/* ============================================================================
   ADPerfDashboard - 01_Tables.sql
   Database : ADS-Stats
   Purpose  : Ensures the collection table exists, adds the site map table and
              the indexes the dashboard queries depend on.
   NOTE     : If dbo.ADPerfMonData already exists (populated by your PowerShell
              collector) the CREATE is skipped; only indexes are added.
   ========================================================================== */
USE [ADS-Stats];
GO

/* ---------------------------------------------------------------------------
   Primary collection table (created only if missing).
   --------------------------------------------------------------------------*/
IF OBJECT_ID(N'dbo.ADPerfMonData', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ADPerfMonData
    (
        id                                                        BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_ADPerfMonData PRIMARY KEY CLUSTERED,
        [Server]                                                  NVARCHAR(128)  NOT NULL,
        system_system_up_time                                     FLOAT          NULL,
        memory_available_mbytes                                   FLOAT          NULL,
        memory_pages_sec                                          FLOAT          NULL,
        memory_free_system_page_table_entries                     FLOAT          NULL,
        memory_pool_nonpaged_bytes                                FLOAT          NULL,
        memory_pool_paged_bytes                                   FLOAT          NULL,
        process_lsass_processor_time                              FLOAT          NULL,
        process_lsass_working_set                                 FLOAT          NULL,
        physicaldisk_0_c_avg_disk_sec_read                        FLOAT          NULL,
        physicaldisk_1_d_avg_disk_sec_read                        FLOAT          NULL,
        physicaldisk_total_avg_disk_sec_read                      FLOAT          NULL,
        physicaldisk_0_c_avg_disk_sec_write                       FLOAT          NULL,
        physicaldisk_1_d_avg_disk_sec_write                       FLOAT          NULL,
        physicaldisk_total_avg_disk_sec_write                     FLOAT          NULL,
        security_system_wide_statistics_kerberos_authentications  FLOAT          NULL,
        security_system_wide_statistics_ntlm_authentications      FLOAT          NULL,
        directoryservices_ntds_ldap_bind_time                     FLOAT          NULL,
        directoryservices_ntds_ldap_searches_sec                  FLOAT          NULL,
        directoryservices_ntds_ldap_client_sessions               FLOAT          NULL,
        directoryservices_ntds_ab_client_sessions                 FLOAT          NULL,
        directoryservices_ntds_ldap_successful_binds_sec          FLOAT          NULL,
        directoryservices_ntds_ldap_new_connections_sec           FLOAT          NULL,
        directoryservices_ntds_ldap_closed_connections_sec        FLOAT          NULL,
        directoryservices_ntds_ds_server_name_translations_sec    FLOAT          NULL,
        directoryservices_ntds_ds_client_name_translations_sec    FLOAT          NULL,
        server_errors_logon                                       FLOAT          NULL,
        server_server_sessions                                    FLOAT          NULL,
        server_logon_total                                        FLOAT          NULL,
        server_logon_sec                                          FLOAT          NULL,
        Total_Days                                                FLOAT          NULL,
        Logons_Per_Day                                            FLOAT          NULL,
        ReportDate                                                DATETIME       NOT NULL,
        ReportDate2                                               NVARCHAR(50)   NULL
    );
END
GO

/* ---------------------------------------------------------------------------
   Optional site map: maps each DC to an AD site for the Site filter.
   Populate manually or from: Get-ADDomainController -Filter * |
       Select Name, Site | Export-Csv
   --------------------------------------------------------------------------*/
IF OBJECT_ID(N'dbo.ADServerSites', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ADServerSites
    (
        [Server] NVARCHAR(128) NOT NULL CONSTRAINT PK_ADServerSites PRIMARY KEY CLUSTERED,
        [Site]   NVARCHAR(128) NOT NULL
    );
END
GO

/* ---------------------------------------------------------------------------
   Indexes. The dashboard's hot path is "latest row per server" and
   "history for one server over a date range" — both served by this index.
   --------------------------------------------------------------------------*/
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = N'IX_ADPerfMonData_Server_ReportDate'
                 AND object_id = OBJECT_ID(N'dbo.ADPerfMonData'))
BEGIN
    CREATE NONCLUSTERED INDEX IX_ADPerfMonData_Server_ReportDate
        ON dbo.ADPerfMonData ([Server] ASC, ReportDate DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = N'IX_ADPerfMonData_ReportDate'
                 AND object_id = OBJECT_ID(N'dbo.ADPerfMonData'))
BEGIN
    CREATE NONCLUSTERED INDEX IX_ADPerfMonData_ReportDate
        ON dbo.ADPerfMonData (ReportDate DESC)
        INCLUDE ([Server]);
END
GO

PRINT '01_Tables.sql completed.';
GO
