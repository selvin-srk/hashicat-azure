/* ============================================================================
   ADPerfDashboard - 03_Security.sql
   Purpose : Grants the IIS application-pool identity least-privilege access:
             EXECUTE on the dashboard procedures and SELECT on the view only.
             The web app can never write to the database.
   USAGE   : Replace DOMAIN\SVC-ADPerfDash with your app-pool identity.
             For the default identity use: IIS APPPOOL\ADPerfDashboard
             (machine account DOMAIN\SERVER$ if SQL is on another host).
   ========================================================================== */
USE [master];
GO

-- 1. Login (Windows authentication — no passwords anywhere)
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'DOMAIN\SVC-ADPerfDash')
BEGIN
    CREATE LOGIN [DOMAIN\SVC-ADPerfDash] FROM WINDOWS;
END
GO

USE [ADS-Stats];
GO

-- 2. Database user
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'DOMAIN\SVC-ADPerfDash')
BEGIN
    CREATE USER [DOMAIN\SVC-ADPerfDash] FOR LOGIN [DOMAIN\SVC-ADPerfDash];
END
GO

-- 3. Dedicated role with least privilege
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'ADPerfDashboardReader' AND type = 'R')
BEGIN
    CREATE ROLE ADPerfDashboardReader;
END
GO

GRANT SELECT  ON dbo.vw_ADPerfMonData      TO ADPerfDashboardReader;
GRANT EXECUTE ON dbo.usp_GetLatestSnapshot TO ADPerfDashboardReader;
GRANT EXECUTE ON dbo.usp_GetServerHistory  TO ADPerfDashboardReader;
GRANT EXECUTE ON dbo.usp_GetDailyTrends    TO ADPerfDashboardReader;
GRANT EXECUTE ON dbo.usp_GetServers        TO ADPerfDashboardReader;
GRANT EXECUTE ON dbo.usp_GetSites          TO ADPerfDashboardReader;
GRANT EXECUTE ON dbo.usp_GetHistoryPaged   TO ADPerfDashboardReader;
GO

ALTER ROLE ADPerfDashboardReader ADD MEMBER [DOMAIN\SVC-ADPerfDash];
GO

PRINT '03_Security.sql completed.';
GO
