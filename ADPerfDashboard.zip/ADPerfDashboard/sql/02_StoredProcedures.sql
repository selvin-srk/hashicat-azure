/* ============================================================================
   ADPerfDashboard - 02_StoredProcedures.sql
   Database : ADS-Stats
   Purpose  : View + stored procedures consumed by the web application.
              All application data access goes through these procedures with
              typed parameters — no ad-hoc SQL from the app.
   NOTE     : PerfMon "Avg. Disk sec/Read|Write" counters are stored in
              SECONDS; the view converts them to MILLISECONDS. If your
              collector already stores milliseconds, remove the "* 1000".
   ========================================================================== */
USE [ADS-Stats];
GO

/* ---------------------------------------------------------------------------
   vw_ADPerfMonData : single place that maps raw column names to the
   PascalCase aliases the application binds to, converts disk latency to ms,
   and joins the optional site map.
   --------------------------------------------------------------------------*/
CREATE OR ALTER VIEW dbo.vw_ADPerfMonData
AS
SELECT
    d.id                                                          AS Id,
    d.[Server]                                                    AS [Server],
    s.[Site]                                                      AS [Site],
    d.system_system_up_time                                       AS SystemUpTimeSeconds,
    d.memory_available_mbytes                                     AS MemoryAvailableMBytes,
    d.memory_pages_sec                                            AS MemoryPagesSec,
    d.memory_free_system_page_table_entries                       AS MemoryFreePageTableEntries,
    d.memory_pool_nonpaged_bytes                                  AS MemoryPoolNonPagedBytes,
    d.memory_pool_paged_bytes                                     AS MemoryPoolPagedBytes,
    d.process_lsass_processor_time                                AS LsassProcessorTime,
    d.process_lsass_working_set                                   AS LsassWorkingSet,
    d.physicaldisk_0_c_avg_disk_sec_read      * 1000.0            AS DiskCReadMs,
    d.physicaldisk_1_d_avg_disk_sec_read      * 1000.0            AS DiskDReadMs,
    d.physicaldisk_total_avg_disk_sec_read    * 1000.0            AS DiskTotalReadMs,
    d.physicaldisk_0_c_avg_disk_sec_write     * 1000.0            AS DiskCWriteMs,
    d.physicaldisk_1_d_avg_disk_sec_write     * 1000.0            AS DiskDWriteMs,
    d.physicaldisk_total_avg_disk_sec_write   * 1000.0            AS DiskTotalWriteMs,
    d.security_system_wide_statistics_kerberos_authentications    AS KerberosAuthentications,
    d.security_system_wide_statistics_ntlm_authentications        AS NtlmAuthentications,
    d.directoryservices_ntds_ldap_bind_time                       AS LdapBindTime,
    d.directoryservices_ntds_ldap_searches_sec                    AS LdapSearchesSec,
    d.directoryservices_ntds_ldap_client_sessions                 AS LdapClientSessions,
    d.directoryservices_ntds_ab_client_sessions                   AS AbClientSessions,
    d.directoryservices_ntds_ldap_successful_binds_sec            AS LdapSuccessfulBindsSec,
    d.directoryservices_ntds_ldap_new_connections_sec             AS LdapNewConnectionsSec,
    d.directoryservices_ntds_ldap_closed_connections_sec          AS LdapClosedConnectionsSec,
    d.directoryservices_ntds_ds_server_name_translations_sec      AS DsServerNameTranslationsSec,
    d.directoryservices_ntds_ds_client_name_translations_sec      AS DsClientNameTranslationsSec,
    d.server_errors_logon                                         AS ServerErrorsLogon,
    d.server_server_sessions                                      AS ServerSessions,
    d.server_logon_total                                          AS LogonTotal,
    d.server_logon_sec                                            AS LogonSec,
    d.Total_Days                                                  AS TotalDays,
    d.Logons_Per_Day                                              AS LogonsPerDay,
    d.ReportDate                                                  AS ReportDate
FROM dbo.ADPerfMonData d
LEFT JOIN dbo.ADServerSites s ON s.[Server] = d.[Server];
GO

/* ---------------------------------------------------------------------------
   usp_GetLatestSnapshot : newest row per server, optional filters.
   Used by: summary cards, overview grid.
   --------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.usp_GetLatestSnapshot
    @Server   NVARCHAR(128) = NULL,
    @Site     NVARCHAR(128) = NULL,
    @DateFrom DATETIME      = NULL,
    @DateTo   DATETIME      = NULL
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH Ranked AS
    (
        SELECT v.*,
               ROW_NUMBER() OVER (PARTITION BY v.[Server] ORDER BY v.ReportDate DESC) AS rn
        FROM dbo.vw_ADPerfMonData v
        WHERE (@Server   IS NULL OR v.[Server] = @Server)
          AND (@Site     IS NULL OR v.[Site]   = @Site)
          AND (@DateFrom IS NULL OR v.ReportDate >= @DateFrom)
          AND (@DateTo   IS NULL OR v.ReportDate <  DATEADD(DAY, 1, @DateTo))
    )
    SELECT *
    FROM Ranked
    WHERE rn = 1
    ORDER BY [Server];
END
GO

/* ---------------------------------------------------------------------------
   usp_GetServerHistory : all rows for one server over the last @Days days.
   Used by: Server Details page (sparklines, 90-day charts, min/max/avg).
   --------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.usp_GetServerHistory
    @Server NVARCHAR(128),
    @Days   INT = 90
AS
BEGIN
    SET NOCOUNT ON;

    SELECT *
    FROM dbo.vw_ADPerfMonData
    WHERE [Server] = @Server
      AND ReportDate >= DATEADD(DAY, -@Days, GETDATE())
    ORDER BY ReportDate ASC;
END
GO

/* ---------------------------------------------------------------------------
   usp_GetDailyTrends : one averaged row per server per day.
   Used by: every trend chart and heatmap (Authentication, LDAP, Memory,
   Disk tabs). Averaging per day keeps chart payloads small regardless of
   collection frequency.
   --------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.usp_GetDailyTrends
    @Days   INT           = 30,
    @Server NVARCHAR(128) = NULL,
    @Site   NVARCHAR(128) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        v.[Server]                                   AS [Server],
        CAST(v.ReportDate AS DATE)                   AS [Day],
        AVG(v.KerberosAuthentications)               AS Kerberos,
        AVG(v.NtlmAuthentications)                   AS Ntlm,
        AVG(v.LogonSec)                              AS LogonSec,
        MAX(v.LogonTotal)                            AS LogonTotal,
        MAX(v.ServerErrorsLogon)                     AS LogonErrors,
        AVG(v.LdapSearchesSec)                       AS LdapSearchesSec,
        AVG(v.LdapBindTime)                          AS LdapBindTime,
        AVG(v.LdapClientSessions)                    AS LdapClientSessions,
        AVG(v.LdapSuccessfulBindsSec)                AS LdapSuccessfulBindsSec,
        AVG(v.LdapNewConnectionsSec)                 AS LdapNewConnectionsSec,
        AVG(v.LdapClosedConnectionsSec)              AS LdapClosedConnectionsSec,
        AVG(v.DsServerNameTranslationsSec)           AS ServerNameTranslationsSec,
        AVG(v.DsClientNameTranslationsSec)           AS ClientNameTranslationsSec,
        AVG(v.MemoryAvailableMBytes)                 AS MemoryAvailableMBytes,
        AVG(v.MemoryPagesSec)                        AS MemoryPagesSec,
        AVG(v.MemoryPoolPagedBytes)                  AS MemoryPoolPagedBytes,
        AVG(v.MemoryPoolNonPagedBytes)               AS MemoryPoolNonPagedBytes,
        AVG(v.MemoryFreePageTableEntries)            AS MemoryFreePageTableEntries,
        AVG(v.DiskCReadMs)                           AS DiskCReadMs,
        AVG(v.DiskDReadMs)                           AS DiskDReadMs,
        AVG(v.DiskTotalReadMs)                       AS DiskTotalReadMs,
        AVG(v.DiskCWriteMs)                          AS DiskCWriteMs,
        AVG(v.DiskDWriteMs)                          AS DiskDWriteMs,
        AVG(v.DiskTotalWriteMs)                      AS DiskTotalWriteMs,
        AVG(v.LsassProcessorTime)                    AS LsassCpu,
        AVG(v.LsassWorkingSet)                       AS LsassWorkingSet
    FROM dbo.vw_ADPerfMonData v
    WHERE v.ReportDate >= DATEADD(DAY, -@Days, GETDATE())
      AND (@Server IS NULL OR v.[Server] = @Server)
      AND (@Site   IS NULL OR v.[Site]   = @Site)
    GROUP BY v.[Server], CAST(v.ReportDate AS DATE)
    ORDER BY [Day] ASC, v.[Server] ASC;
END
GO

/* ---------------------------------------------------------------------------
   usp_GetServers : distinct DC names for the filter drop-down.
   --------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.usp_GetServers
AS
BEGIN
    SET NOCOUNT ON;
    SELECT DISTINCT [Server]
    FROM dbo.ADPerfMonData
    ORDER BY [Server];
END
GO

/* ---------------------------------------------------------------------------
   usp_GetSites : distinct site names for the filter drop-down.
   --------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.usp_GetSites
AS
BEGIN
    SET NOCOUNT ON;
    SELECT DISTINCT [Site]
    FROM dbo.ADServerSites
    ORDER BY [Site];
END
GO

/* ---------------------------------------------------------------------------
   usp_GetHistoryPaged : raw history page for lazy-loaded grids.
   Returns two result sets: (1) total row count, (2) requested page.
   --------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE dbo.usp_GetHistoryPaged
    @Server   NVARCHAR(128) = NULL,
    @DateFrom DATETIME      = NULL,
    @DateTo   DATETIME      = NULL,
    @Offset   INT           = 0,
    @PageSize INT           = 25
AS
BEGIN
    SET NOCOUNT ON;

    -- Guard rails: never allow a runaway page size
    IF @PageSize > 500 SET @PageSize = 500;
    IF @PageSize < 1   SET @PageSize = 25;
    IF @Offset   < 0   SET @Offset   = 0;

    SELECT COUNT(*)
    FROM dbo.vw_ADPerfMonData v
    WHERE (@Server   IS NULL OR v.[Server] = @Server)
      AND (@DateFrom IS NULL OR v.ReportDate >= @DateFrom)
      AND (@DateTo   IS NULL OR v.ReportDate <  DATEADD(DAY, 1, @DateTo));

    SELECT *
    FROM dbo.vw_ADPerfMonData v
    WHERE (@Server   IS NULL OR v.[Server] = @Server)
      AND (@DateFrom IS NULL OR v.ReportDate >= @DateFrom)
      AND (@DateTo   IS NULL OR v.ReportDate <  DATEADD(DAY, 1, @DateTo))
    ORDER BY v.ReportDate DESC, v.[Server] ASC
    OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;
END
GO

PRINT '02_StoredProcedures.sql completed.';
GO
