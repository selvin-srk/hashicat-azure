# Installation Guide

## Prerequisites

Windows Server 2019/2022 with IIS, .NET 8 Hosting Bundle, SQL Server 2016+ hosting the `ADS-Stats` database, and Visual Studio 2022 (or the .NET 8 SDK) to build.

## 1. Database setup

Run the scripts in `sql/` against your SQL Server **in order**, connected to the `ADS-Stats` database:

1. `01_Tables.sql` — creates `dbo.ADPerfMonData` only if missing (safe on an existing database), creates `dbo.ADServerSites`, and adds the two indexes the dashboard needs.
2. `02_StoredProcedures.sql` — creates `dbo.vw_ADPerfMonData` and the six stored procedures (`usp_GetLatestSnapshot`, `usp_GetServerHistory`, `usp_GetDailyTrends`, `usp_GetServers`, `usp_GetSites`, `usp_GetHistoryPaged`).
3. `03_Security.sql` — **edit first**: replace `DOMAIN\SVC-ADPerfDash` with the identity your IIS application pool will run as, then run it. It creates a least-privilege role with EXECUTE-only rights.

Verify: `EXEC dbo.usp_GetLatestSnapshot;` should return one row per domain controller.

## 2. Configure the application

Edit `src/ADPerfDashboard/appsettings.json`:

- `ConnectionStrings:ADSStats` — already set to `Server=edm-goa-sql-1;Database=ADS-Stats`. Leave `Integrated Security=true` (no passwords are stored anywhere).
- `Authorization:ViewerGroups` — optional list of AD groups allowed to view, e.g. `["CONTOSO\\AD-Dashboard-Viewers"]`. Empty = any authenticated domain user.
- `HealthThresholds` — adjust if your baseline differs from the defaults.
- `Dashboard:CacheSeconds` — server-side cache TTL (default 300).

## 3. Build and publish

```powershell
cd src\ADPerfDashboard
dotnet restore
dotnet publish -c Release -o C:\Publish\ADPerfDashboard
```

Or in Visual Studio: right-click the project → Publish → Folder.

## 4. Deploy to IIS

Follow `docs/IIS-Deployment-Guide.md`.

## 5. Smoke test

Browse to the site as a domain user. Expected result: KPI cards populate within a few seconds, the Overview grid lists every DC with colour-coded health, clicking a row opens the Server Details page, and Export downloads a CSV/Excel file. Check `App_Data\Logs\` for the audit/application log.

## Troubleshooting

- **HTTP 500 immediately** — check `App_Data\Logs`, most commonly a wrong SQL server name or missing SQL permissions for the app-pool identity.
- **401 loop in browser** — site must be in the Local Intranet zone (or add it) so Windows auth is silent; verify Windows Authentication is enabled and Anonymous disabled in IIS.
- **Login failed for `DOMAIN\MACHINE$`** — SQL is remote and the pool runs as ApplicationPoolIdentity; either grant the machine account or use a domain service account (recommended, see deployment guide).
- **Empty Site drop-down** — populate `dbo.ADServerSites` (see README).
- **Disk latency looks 1000× too high/low** — see the units note 