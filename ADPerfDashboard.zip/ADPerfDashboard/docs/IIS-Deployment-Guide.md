# IIS Deployment Guide

## 1. Install prerequisites on the web server

```powershell
# IIS with Windows Authentication
Install-WindowsFeature Web-Server, Web-Windows-Auth, Web-Asp-Net45, Web-Mgmt-Console

# .NET 8 Hosting Bundle (download from https://dotnet.microsoft.com/download/dotnet/8.0)
# Install dotnet-hosting-8.x.x-win.exe, then:
net stop was /y
net start w3svc
```

## 2. Create the application pool

```powershell
Import-Module WebAdministration

New-WebAppPool -Name "ADPerfDashboard"
Set-ItemProperty IIS:\AppPools\ADPerfDashboard managedRuntimeVersion ""   # No Managed Code
Set-ItemProperty IIS:\AppPools\ADPerfDashboard startMode "AlwaysRunning"

# RECOMMENDED: run as a domain service account so SQL access works cleanly
Set-ItemProperty IIS:\AppPools\ADPerfDashboard processModel.identityType 3
Set-ItemProperty IIS:\AppPools\ADPerfDashboard processModel.userName "DOMAIN\SVC-ADPerfDash"
Set-ItemProperty IIS:\AppPools\ADPerfDashboard processModel.password "<service-account-password>"
```

The service account needs no special rights — just membership in the `ADPerfDashboardReader` SQL role (script `03_Security.sql`) and read access to the publish folder.

## 3. Create the site

```powershell
New-Item -ItemType Directory -Path C:\inetpub\ADPerfDashboard -Force
# copy your publish output here, then:

New-Website -Name "ADPerfDashboard" -Port 443 -PhysicalPath "C:\inetpub\ADPerfDashboard" `
            -ApplicationPool "ADPerfDashboard" -Ssl

# bind your certificate (replace thumbprint)
$cert = Get-ChildItem Cert:\LocalMachine\My | Where-Object Thumbprint -eq "<THUMBPRINT>"
New-Item "IIS:\SslBindings\0.0.0.0!443" -Value $cert
```

## 4. Enable Windows Authentication

```powershell
Set-WebConfigurationProperty -PSPath "IIS:\" -Location "ADPerfDashboard" `
    -Filter "system.webServer/security/authentication/windowsAuthentication" -Name enabled -Value $true
Set-WebConfigurationProperty -PSPath "IIS:\" -Location "ADPerfDashboard" `
    -Filter "system.webServer/security/authentication/anonymousAuthentication" -Name enabled -Value $false
```

The shipped `web.config` also declares these, with Negotiate (Kerberos) preferred over NTLM.

### Kerberos (recommended over NTLM)

If the site runs under a domain service account and users browse by hostname, register an SPN once:

```powershell
setspn -S HTTP/adperf.yourdomain.com DOMAIN\SVC-ADPerfDash
```

## 5. File permissions

```powershell
# App needs write access ONLY to its log folder
$acl = "IIS AppPool\ADPerfDashboard"   # or DOMAIN\SVC-ADPerfDash
icacls "C:\inetpub\ADPerfDashboard" /grant "${acl}:(OI)(CI)RX"
icacls "C:\inetpub\ADPerfDashboard\App_Data" /grant "${acl}:(OI)(CI)M"
```

## 6. Verify

1. `iisreset` (or recycle the pool).
2. Browse `https://adperf.yourdomain.com` from a domain-joined client — no credential prompt should appear (Local Intranet zone).
3. Confirm data loads and `App_Data\Logs\adperfdash-YYYYMMDD.log` shows `AUDIT user=DOMAIN\you ...` lines.

## Maintenance notes

Logs roll daily and are retained 90 days (configurable in `appsettings.json → Serilog`). The app is read-only against SQL, so no backup considerations beyond the database itself. To update: publish to a temp folder, stop the app pool, copy over, start the pool — total downtime a few seconds. Auto-refresh is client-side (12 h), so an IIS recycle never interrupts users' browsers.
