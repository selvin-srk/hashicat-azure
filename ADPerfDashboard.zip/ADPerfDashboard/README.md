# Active Directory Performance Dashboard

Production ASP.NET Core 8 MVC dashboard for monitoring domain controller performance from the **ADS-Stats** SQL Server database (table `dbo.ADPerfMonData`). Azure-portal style UI, dark mode, Bootstrap 5, Chart.js, Font Awesome, fully AJAX-driven with a 12-hour auto refresh.

## Solution layout

```
ADPerfDashboard.sln
├── src/ADPerfDashboard/          ASP.NET Core 8 MVC application
│   ├── Controllers/              Home, Server, DashboardApi, Export
│   ├── Models/                   AdPerfRecord, DTOs, health models
│   ├── Repositories/             Dapper repository (stored procs only)
│   ├── Services/                 DashboardService, HealthEngine, ExportService
│   ├── Middleware/               Global exception handler, audit logging
│   ├── Views/                    Dashboard + Server Details (Razor)
│   └── wwwroot/                  site.css, dashboard.js, charts.js, server-details.js
├── sql/                          01_Tables, 02_StoredProcedures, 03_Security
└── docs/                         Installation-Guide.md, IIS-Deployment-Guide.md
```

## Features

The dashboard shows summary KPI cards (latest collection, DC counts by health, averages, worst offenders) above six tabs: Overview grid (sortable, searchable, colour-coded, click-through to details), Authentication, LDAP (with heatmap), Memory, Disk (C:/D:/combined/total with threshold guides and heatmap), and a Server Details deep-dive with every metric, sparklines, 90-day history, min/max/avg and CSV/Excel export. Tabs load lazily; only the latest snapshot loads initially and history loads on demand.

## Health engine

Computed server-side per DC (configurable in `appsettings.json → HealthThresholds`): memory available (critical <2048 MB, warning <4096 MB), disk read/write latency (critical >20 ms, warning >10 ms), LDAP bind time (critical >100, warning >50), logon errors (critical >10), LSASS CPU (critical >70 %, warning >40 %), and a warning when NTLM exceeds 25 % of authentications.

## Architecture and security

Repository pattern with dependency injection throughout; all SQL access is async, uses connection pooling and calls **parameterized stored procedures only** — no dynamic SQL. Windows Authentication (Negotiate) with an optional AD-group viewer policy (`Authorization:ViewerGroups`), read-only database role (`sql/03_Security.sql`), audit logging of every request to rolling Serilog files, a global exception handler that never leaks stack traces, and in-memory caching (default 5 min) for fast loads.

## Important data note — disk latency units

PerfMon `Avg. Disk sec/Read|Write` counters are collected in **seconds**. The view `dbo.vw_ADPerfMonData` multiplies them by 1000 to display milliseconds. If your collector already stores milliseconds, remove the `* 1000.0` factors in `sql/02_StoredProcedures.sql`.

## Site filter

Populate `dbo.ADServerSites (Server, Site)` to enable the Site filter, e.g.:

```powershell
Get-ADDomainController -Filter * | ForEach-Object {
    Invoke-Sqlcmd -ServerInstance YOUR-SQL -Database ADS-Stats -Query `
    "MERGE dbo.ADServerSites AS t USING (SELECT '$($_.Name)' s,'$($_.Site)' st) src ON t.Server=src.s
     WHEN MATCHED THEN UPDATE SET Site=src.st WHEN NOT MATCHED THEN INSERT(Server,Site) VALUES(src.s,src.st);"
}
```

## Offline / air-gapped environments

The layout references Bootstrap, Font Awesome, jQuery and Chart.js from CDNs. For servers without internet access, download those four libraries into `wwwroot/lib/` and update the `<link>`/`<script>` tags in `Views/Shared/_Layout.cshtml`.

## Getting started

See `docs/Installation-Guide.md` for build + database setup and `docs/IIS-Deployment-Guide.md` for IIS hosting on Windows Server.
