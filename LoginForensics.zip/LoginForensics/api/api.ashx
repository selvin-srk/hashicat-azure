<%@ WebHandler Language="C#" Class="ApiHandler" %>
<%@ Assembly Name="System.Web.Extensions" %>

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;

/// <summary>
/// GOA Login Forensics API Handler
/// All actions return JSON. Query via:  api/api.ashx?action=ACTION_NAME[&param=value...]
///
/// Actions:
///   filter-options   — distinct events / sites / OS for dropdowns
///   kpi              — summary KPIs (from, to)
///   daily-volume     — login count per day (from, to)
///   event-types      — count by Event column (from, to)
///   weekday          — count by day-of-week (from, to)
///   hourly           — count by hour (from, to)
///   os-dist          — OS distribution (from, to)
///   heatmap          — 7×24 day/hour matrix (year)
///   sites            — logins by AD site (from, to)
///   servers          — logins by logon server (from, to)
///   historic         — yearly aggregates (fromYear, toYear)
///   live-feed        — paginated recent logins (from, to, page, pageSize, event, site, search)
///   user-search      — search users by ID/DN/machine (q, from, to)
///   user-profile     — per-user charts + events (userId, from, to)
///   anomalies        — after-hours, multi-site, high-freq alerts (from, to)
///   machines         — machine registry with stats (from, to, search, os, page)
///   subnets          — subnet activity summary (from, to)
///   comparison       — side-by-side entity stats (type, a, b, from, to)
/// </summary>
public class ApiHandler : IHttpHandler
{
    private static readonly string ConnStr =
        ConfigurationManager.ConnectionStrings["GOALogins"].ConnectionString;

    private readonly JavaScriptSerializer _json = new JavaScriptSerializer
    {
        MaxJsonLength = int.MaxValue
    };

    public bool IsReusable { get { return false; } }

    // ======================================================================
    //  Entry Point
    // ======================================================================
    public void ProcessRequest(HttpContext ctx)
    {
        ctx.Response.ContentType = "application/json; charset=utf-8";
        ctx.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        // Allow same-origin intranet AJAX
        ctx.Response.AddHeader("Access-Control-Allow-Origin", "*");

        string action = P(ctx, "action");

        try
        {
            object result;
            switch (action)
            {
                case "filter-options": result = GetFilterOptions();       break;
                case "kpi":            result = GetKPI(ctx);              break;
                case "daily-volume":   result = GetDailyVolume(ctx);      break;
                case "event-types":    result = GetEventTypes(ctx);       break;
                case "weekday":        result = GetWeekdayDist(ctx);      break;
                case "hourly":         result = GetHourlyDist(ctx);       break;
                case "os-dist":        result = GetOSDist(ctx);           break;
                case "heatmap":        result = GetHeatmap(ctx);          break;
                case "sites":          result = GetSites(ctx);            break;
                case "servers":        result = GetServers(ctx);          break;
                case "historic":       result = GetHistoric(ctx);         break;
                case "live-feed":      result = GetLiveFeed(ctx);         break;
                case "user-search":    result = GetUserSearch(ctx);       break;
                case "user-profile":   result = GetUserProfile(ctx);      break;
                case "anomalies":      result = GetAnomalies(ctx);        break;
                case "machines":       result = GetMachines(ctx);         break;
                case "subnets":        result = GetSubnets(ctx);          break;
                case "comparison":     result = GetComparison(ctx);       break;
                default:
                    ctx.Response.StatusCode = 400;
                    result = new { error = "Unknown action: " + action };
                    break;
            }
            ctx.Response.Write(_json.Serialize(result));
        }
        catch (Exception ex)
        {
            ctx.Response.StatusCode = 500;
            ctx.Response.Write(_json.Serialize(new { error = ex.Message }));
        }
    }

    // ======================================================================
    //  Helpers
    // ======================================================================
    private SqlConnection Conn()
    {
        var c = new SqlConnection(ConnStr);
        c.Open();
        return c;
    }

    private string P(HttpContext ctx, string key, string def = "")
        => ctx.Request[key] ?? def;

    private DateTime DateP(HttpContext ctx, string key, DateTime def)
    {
        DateTime d;
        return DateTime.TryParse(ctx.Request[key], out d) ? d.Date : def;
    }

    private int IntP(HttpContext ctx, string key, int def)
    {
        int v;
        return int.TryParse(ctx.Request[key], out v) ? v : def;
    }

    private string S(IDataRecord r, string col)
        => r.IsDBNull(r.GetOrdinal(col)) ? "" : r[col].ToString().Trim();

    private int I(IDataRecord r, string col)
        => r.IsDBNull(r.GetOrdinal(col)) ? 0 : Convert.ToInt32(r[col]);

    private long L(IDataRecord r, string col)
        => r.IsDBNull(r.GetOrdinal(col)) ? 0L : Convert.ToInt64(r[col]);

    private string DateStr(IDataRecord r, string col)
    {
        int o = r.GetOrdinal(col);
        return r.IsDBNull(o) ? "" : Convert.ToDateTime(r[o]).ToString("yyyy-MM-dd");
    }

    // ======================================================================
    //  FILTER OPTIONS  — distinct values for dropdown population
    // ======================================================================
    private object GetFilterOptions()
    {
        var events = new List<string>();
        var sites  = new List<string>();
        var os     = new List<string>();

        using (var cn = Conn())
        {
            Action<string, List<string>> fill = (sql, lst) =>
            {
                using (var cmd = new SqlCommand(sql, cn))
                using (var r = cmd.ExecuteReader())
                    while (r.Read()) if (!r.IsDBNull(0)) lst.Add(r[0].ToString().Trim());
            };

            fill("SELECT DISTINCT Event FROM [REMEDY_Info].[dbo].[GOALogins] WHERE Event IS NOT NULL ORDER BY Event", events);
            fill("SELECT DISTINCT AdsSiteName FROM [REMEDY_Info].[dbo].[GOALogins] WHERE AdsSiteName IS NOT NULL ORDER BY AdsSiteName", sites);
            fill("SELECT DISTINCT MachineOS FROM [REMEDY_Info].[dbo].[GOALogins] WHERE MachineOS IS NOT NULL ORDER BY MachineOS", os);
        }
        return new { events, sites, os };
    }

    // ======================================================================
    //  KPI
    // ======================================================================
    private object GetKPI(HttpContext ctx)
    {
        var from = DateP(ctx, "from", DateTime.Now.AddYears(-1));
        var to   = DateP(ctx, "to",   DateTime.Now);

        const string sql = @"
SELECT
    COUNT(*)                                                                       AS TotalLogins,
    COUNT(DISTINCT LastLogonID)                                                    AS UniqueUsers,
    COUNT(DISTINCT MachineName)                                                    AS UniqueMachines,
    SUM(CASE WHEN Event LIKE '%VPN%' THEN 1 ELSE 0 END)                           AS VPNSessions,
    SUM(CASE WHEN (
            CAST(TRY_CONVERT(time, LogonTime) AS TIME) < '06:00:00'
         OR CAST(TRY_CONVERT(time, LogonTime) AS TIME) > '20:00:00'
         OR LogonWeekday IN ('Saturday','Sunday')
    ) THEN 1 ELSE 0 END)                                                           AS AnomalousLogins,
    COUNT(*) / NULLIF(DATEDIFF(day, @from, DATEADD(day,1,@to)), 0)                AS AvgPerDay
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to", to);
            using (var r = cmd.ExecuteReader())
            {
                if (r.Read())
                    return new {
                        totalLogins     = L(r, "TotalLogins"),
                        uniqueUsers     = I(r, "UniqueUsers"),
                        uniqueMachines  = I(r, "UniqueMachines"),
                        vpnSessions     = I(r, "VPNSessions"),
                        anomalousLogins = I(r, "AnomalousLogins"),
                        avgPerDay       = I(r, "AvgPerDay")
                    };
            }
        }
        return new {};
    }

    // ======================================================================
    //  DAILY VOLUME
    // ======================================================================
    private object GetDailyVolume(HttpContext ctx)
    {
        var from = DateP(ctx, "from", DateTime.Now.AddDays(-30));
        var to   = DateP(ctx, "to",   DateTime.Now);

        var labels = new List<string>(); var data = new List<long>();

        const string sql = @"
SELECT CAST(LogonDate AS DATE) AS Day, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
GROUP BY CAST(LogonDate AS DATE) ORDER BY Day";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to", to);
            using (var r = cmd.ExecuteReader())
                while (r.Read()) { labels.Add(DateStr(r,"Day")); data.Add(L(r,"Cnt")); }
        }
        return new { labels, data };
    }

    // ======================================================================
    //  EVENT TYPES
    // ======================================================================
    private object GetEventTypes(HttpContext ctx)
    {
        var from = DateP(ctx, "from", DateTime.Now.AddDays(-30));
        var to   = DateP(ctx, "to",   DateTime.Now);

        var labels = new List<string>(); var data = new List<long>();

        const string sql = @"
SELECT COALESCE(Event,'Unknown') AS Ev, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
GROUP BY Event ORDER BY Cnt DESC";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to", to);
            using (var r = cmd.ExecuteReader())
                while (r.Read()) { labels.Add(r["Ev"].ToString()); data.Add(L(r,"Cnt")); }
        }
        return new { labels, data };
    }

    // ======================================================================
    //  WEEKDAY DISTRIBUTION
    // ======================================================================
    private object GetWeekdayDist(HttpContext ctx)
    {
        var from = DateP(ctx, "from", DateTime.Now.AddYears(-1));
        var to   = DateP(ctx, "to",   DateTime.Now);

        var order = new[] {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
        var dict  = new Dictionary<string,long>();
        foreach (var d in order) dict[d] = 0;

        const string sql = @"
SELECT COALESCE(LogonWeekday,'Unknown') AS Wd, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to) AND LogonWeekday IS NOT NULL
GROUP BY LogonWeekday";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to", to);
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                {
                    var k = r["Wd"].ToString().Trim();
                    if (dict.ContainsKey(k)) dict[k] = Convert.ToInt64(r["Cnt"]);
                }
        }

        var labels = new List<string>(order);
        var data   = new List<long>();
        foreach (var k in order) data.Add(dict.ContainsKey(k) ? dict[k] : 0);
        return new { labels, data };
    }

    // ======================================================================
    //  HOURLY DISTRIBUTION
    // ======================================================================
    private object GetHourlyDist(HttpContext ctx)
    {
        var from = DateP(ctx, "from", DateTime.Now.AddDays(-30));
        var to   = DateP(ctx, "to",   DateTime.Now);

        var data = new long[24];

        const string sql = @"
SELECT DATEPART(hour, TRY_CONVERT(time, LogonTime)) AS Hr, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
GROUP BY DATEPART(hour, TRY_CONVERT(time, LogonTime))";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to", to);
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                    if (!r.IsDBNull(0)) { int h = Convert.ToInt32(r["Hr"]); if (h>=0&&h<24) data[h] = Convert.ToInt64(r["Cnt"]); }
        }

        var labels = new List<string>();
        for (int i=0;i<24;i++) labels.Add(i.ToString("00")+"h");
        return new { labels, data };
    }

    // ======================================================================
    //  OS DISTRIBUTION
    // ======================================================================
    private object GetOSDist(HttpContext ctx)
    {
        var from = DateP(ctx, "from", DateTime.Now.AddYears(-1));
        var to   = DateP(ctx, "to",   DateTime.Now);

        var labels = new List<string>(); var data = new List<long>();

        const string sql = @"
SELECT TOP 12 COALESCE(MachineOS,'Unknown') AS OS, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
GROUP BY MachineOS ORDER BY Cnt DESC";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to", to);
            using (var r = cmd.ExecuteReader())
                while (r.Read()) { labels.Add(S(r,"OS")); data.Add(L(r,"Cnt")); }
        }
        return new { labels, data };
    }

    // ======================================================================
    //  HEATMAP  — 7 days × 24 hours
    // ======================================================================
    private object GetHeatmap(HttpContext ctx)
    {
        int year = IntP(ctx, "year", DateTime.Now.Year);
        string site = P(ctx, "site");

        var dayOrder = new[] {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
        var dayIdx   = new Dictionary<string,int>
            {{"Monday",0},{"Tuesday",1},{"Wednesday",2},{"Thursday",3},{"Friday",4},{"Saturday",5},{"Sunday",6}};
        var matrix = new long[7, 24];

        var sb = new StringBuilder(@"
SELECT LogonWeekday, DATEPART(hour, TRY_CONVERT(time, LogonTime)) AS Hr, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE YEAR(LogonDate) = @year AND LogonWeekday IS NOT NULL");
        if (!string.IsNullOrEmpty(site)) sb.Append(" AND AdsSiteName = @site");
        sb.Append(" GROUP BY LogonWeekday, DATEPART(hour, TRY_CONVERT(time, LogonTime))");

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sb.ToString(), cn))
        {
            cmd.Parameters.AddWithValue("@year", year);
            if (!string.IsNullOrEmpty(site)) cmd.Parameters.AddWithValue("@site", site);
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                {
                    string day = S(r,"LogonWeekday");
                    if (!r.IsDBNull(1) && dayIdx.ContainsKey(day))
                    {
                        int h = Convert.ToInt32(r["Hr"]);
                        int d = dayIdx[day];
                        if (h>=0&&h<24) matrix[d,h] = Convert.ToInt64(r["Cnt"]);
                    }
                }
        }

        var result = new List<List<long>>();
        for (int d=0;d<7;d++) { var row = new List<long>(); for (int h=0;h<24;h++) row.Add(matrix[d,h]); result.Add(row); }

        var hours = new List<string>();
        for (int i=0;i<24;i++) hours.Add(i.ToString("00"));
        return new { days = dayOrder, hours, matrix = result };
    }

    // ======================================================================
    //  SITES
    // ======================================================================
    private object GetSites(HttpContext ctx)
    {
        var from = DateP(ctx, "from", DateTime.Now.AddYears(-1));
        var to   = DateP(ctx, "to",   DateTime.Now);

        var labels = new List<string>(); var data = new List<long>();

        const string sql = @"
SELECT TOP 15 COALESCE(AdsSiteName,'Unknown') AS Site, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
GROUP BY AdsSiteName ORDER BY Cnt DESC";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to", to);
            using (var r = cmd.ExecuteReader())
                while (r.Read()) { labels.Add(S(r,"Site")); data.Add(L(r,"Cnt")); }
        }
        return new { labels, data };
    }

    // ======================================================================
    //  LOGON SERVERS
    // ======================================================================
    private object GetServers(HttpContext ctx)
    {
        var from = DateP(ctx, "from", DateTime.Now.AddYears(-1));
        var to   = DateP(ctx, "to",   DateTime.Now);

        var labels = new List<string>(); var data = new List<long>();

        const string sql = @"
SELECT TOP 10 COALESCE(LogonServer,'Unknown') AS Srv, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
GROUP BY LogonServer ORDER BY Cnt DESC";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to", to);
            using (var r = cmd.ExecuteReader())
                while (r.Read()) { labels.Add(S(r,"Srv")); data.Add(L(r,"Cnt")); }
        }
        return new { labels, data };
    }

    // ======================================================================
    //  HISTORIC  — yearly aggregates
    // ======================================================================
    private object GetHistoric(HttpContext ctx)
    {
        int fromYear = IntP(ctx, "fromYear", DateTime.Now.Year - 10);
        int toYear   = IntP(ctx, "toYear",   DateTime.Now.Year);

        var labels = new List<string>();
        var totalLogins    = new List<long>();
        var uniqueUsers    = new List<int>();
        var vpnSessions    = new List<int>();
        var uniqueMachines = new List<int>();

        const string sql = @"
SELECT
    YEAR(LogonDate)                                                AS Yr,
    COUNT(*)                                                       AS TotalLogins,
    COUNT(DISTINCT LastLogonID)                                    AS UniqueUsers,
    SUM(CASE WHEN Event LIKE '%VPN%' THEN 1 ELSE 0 END)           AS VPNSessions,
    COUNT(DISTINCT MachineName)                                    AS UniqueMachines
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE YEAR(LogonDate) >= @fromYear AND YEAR(LogonDate) <= @toYear
GROUP BY YEAR(LogonDate)
ORDER BY Yr";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.CommandTimeout = 120;
            cmd.Parameters.AddWithValue("@fromYear", fromYear);
            cmd.Parameters.AddWithValue("@toYear",   toYear);
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                {
                    labels.Add(r["Yr"].ToString());
                    totalLogins.Add(L(r,"TotalLogins"));
                    uniqueUsers.Add(I(r,"UniqueUsers"));
                    vpnSessions.Add(I(r,"VPNSessions"));
                    uniqueMachines.Add(I(r,"UniqueMachines"));
                }
        }
        return new { labels, totalLogins, uniqueUsers, vpnSessions, uniqueMachines };
    }

    // ======================================================================
    //  LIVE FEED  — server-side paginated login records
    // ======================================================================
    private object GetLiveFeed(HttpContext ctx)
    {
        var from     = DateP(ctx, "from",     DateTime.Now.AddDays(-7));
        var to       = DateP(ctx, "to",       DateTime.Now);
        int page     = Math.Max(1, IntP(ctx, "page", 1));
        int pageSize = IntP(ctx, "pageSize", 25);
        string evFilter  = P(ctx, "event");
        string siteFilter= P(ctx, "site");
        string search    = P(ctx, "search");

        // Build WHERE
        var where = new StringBuilder("WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)");
        if (!string.IsNullOrEmpty(evFilter))  where.Append(" AND Event = @event");
        if (!string.IsNullOrEmpty(siteFilter))where.Append(" AND AdsSiteName = @site");
        if (!string.IsNullOrEmpty(search))    where.Append(" AND (LastLogonID LIKE @search OR MachineName LIKE @search OR NetworkInfoPrimaryIP LIKE @search)");

        Action<SqlCommand> addPrms = cmd =>
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to",   to);
            if (!string.IsNullOrEmpty(evFilter))   cmd.Parameters.AddWithValue("@event",  evFilter);
            if (!string.IsNullOrEmpty(siteFilter))  cmd.Parameters.AddWithValue("@site",   siteFilter);
            if (!string.IsNullOrEmpty(search))       cmd.Parameters.AddWithValue("@search", "%"+search+"%");
        };

        int totalCount = 0;
        using (var cn = Conn())
        {
            string cntSql = $"SELECT COUNT(*) FROM [REMEDY_Info].[dbo].[GOALogins] {where}";
            using (var cmd = new SqlCommand(cntSql, cn)) { addPrms(cmd); totalCount = (int)cmd.ExecuteScalar(); }
        }

        int offset = (page - 1) * pageSize;
        var rows = new List<Dictionary<string,object>>();

        string dataSql = $@"
SELECT Id, LogonDate, LogonTime, LogonWeekday,
       LastLogonID, MachineName, Event, AdsSiteName,
       LogonServer, MachineOS, NetworkInfoPrimaryIP, UserDistinguishedName
FROM [REMEDY_Info].[dbo].[GOALogins]
{where}
ORDER BY LogonDate DESC, LogonTime DESC
OFFSET {offset} ROWS FETCH NEXT {pageSize} ROWS ONLY";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(dataSql, cn))
        {
            addPrms(cmd);
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                    rows.Add(new Dictionary<string,object> {
                        ["id"]      = r["Id"],
                        ["date"]    = DateStr(r,"LogonDate"),
                        ["time"]    = S(r,"LogonTime"),
                        ["weekday"] = S(r,"LogonWeekday"),
                        ["user"]    = S(r,"LastLogonID"),
                        ["machine"] = S(r,"MachineName"),
                        ["event"]   = S(r,"Event"),
                        ["site"]    = S(r,"AdsSiteName"),
                        ["server"]  = S(r,"LogonServer"),
                        ["os"]      = S(r,"MachineOS"),
                        ["ip"]      = S(r,"NetworkInfoPrimaryIP"),
                        ["dn"]      = S(r,"UserDistinguishedName")
                    });
        }

        return new {
            rows, totalCount, page, pageSize,
            totalPages = (int)Math.Ceiling((double)totalCount / pageSize)
        };
    }

    // ======================================================================
    //  USER SEARCH
    // ======================================================================
    private object GetUserSearch(HttpContext ctx)
    {
        string q   = P(ctx, "q");
        var from   = DateP(ctx, "from", DateTime.Now.AddYears(-1));
        var to     = DateP(ctx, "to",   DateTime.Now);

        if (string.IsNullOrEmpty(q)) return new { users = new List<object>() };

        string sqlQ = q.Replace("*", "%");
        if (!sqlQ.Contains("%")) sqlQ = "%" + sqlQ + "%";

        const string sql = @"
SELECT TOP 50
    LastLogonID, UserDistinguishedName,
    COUNT(*)                                                                     AS TotalLogins,
    MIN(CAST(LogonDate AS DATE))                                                 AS FirstSeen,
    MAX(CAST(LogonDate AS DATE))                                                 AS LastSeen,
    COUNT(DISTINCT MachineName)                                                  AS MachinesUsed,
    COUNT(DISTINCT AdsSiteName)                                                  AS SitesUsed,
    SUM(CASE WHEN Event LIKE '%VPN%' THEN 1 ELSE 0 END)                         AS VPNSessions,
    SUM(CASE WHEN (
            CAST(TRY_CONVERT(time, LogonTime) AS TIME) < '06:00:00'
         OR CAST(TRY_CONVERT(time, LogonTime) AS TIME) > '20:00:00'
         OR LogonWeekday IN ('Saturday','Sunday')
    ) THEN 1 ELSE 0 END)                                                         AS AfterHours
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
  AND (LastLogonID LIKE @q OR UserDistinguishedName LIKE @q OR MachineName LIKE @q)
GROUP BY LastLogonID, UserDistinguishedName
ORDER BY TotalLogins DESC";

        var users = new List<Dictionary<string,object>>();
        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to",   to);
            cmd.Parameters.AddWithValue("@q",    sqlQ);
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                    users.Add(new Dictionary<string,object> {
                        ["logonId"]      = S(r,"LastLogonID"),
                        ["dn"]           = S(r,"UserDistinguishedName"),
                        ["totalLogins"]  = L(r,"TotalLogins"),
                        ["firstSeen"]    = DateStr(r,"FirstSeen"),
                        ["lastSeen"]     = DateStr(r,"LastSeen"),
                        ["machinesUsed"] = I(r,"MachinesUsed"),
                        ["sitesUsed"]    = I(r,"SitesUsed"),
                        ["vpnSessions"]  = I(r,"VPNSessions"),
                        ["afterHours"]   = I(r,"AfterHours")
                    });
        }
        return new { users };
    }

    // ======================================================================
    //  USER PROFILE  — charts + login events for a specific user
    // ======================================================================
    private object GetUserProfile(HttpContext ctx)
    {
        string userId = P(ctx, "userId");
        var from = DateP(ctx, "from", DateTime.Now.AddYears(-1));
        var to   = DateP(ctx, "to",   DateTime.Now);

        if (string.IsNullOrEmpty(userId)) return new { error = "userId required" };

        var monthLabels = new List<string>(); var monthData = new List<long>();
        var hourData    = new long[24];
        var machLabels  = new List<string>(); var machData = new List<long>();
        var events      = new List<Dictionary<string,object>>();

        using (var cn = Conn())
        {
            // Monthly trend
            const string monthlySql = @"
SELECT YEAR(LogonDate) AS Yr, MONTH(LogonDate) AS Mo, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LastLogonID = @u AND LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
GROUP BY YEAR(LogonDate), MONTH(LogonDate) ORDER BY Yr, Mo";
            using (var cmd = new SqlCommand(monthlySql, cn))
            {
                cmd.Parameters.AddWithValue("@u",    userId);
                cmd.Parameters.AddWithValue("@from", from);
                cmd.Parameters.AddWithValue("@to",   to);
                using (var r = cmd.ExecuteReader())
                    while (r.Read())
                    {
                        monthLabels.Add($"{r["Yr"]}-{Convert.ToInt32(r["Mo"]):00}");
                        monthData.Add(L(r,"Cnt"));
                    }
            }

            // Hourly distribution
            const string hourlySql = @"
SELECT DATEPART(hour, TRY_CONVERT(time, LogonTime)) AS Hr, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LastLogonID = @u AND LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
GROUP BY DATEPART(hour, TRY_CONVERT(time, LogonTime))";
            using (var cmd = new SqlCommand(hourlySql, cn))
            {
                cmd.Parameters.AddWithValue("@u",    userId);
                cmd.Parameters.AddWithValue("@from", from);
                cmd.Parameters.AddWithValue("@to",   to);
                using (var r = cmd.ExecuteReader())
                    while (r.Read())
                        if (!r.IsDBNull(0)) { int h = Convert.ToInt32(r["Hr"]); if (h>=0&&h<24) hourData[h] = L(r,"Cnt"); }
            }

            // Machines used
            const string machSql = @"
SELECT TOP 8 MachineName, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LastLogonID = @u AND LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
GROUP BY MachineName ORDER BY Cnt DESC";
            using (var cmd = new SqlCommand(machSql, cn))
            {
                cmd.Parameters.AddWithValue("@u",    userId);
                cmd.Parameters.AddWithValue("@from", from);
                cmd.Parameters.AddWithValue("@to",   to);
                using (var r = cmd.ExecuteReader())
                    while (r.Read()) { machLabels.Add(S(r,"MachineName")); machData.Add(L(r,"Cnt")); }
            }

            // Recent login events
            const string evSql = @"
SELECT TOP 200 LogonDate, LogonTime, LogonWeekday, MachineName,
               Event, LogonServer, AdsSiteName, NetworkInfoPrimaryIP, MachineOS
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LastLogonID = @u AND LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
ORDER BY LogonDate DESC, LogonTime DESC";
            using (var cmd = new SqlCommand(evSql, cn))
            {
                cmd.Parameters.AddWithValue("@u",    userId);
                cmd.Parameters.AddWithValue("@from", from);
                cmd.Parameters.AddWithValue("@to",   to);
                using (var r = cmd.ExecuteReader())
                    while (r.Read())
                        events.Add(new Dictionary<string,object> {
                            ["date"]    = DateStr(r,"LogonDate"),
                            ["time"]    = S(r,"LogonTime"),
                            ["weekday"] = S(r,"LogonWeekday"),
                            ["machine"] = S(r,"MachineName"),
                            ["event"]   = S(r,"Event"),
                            ["server"]  = S(r,"LogonServer"),
                            ["site"]    = S(r,"AdsSiteName"),
                            ["ip"]      = S(r,"NetworkInfoPrimaryIP"),
                            ["os"]      = S(r,"MachineOS")
                        });
            }
        }

        var hourLabels = new List<string>();
        for (int i=0;i<24;i++) hourLabels.Add(i.ToString("00")+"h");

        return new {
            monthlyChart = new { labels = monthLabels, data = monthData },
            hourlyChart  = new { labels = hourLabels,  data = hourData  },
            machineChart = new { labels = machLabels,  data = machData  },
            events
        };
    }

    // ======================================================================
    //  ANOMALIES
    // ======================================================================
    private object GetAnomalies(HttpContext ctx)
    {
        var from = DateP(ctx, "from", DateTime.Now.AddDays(-30));
        var to   = DateP(ctx, "to",   DateTime.Now);

        var alerts = new List<Dictionary<string,object>>();

        using (var cn = Conn())
        {
            // After-hours
            const string ahSql = @"
SELECT TOP 25 Id, LastLogonID, MachineName,
    CAST(LogonDate AS DATE) AS LogDate, LogonTime, AdsSiteName, Event, LogonWeekday
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
  AND (
      CAST(TRY_CONVERT(time, LogonTime) AS TIME) < '06:00:00'
   OR CAST(TRY_CONVERT(time, LogonTime) AS TIME) > '20:00:00'
   OR LogonWeekday IN ('Saturday','Sunday')
  )
ORDER BY LogonDate DESC, LogonTime DESC";
            using (var cmd = new SqlCommand(ahSql, cn))
            {
                cmd.Parameters.AddWithValue("@from", from);
                cmd.Parameters.AddWithValue("@to",   to);
                using (var r = cmd.ExecuteReader())
                    while (r.Read())
                        alerts.Add(new Dictionary<string,object> {
                            ["type"]     = "After-Hours",
                            ["severity"] = "warning",
                            ["user"]     = S(r,"LastLogonID"),
                            ["machine"]  = S(r,"MachineName"),
                            ["date"]     = DateStr(r,"LogDate"),
                            ["time"]     = S(r,"LogonTime"),
                            ["site"]     = S(r,"AdsSiteName"),
                            ["event"]    = S(r,"Event"),
                            ["detail"]   = $"Login outside business hours by {S(r,"LastLogonID")} on {S(r,"MachineName")} ({S(r,"LogonWeekday")} {S(r,"LogonTime")})"
                        });
            }

            // Multi-site same day
            const string msSql = @"
SELECT TOP 15
    LastLogonID, CAST(LogonDate AS DATE) AS LogDate,
    COUNT(DISTINCT AdsSiteName) AS SiteCount
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to) AND AdsSiteName IS NOT NULL
GROUP BY LastLogonID, CAST(LogonDate AS DATE)
HAVING COUNT(DISTINCT AdsSiteName) >= 2
ORDER BY LogDate DESC, SiteCount DESC";
            using (var cmd = new SqlCommand(msSql, cn))
            {
                cmd.Parameters.AddWithValue("@from", from);
                cmd.Parameters.AddWithValue("@to",   to);
                using (var r = cmd.ExecuteReader())
                    while (r.Read())
                        alerts.Add(new Dictionary<string,object> {
                            ["type"]      = "Multi-Site",
                            ["severity"]  = "critical",
                            ["user"]      = S(r,"LastLogonID"),
                            ["date"]      = DateStr(r,"LogDate"),
                            ["siteCount"] = I(r,"SiteCount"),
                            ["detail"]    = $"User {S(r,"LastLogonID")} logged in from {I(r,"SiteCount")} different sites on {DateStr(r,"LogDate")}"
                        });
            }

            // High-frequency
            const string hfSql = @"
SELECT TOP 10
    LastLogonID, CAST(LogonDate AS DATE) AS LogDate, COUNT(*) AS LoginCount
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
GROUP BY LastLogonID, CAST(LogonDate AS DATE)
HAVING COUNT(*) > 100
ORDER BY LoginCount DESC";
            using (var cmd = new SqlCommand(hfSql, cn))
            {
                cmd.Parameters.AddWithValue("@from", from);
                cmd.Parameters.AddWithValue("@to",   to);
                using (var r = cmd.ExecuteReader())
                    while (r.Read())
                        alerts.Add(new Dictionary<string,object> {
                            ["type"]       = "High-Frequency",
                            ["severity"]   = "warning",
                            ["user"]       = S(r,"LastLogonID"),
                            ["date"]       = DateStr(r,"LogDate"),
                            ["loginCount"] = I(r,"LoginCount"),
                            ["detail"]     = $"User {S(r,"LastLogonID")} had {I(r,"LoginCount")} logins on {DateStr(r,"LogDate")} — possible shared/service account"
                        });
            }
        }

        // Anomaly trend (after-hours count per day, last 30 days)
        var trendLabels = new List<string>(); var trendData = new List<int>();
        const string trendSql = @"
SELECT CAST(LogonDate AS DATE) AS Day, COUNT(*) AS Cnt
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= DATEADD(day,-30,GETDATE())
  AND (
      CAST(TRY_CONVERT(time, LogonTime) AS TIME) < '06:00:00'
   OR CAST(TRY_CONVERT(time, LogonTime) AS TIME) > '20:00:00'
   OR LogonWeekday IN ('Saturday','Sunday')
  )
GROUP BY CAST(LogonDate AS DATE) ORDER BY Day";
        using (var cn = Conn())
        using (var cmd = new SqlCommand(trendSql, cn))
        using (var r = cmd.ExecuteReader())
            while (r.Read()) { trendLabels.Add(DateStr(r,"Day")); trendData.Add(I(r,"Cnt")); }

        int critCount = 0, warnCount = 0, ahCount = 0, msCount = 0, hfCount = 0;
        foreach (var a in alerts)
        {
            string t = a["type"].ToString(); string s = a["severity"].ToString();
            if (s == "critical") critCount++; else warnCount++;
            if (t == "After-Hours") ahCount++;
            else if (t == "Multi-Site") msCount++;
            else if (t == "High-Frequency") hfCount++;
        }

        return new {
            alerts,
            counts = new { critical=critCount, warning=warnCount, afterHours=ahCount, multiSite=msCount, highFrequency=hfCount },
            trend  = new { labels=trendLabels, data=trendData }
        };
    }

    // ======================================================================
    //  MACHINES
    // ======================================================================
    private object GetMachines(HttpContext ctx)
    {
        var from     = DateP(ctx, "from",   DateTime.Now.AddYears(-1));
        var to       = DateP(ctx, "to",     DateTime.Now);
        string search= P(ctx, "search");
        string os    = P(ctx, "os");
        int page     = Math.Max(1, IntP(ctx, "page", 1));
        int pageSize = 50;

        var where = new StringBuilder("WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)");
        if (!string.IsNullOrEmpty(search)) where.Append(" AND (MachineName LIKE @search OR MachineDistinguishedName LIKE @search)");
        if (!string.IsNullOrEmpty(os))     where.Append(" AND MachineOS = @os");

        Action<SqlCommand> addPrms = cmd =>
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to",   to);
            if (!string.IsNullOrEmpty(search)) cmd.Parameters.AddWithValue("@search", "%"+search+"%");
            if (!string.IsNullOrEmpty(os))     cmd.Parameters.AddWithValue("@os",     os);
        };

        int total = 0;
        using (var cn = Conn())
        using (var cmd = new SqlCommand($"SELECT COUNT(DISTINCT MachineName) FROM [REMEDY_Info].[dbo].[GOALogins] {where}", cn))
        { addPrms(cmd); total = (int)cmd.ExecuteScalar(); }

        int offset = (page - 1) * pageSize;
        var rows = new List<Dictionary<string,object>>();

        string dataSql = $@"
SELECT MachineName, MachineOS, AdsSiteName,
    COUNT(*)                       AS TotalLogins,
    COUNT(DISTINCT LastLogonID)    AS UniqueUsers,
    MAX(CAST(LogonDate AS DATE))   AS LastLogin,
    MAX(LastLogonID)               AS LastUser
FROM [REMEDY_Info].[dbo].[GOALogins]
{where}
GROUP BY MachineName, MachineOS, AdsSiteName
ORDER BY TotalLogins DESC
OFFSET {offset} ROWS FETCH NEXT {pageSize} ROWS ONLY";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(dataSql, cn))
        {
            addPrms(cmd);
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                    rows.Add(new Dictionary<string,object> {
                        ["machine"]     = S(r,"MachineName"),
                        ["os"]          = S(r,"MachineOS"),
                        ["site"]        = S(r,"AdsSiteName"),
                        ["totalLogins"] = I(r,"TotalLogins"),
                        ["uniqueUsers"] = I(r,"UniqueUsers"),
                        ["lastLogin"]   = DateStr(r,"LastLogin"),
                        ["lastUser"]    = S(r,"LastUser")
                    });
        }
        return new { rows, total, page, pageSize, totalPages = (int)Math.Ceiling((double)total/pageSize) };
    }

    // ======================================================================
    //  SUBNETS
    // ======================================================================
    private object GetSubnets(HttpContext ctx)
    {
        var from = DateP(ctx, "from", DateTime.Now.AddYears(-1));
        var to   = DateP(ctx, "to",   DateTime.Now);

        var rows = new List<Dictionary<string,object>>();

        const string sql = @"
SELECT TOP 50
    COALESCE(NetworkInfoPrimarySubnet,'Unknown')   AS Subnet,
    COALESCE(NetworkInfoPrimaryMask,'')            AS Mask,
    COALESCE(NetworkInfoPrimaryHostName,'')        AS HostName,
    COALESCE(AdsSiteName,'Unknown')                AS Site,
    COUNT(*)                                        AS LoginCount,
    COUNT(DISTINCT LastLogonID)                     AS UniqueUsers,
    MAX(CAST(LogonDate AS DATE))                    AS LastActivity
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE LogonDate >= @from AND LogonDate < DATEADD(day,1,@to)
GROUP BY NetworkInfoPrimarySubnet, NetworkInfoPrimaryMask, NetworkInfoPrimaryHostName, AdsSiteName
ORDER BY LoginCount DESC";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to",   to);
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                    rows.Add(new Dictionary<string,object> {
                        ["subnet"]       = S(r,"Subnet"),
                        ["mask"]         = S(r,"Mask"),
                        ["hostName"]     = S(r,"HostName"),
                        ["site"]         = S(r,"Site"),
                        ["loginCount"]   = I(r,"LoginCount"),
                        ["uniqueUsers"]  = I(r,"UniqueUsers"),
                        ["lastActivity"] = DateStr(r,"LastActivity")
                    });
        }
        return new { rows };
    }

    // ======================================================================
    //  COMPARISON
    // ======================================================================
    private object GetComparison(HttpContext ctx)
    {
        string type    = P(ctx, "type", "user");   // user | site | machine | period
        string entityA = P(ctx, "a");
        string entityB = P(ctx, "b");
        var from = DateP(ctx, "from", DateTime.Now.AddYears(-1));
        var to   = DateP(ctx, "to",   DateTime.Now);

        if (string.IsNullOrEmpty(entityA) || string.IsNullOrEmpty(entityB))
            return new { error = "Both entity A and B are required." };

        string col = type == "site" ? "AdsSiteName" : type == "machine" ? "MachineName" : "LastLogonID";

        // If period comparison, entityA = year A, entityB = year B
        if (type == "period")
        {
            int yearA, yearB;
            if (!int.TryParse(entityA, out yearA) || !int.TryParse(entityB, out yearB))
                return new { error = "Period comparison requires 4-digit years." };

            return ComparePeriods(yearA, yearB);
        }

        var chartLabels = new List<string>(); var chartDataA = new List<long>(); var chartDataB = new List<long>();
        var hourDataA   = new long[24]; var hourDataB = new long[24];
        var weekDataA   = new long[7]; var weekDataB  = new long[7];
        object statsA = null, statsB = null;

        using (var cn = Conn())
        {
            // Stats helper
            Func<string, object> getStats = entity =>
            {
                string s = $@"
SELECT COUNT(*) AS TotalLogins, COUNT(DISTINCT CAST(LogonDate AS DATE)) AS ActiveDays,
    COUNT(DISTINCT MachineName) AS UniqueMachines,
    SUM(CASE WHEN Event LIKE '%VPN%' THEN 1 ELSE 0 END) AS VPNSessions,
    SUM(CASE WHEN CAST(TRY_CONVERT(time,LogonTime) AS TIME)<'06:00:00' OR CAST(TRY_CONVERT(time,LogonTime) AS TIME)>'20:00:00' THEN 1 ELSE 0 END) AS AfterHours
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE {col}=@entity AND LogonDate>=@from AND LogonDate<DATEADD(day,1,@to)";
                using (var cmd = new SqlCommand(s, cn))
                {
                    cmd.Parameters.AddWithValue("@entity", entity);
                    cmd.Parameters.AddWithValue("@from",   from);
                    cmd.Parameters.AddWithValue("@to",     to);
                    using (var r = cmd.ExecuteReader())
                        if (r.Read())
                            return new { totalLogins=L(r,"TotalLogins"), activeDays=I(r,"ActiveDays"), uniqueMachines=I(r,"UniqueMachines"), vpnSessions=I(r,"VPNSessions"), afterHours=I(r,"AfterHours") };
                }
                return new {};
            };

            statsA = getStats(entityA);
            statsB = getStats(entityB);

            // Monthly chart
            string mSql = $@"
SELECT YEAR(LogonDate) AS Yr, MONTH(LogonDate) AS Mo,
    SUM(CASE WHEN {col}=@a THEN 1 ELSE 0 END) AS CntA,
    SUM(CASE WHEN {col}=@b THEN 1 ELSE 0 END) AS CntB
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE ({col}=@a OR {col}=@b) AND LogonDate>=@from AND LogonDate<DATEADD(day,1,@to)
GROUP BY YEAR(LogonDate),MONTH(LogonDate) ORDER BY Yr,Mo";
            using (var cmd = new SqlCommand(mSql, cn))
            {
                cmd.Parameters.AddWithValue("@a", entityA); cmd.Parameters.AddWithValue("@b", entityB);
                cmd.Parameters.AddWithValue("@from", from);  cmd.Parameters.AddWithValue("@to",   to);
                using (var r = cmd.ExecuteReader())
                    while (r.Read()) { chartLabels.Add($"{r["Yr"]}-{Convert.ToInt32(r["Mo"]):00}"); chartDataA.Add(L(r,"CntA")); chartDataB.Add(L(r,"CntB")); }
            }

            // Hourly
            string hSql = $@"
SELECT DATEPART(hour,TRY_CONVERT(time,LogonTime)) AS Hr,
    SUM(CASE WHEN {col}=@a THEN 1 ELSE 0 END) AS CntA,
    SUM(CASE WHEN {col}=@b THEN 1 ELSE 0 END) AS CntB
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE ({col}=@a OR {col}=@b) AND LogonDate>=@from AND LogonDate<DATEADD(day,1,@to)
GROUP BY DATEPART(hour,TRY_CONVERT(time,LogonTime))";
            using (var cmd = new SqlCommand(hSql, cn))
            {
                cmd.Parameters.AddWithValue("@a", entityA); cmd.Parameters.AddWithValue("@b", entityB);
                cmd.Parameters.AddWithValue("@from", from);  cmd.Parameters.AddWithValue("@to",   to);
                using (var r = cmd.ExecuteReader())
                    while (r.Read())
                        if (!r.IsDBNull(0)) { int h=Convert.ToInt32(r["Hr"]); if (h>=0&&h<24) { hourDataA[h]=L(r,"CntA"); hourDataB[h]=L(r,"CntB"); } }
            }

            // Weekday
            var wo = new[]{"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
            var wi = new Dictionary<string,int>{{"Monday",0},{"Tuesday",1},{"Wednesday",2},{"Thursday",3},{"Friday",4},{"Saturday",5},{"Sunday",6}};
            string wSql = $@"
SELECT LogonWeekday,
    SUM(CASE WHEN {col}=@a THEN 1 ELSE 0 END) AS CntA,
    SUM(CASE WHEN {col}=@b THEN 1 ELSE 0 END) AS CntB
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE ({col}=@a OR {col}=@b) AND LogonDate>=@from AND LogonDate<DATEADD(day,1,@to)
GROUP BY LogonWeekday";
            using (var cmd = new SqlCommand(wSql, cn))
            {
                cmd.Parameters.AddWithValue("@a", entityA); cmd.Parameters.AddWithValue("@b", entityB);
                cmd.Parameters.AddWithValue("@from", from);  cmd.Parameters.AddWithValue("@to",   to);
                using (var r = cmd.ExecuteReader())
                    while (r.Read())
                    {
                        string d = S(r,"LogonWeekday");
                        if (wi.ContainsKey(d)) { weekDataA[wi[d]]=L(r,"CntA"); weekDataB[wi[d]]=L(r,"CntB"); }
                    }
            }
        }

        var hLabels = new List<string>(); for (int i=0;i<24;i++) hLabels.Add(i.ToString("00")+"h");

        return new {
            statsA, statsB,
            chart   = new { labels=chartLabels, dataA=chartDataA, dataB=chartDataB },
            hourly  = new { labels=hLabels, dataA=hourDataA, dataB=hourDataB },
            weekly  = new { labels=new[]{"Mon","Tue","Wed","Thu","Fri","Sat","Sun"}, dataA=weekDataA, dataB=weekDataB }
        };
    }

    private object ComparePeriods(int yearA, int yearB)
    {
        var labels = new List<string>(); var dataA = new List<long>(); var dataB = new List<long>();

        const string sql = @"
SELECT MONTH(LogonDate) AS Mo,
    SUM(CASE WHEN YEAR(LogonDate)=@a THEN 1 ELSE 0 END) AS CntA,
    SUM(CASE WHEN YEAR(LogonDate)=@b THEN 1 ELSE 0 END) AS CntB
FROM [REMEDY_Info].[dbo].[GOALogins]
WHERE YEAR(LogonDate) IN (@a,@b)
GROUP BY MONTH(LogonDate) ORDER BY Mo";

        using (var cn = Conn())
        using (var cmd = new SqlCommand(sql, cn))
        {
            cmd.Parameters.AddWithValue("@a", yearA);
            cmd.Parameters.AddWithValue("@b", yearB);
            using (var r = cmd.ExecuteReader())
                while (r.Read())
                {
                    labels.Add(new DateTime(2000,Convert.ToInt32(r["Mo"]),1).ToString("MMM"));
                    dataA.Add(L(r,"CntA")); dataB.Add(L(r,"CntB"));
                }
        }
        return new { chart = new { labels, dataA, dataB } };
    }
}
