-- ============================================================
-- GOA Login Forensics — SQL Server Permission Setup
-- Run this on SQL-PROD-01 as sysadmin ONCE before deploying
-- the dashboard.
--
-- Creates a read-only login for the IIS App Pool service account
-- and grants the minimum permissions needed by the API.
-- ============================================================

USE [master];
GO

-- ── 1. Create Windows Login for the IIS service account ──────
-- Replace GOA\svc_goaforensics with your actual domain service account.
-- If using ApplicationPoolIdentity, the login name is:
--   IIS APPPOOL\GOALoginForensics-Pool
-- (create the site first so the virtual account exists)

IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'GOA\svc_goaforensics')
BEGIN
    CREATE LOGIN [GOA\svc_goaforensics] FROM WINDOWS
        WITH DEFAULT_DATABASE = [REMEDY_Info];
    PRINT 'Login GOA\svc_goaforensics created.';
END
ELSE
    PRINT 'Login GOA\svc_goaforensics already exists.';
GO

-- ── 2. Create database user in REMEDY_Info ───────────────────
USE [REMEDY_Info];
GO

IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'svc_goaforensics')
BEGIN
    CREATE USER [svc_goaforensics] FOR LOGIN [GOA\svc_goaforensics]
        WITH DEFAULT_SCHEMA = [dbo];
    PRINT 'Database user svc_goaforensics created.';
END
ELSE
    PRINT 'Database user svc_goaforensics already exists.';
GO

-- ── 3. Grant minimum read-only permissions ───────────────────
-- db_datareader: SELECT on all tables/views in the database.
-- Do NOT grant db_datawriter, db_owner, or any DDL permissions.

ALTER ROLE [db_datareader] ADD MEMBER [svc_goaforensics];
PRINT 'db_datareader granted to svc_goaforensics.';
GO

-- ── 4. Explicit EXECUTE on needed system functions (if required) ──
-- Typically not needed for SELECT-only workload, but included for
-- DATEPART / STRING_AGG which are built-in and require no grant.

-- ── 5. Deny write and schema change to be explicit ───────────
DENY INSERT ON SCHEMA::dbo TO [svc_goaforensics];
DENY UPDATE ON SCHEMA::dbo TO [svc_goaforensics];
DENY DELETE ON SCHEMA::dbo TO [svc_goaforensics];
DENY ALTER  ON SCHEMA::dbo TO [svc_goaforensics];
PRINT 'Write permissions explicitly denied.';
GO

-- ── 6. Verify ────────────────────────────────────────────────
SELECT
    dp.name                              AS DatabaseUser,
    dp.type_desc                         AS UserType,
    r.name                               AS RoleMember
FROM sys.database_role_members drm
JOIN sys.database_principals r  ON drm.role_principal_id  = r.principal_id
JOIN sys.database_principals dp ON drm.member_principal_id = dp.principal_id
WHERE dp.name = N'svc_goaforensics';

-- ── 7. Quick access test ─────────────────────────────────────
EXECUTE AS USER = 'svc_goaforensics';
    SELECT TOP 1 Id, LastLogonID, LogonDate FROM [dbo].[GOALogins] WITH (NOLOCK);
    PRINT 'Read access confirmed for svc_goaforensics.';
REVERT;
GO

PRINT '======================================================';
PRINT 'DB permission setup complete.';
PRINT 'Run Test-GOASQLConnection.ps1 from the IIS server next.';
PRINT '======================================================';
