#Requires -RunAsAdministrator
#Requires -Version 5.1
<#
.SYNOPSIS
    Installs and configures the GOA Login Forensics Dashboard on IIS.

.DESCRIPTION
    This script:
      1. Installs required Windows Features (IIS + ASP.NET Core Hosting)
      2. Creates the IIS Site and Application Pool
      3. Deploys the static dashboard and .NET 8 API
      4. Configures Windows Authentication (AD pass-through)
      5. Sets NTFS permissions for the service account
      6. Creates a Windows Firewall rule for the intranet port
      7. Optionally binds an HTTPS certificate

.PARAMETER SiteName
    IIS site name. Default: GOALoginForensics

.PARAMETER PhysicalPath
    Root folder for IIS content. Default: C:\inetpub\GOALoginForensics

.PARAMETER Port
    HTTP port. Default: 8080 (avoids conflict with Default Web Site on 80)

.PARAMETER HostName
    DNS hostname for the IIS binding. Default: goaforensics.gov.ab.ca

.PARAMETER SqlServer
    SQL Server hostname for the connection string. Default: SQL-PROD-01

.PARAMETER AppPoolUser
    Domain service account for the App Pool (Integrated Security).
    Format: DOMAIN\svc_goaforensics
    If blank, uses ApplicationPoolIdentity (NetworkService-like, less privileged).

.PARAMETER AppPoolPassword
    Password for AppPoolUser. Leave blank if using AppPoolIdentity.

.PARAMETER CertThumbprint
    If provided, binds an HTTPS listener on port 443 using this cert.

.EXAMPLE
    .\Install-GOAForensicsDashboard.ps1 `
        -SqlServer "SQL-PROD-01" `
        -AppPoolUser "GOA\svc_goaforensics" `
        -AppPoolPassword "P@ssw0rd123!" `
        -HostName "goaforensics.gov.ab.ca"
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$SiteName      = "GOALoginForensics",
    [string]$PhysicalPath  = "C:\inetpub\GOALoginForensics",
    [int]   $Port          = 8080,
    [string]$HostName      = "goaforensics.gov.ab.ca",
    [string]$SqlServer     = "SQL-PROD-01",
    [string]$AppPoolUser   = "",
    [string]$AppPoolPassword = "",
    [string]$CertThumbprint  = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ── Banner ────────────────────────────────────────────────────
Write-Host ""
Write-Host "╔══════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║   GOA Login Forensics Dashboard — IIS Installer      ║" -ForegroundColor Cyan
Write-Host "║   Alberta Government — Domain Forensics Platform      ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# ════════════════════════════════════════════════════════════════
# STEP 1 — Install Windows Features
# ════════════════════════════════════════════════════════════════
Write-Host "[1/8] Installing Windows Features..." -ForegroundColor Yellow

$features = @(
    "Web-Server",                    # IIS base
    "Web-Default-Doc",               # Default documents
    "Web-Dir-Browsing",              # (we disable it; still need the feature)
    "Web-Http-Errors",               # Custom error pages
    "Web-Static-Content",            # Serve HTML/CSS/JS
    "Web-Http-Logging",              # W3C logs
    "Web-Request-Monitor",           # Runtime state
    "Web-Stat-Compression",          # Static gzip
    "Web-Dyn-Compression",           # Dynamic gzip
    "Web-Filtering",                 # Request filtering
    "Web-Windows-Auth",              # AD / Kerberos auth
    "Web-Mgmt-Console",              # IIS Manager GUI
    "Web-Scripting-Tools",           # WebAdministration PowerShell module
    "Web-Url-Auth"                   # URL Authorization
)

foreach ($f in $features) {
    $state = (Get-WindowsFeature -Name $f).InstallState
    if ($state -ne "Installed") {
        Write-Host "   Installing $f ..." -NoNewline
        Install-WindowsFeature -Name $f -IncludeManagementTools | Out-Null
        Write-Host " OK" -ForegroundColor Green
    } else {
        Write-Host "   $f already installed." -ForegroundColor DarkGray
    }
}

# Check / install URL Rewrite 2.x (download if missing)
$rewriteDll = "$env:SystemRoot\system32\inetsrv\rewrite.dll"
if (-not (Test-Path $rewriteDll)) {
    Write-Host "   URL Rewrite 2.x not found. Downloading..." -ForegroundColor Yellow
    $rewriteUrl  = "https://download.microsoft.com/download/1/2/8/128E2E22-C1B9-44A4-BE2A-5859ED1D4592/rewrite_amd64_en-US.msi"
    $rewriteMsi  = "$env:TEMP\rewrite_amd64.msi"
    Invoke-WebRequest -Uri $rewriteUrl -OutFile $rewriteMsi -UseBasicParsing
    Start-Process msiexec.exe -ArgumentList "/i `"$rewriteMsi`" /qn" -Wait
    Write-Host "   URL Rewrite installed." -ForegroundColor Green
}

Write-Host "[1/8] Windows Features ready." -ForegroundColor Green

# ════════════════════════════════════════════════════════════════
# STEP 2 — .NET 8 ASP.NET Core Hosting Bundle
# ════════════════════════════════════════════════════════════════
Write-Host "[2/8] Checking .NET 8 Hosting Bundle..." -ForegroundColor Yellow

$dotnet = & dotnet --list-runtimes 2>$null | Where-Object { $_ -match "Microsoft.AspNetCore.App 8\." }
if (-not $dotnet) {
    Write-Host "   Downloading .NET 8 Hosting Bundle..." -ForegroundColor Yellow
    $bundleUrl = "https://download.microsoft.com/download/dotnet/8.0/dotnet-hosting-8.0.0-win.exe"
    $bundleExe = "$env:TEMP\dotnet-hosting-8.exe"
    Invoke-WebRequest -Uri $bundleUrl -OutFile $bundleExe -UseBasicParsing
    Start-Process $bundleExe -ArgumentList "/quiet /norestart" -Wait
    & net stop was /y 2>$null | Out-Null
    & net start w3svc   2>$null | Out-Null
    Write-Host "   .NET 8 Hosting Bundle installed." -ForegroundColor Green
} else {
    Write-Host "   .NET 8 runtime found." -ForegroundColor DarkGray
}

# ════════════════════════════════════════════════════════════════
# STEP 3 — Create Directory Structure
# ════════════════════════════════════════════════════════════════
Write-Host "[3/8] Creating directory structure..." -ForegroundColor Yellow

$dirs = @(
    "$PhysicalPath\wwwroot",
    "$PhysicalPath\api",
    "$PhysicalPath\logs",
    "$PhysicalPath\config",
    "$PhysicalPath\wwwroot\errors"
)
foreach ($d in $dirs) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

# Copy source files (assumes script is run from the repo root)
$scriptDir = Split-Path $MyInvocation.MyCommand.Path -Parent
$repoRoot  = Split-Path $scriptDir -Parent

Write-Host "   Copying wwwroot files..." -NoNewline
Copy-Item "$repoRoot\wwwroot\*" "$PhysicalPath\wwwroot\" -Recurse -Force
Write-Host " OK" -ForegroundColor Green

Write-Host "   Copying API publish output..." -NoNewline
# Build and publish the API first (requires dotnet SDK on build machine)
$apiSrc = "$repoRoot\api"
if (Test-Path "$apiSrc\GOALoginForensicsApi.csproj") {
    Push-Location $apiSrc
    & dotnet publish -c Release -o "$PhysicalPath\api" --no-self-contained | Out-Null
    Pop-Location
    Write-Host " OK (published)" -ForegroundColor Green
} else {
    Copy-Item "$repoRoot\api\*" "$PhysicalPath\api\" -Recurse -Force
    Write-Host " OK (copied)" -ForegroundColor Green
}

# Generate simple error pages
@(400,401,403,404,500) | ForEach-Object {
    $msg = switch ($_) {
        400 { "Bad Request" } 401 { "Unauthorised" } 403 { "Access Denied" }
        404 { "Page Not Found" } 500 { "Internal Server Error" }
    }
    @"
<!DOCTYPE html><html><head><title>$_ $msg</title>
<style>body{background:#0a0e1a;color:#e2e8f0;font-family:monospace;padding:60px;}</style>
</head><body><h1 style="color:#00c8ff">$_</h1><p>$msg</p>
<p style="color:#64748b">GOA Login Forensics — Contact the Service Desk if this persists.</p>
</body></html>
"@ | Set-Content "$PhysicalPath\wwwroot\errors\$_.html" -Encoding UTF8
}

Write-Host "[3/8] Directory structure ready." -ForegroundColor Green

# ════════════════════════════════════════════════════════════════
# STEP 4 — Update Connection String in appsettings.json
# ════════════════════════════════════════════════════════════════
Write-Host "[4/8] Writing connection string..." -ForegroundColor Yellow

$appSettings = "$PhysicalPath\api\appsettings.json"
if (Test-Path $appSettings) {
    $json = Get-Content $appSettings -Raw | ConvertFrom-Json
    $connStr = "Server=$SqlServer;Database=REMEDY_Info;Integrated Security=True;TrustServerCertificate=True;Connection Timeout=30;"
    $json.ConnectionStrings.GOALogins = $connStr
    $json | ConvertTo-Json -Depth 10 | Set-Content $appSettings -Encoding UTF8
    Write-Host "   Connection string written: $connStr" -ForegroundColor DarkGray
}

Write-Host "[4/8] Connection string configured." -ForegroundColor Green

# ════════════════════════════════════════════════════════════════
# STEP 5 — IIS App Pool
# ════════════════════════════════════════════════════════════════
Write-Host "[5/8] Configuring IIS App Pool..." -ForegroundColor Yellow

Import-Module WebAdministration -ErrorAction Stop

$poolName = "$SiteName-Pool"
if (-not (Test-Path "IIS:\AppPools\$poolName")) {
    New-WebAppPool -Name $poolName | Out-Null
}

$pool = Get-Item "IIS:\AppPools\$poolName"
$pool.managedRuntimeVersion     = ""          # No managed runtime — .NET Core / ANCM
$pool.managedPipelineMode       = "Integrated"
$pool.startMode                 = "AlwaysRunning"
$pool.autoStart                 = $true
$pool.processModel.idleTimeout  = [TimeSpan]::Zero   # Never recycle on idle
$pool.recycling.periodicRestart.time = [TimeSpan]::Zero   # Disable time-based recycle

if ($AppPoolUser -ne "") {
    $pool.processModel.userName  = $AppPoolUser
    $pool.processModel.password  = $AppPoolPassword
    $pool.processModel.identityType = "SpecificUser"
    Write-Host "   App Pool identity: $AppPoolUser" -ForegroundColor DarkGray
} else {
    $pool.processModel.identityType = "ApplicationPoolIdentity"
    Write-Host "   App Pool identity: ApplicationPoolIdentity" -ForegroundColor DarkGray
}
$pool | Set-Item

Write-Host "[5/8] App Pool '$poolName' configured." -ForegroundColor Green

# ════════════════════════════════════════════════════════════════
# STEP 6 — IIS Website + API Sub-Application
# ════════════════════════════════════════════════════════════════
Write-Host "[6/8] Creating IIS Website..." -ForegroundColor Yellow

# Remove site if it already exists (re-deploy scenario)
if (Get-Website -Name $SiteName -ErrorAction SilentlyContinue) {
    Remove-Website -Name $SiteName
    Write-Host "   Removed existing site for re-deploy." -ForegroundColor DarkGray
}

New-Website -Name $SiteName `
            -PhysicalPath "$PhysicalPath\wwwroot" `
            -ApplicationPool $poolName `
            -Port $Port `
            -HostHeader $HostName | Out-Null

Write-Host "   Website created on http://${HostName}:${Port}" -ForegroundColor DarkGray

# Add HTTPS binding if cert thumbprint provided
if ($CertThumbprint -ne "") {
    $cert = Get-ChildItem Cert:\LocalMachine\My | Where-Object { $_.Thumbprint -eq $CertThumbprint }
    if ($cert) {
        New-WebBinding -Name $SiteName -Protocol https -Port 443 -HostHeader $HostName
        $binding = Get-WebBinding -Name $SiteName -Protocol https
        $binding.AddSslCertificate($CertThumbprint, "My")
        Write-Host "   HTTPS binding added (cert: $($cert.Subject))" -ForegroundColor DarkGray
    } else {
        Write-Warning "Certificate $CertThumbprint not found in LocalMachine\My. HTTPS not configured."
    }
}

# Add API as a child application under /api
$apiApp = "$PhysicalPath\api"
if (-not (Get-WebApplication -Site $SiteName -Name "api" -ErrorAction SilentlyContinue)) {
    New-WebApplication -Name "api" `
                       -Site $SiteName `
                       -PhysicalPath $apiApp `
                       -ApplicationPool $poolName | Out-Null
}
Write-Host "   API application added at /api" -ForegroundColor DarkGray

# ── Authentication: disable Anonymous, enable Windows Auth ──
Set-WebConfigurationProperty -Filter "system.webServer/security/authentication/anonymousAuthentication" `
    -Name "enabled" -Value "False" -PSPath "IIS:\Sites\$SiteName"

Set-WebConfigurationProperty -Filter "system.webServer/security/authentication/windowsAuthentication" `
    -Name "enabled" -Value "True" -PSPath "IIS:\Sites\$SiteName"

Write-Host "   Windows Authentication enabled." -ForegroundColor DarkGray

# ── Disable directory browsing ──
Set-WebConfigurationProperty -Filter "system.webServer/directoryBrowse" `
    -Name "enabled" -Value "False" -PSPath "IIS:\Sites\$SiteName"

Write-Host "[6/8] IIS Website '$SiteName' ready." -ForegroundColor Green

# ════════════════════════════════════════════════════════════════
# STEP 7 — NTFS Permissions
# ════════════════════════════════════════════════════════════════
Write-Host "[7/8] Setting NTFS permissions..." -ForegroundColor Yellow

# Determine the identity that needs read access
$identities = @("BUILTIN\IIS_IUSRS")
if ($AppPoolUser -ne "") {
    $identities += $AppPoolUser
} else {
    $identities += "IIS AppPool\$poolName"
}

foreach ($id in $identities) {
    try {
        $acl = Get-Acl $PhysicalPath
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $id, "ReadAndExecute", "ContainerInherit,ObjectInherit", "None", "Allow")
        $acl.SetAccessRule($rule)
        Set-Acl $PhysicalPath $acl
        Write-Host "   Granted ReadAndExecute to $id" -ForegroundColor DarkGray
    } catch {
        Write-Warning "Could not set ACL for ${id}: $_"
    }
}

# logs dir needs write
$logsAcl = Get-Acl "$PhysicalPath\logs"
foreach ($id in $identities) {
    try {
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $id, "Modify", "ContainerInherit,ObjectInherit", "None", "Allow")
        $logsAcl.SetAccessRule($rule)
    } catch {}
}
Set-Acl "$PhysicalPath\logs" $logsAcl
Write-Host "   Granted Modify on logs\ to app pool identity." -ForegroundColor DarkGray

Write-Host "[7/8] NTFS permissions set." -ForegroundColor Green

# ════════════════════════════════════════════════════════════════
# STEP 8 — Windows Firewall Rule
# ════════════════════════════════════════════════════════════════
Write-Host "[8/8] Configuring Windows Firewall..." -ForegroundColor Yellow

$ruleName = "GOA Login Forensics Dashboard (TCP $Port)"
if (-not (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName $ruleName `
                        -Direction Inbound `
                        -Protocol TCP `
                        -LocalPort $Port `
                        -Action Allow `
                        -Profile Domain `       # Intranet only — Domain profile
                        -Description "GOA Login Forensics intranet dashboard" | Out-Null
    Write-Host "   Firewall rule created for port $Port (Domain profile)." -ForegroundColor DarkGray
} else {
    Write-Host "   Firewall rule already exists." -ForegroundColor DarkGray
}

if ($CertThumbprint -ne "") {
    $httpsRule = "GOA Login Forensics Dashboard (HTTPS 443)"
    if (-not (Get-NetFirewallRule -DisplayName $httpsRule -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -DisplayName $httpsRule -Direction Inbound `
            -Protocol TCP -LocalPort 443 -Action Allow -Profile Domain | Out-Null
    }
}

Write-Host "[8/8] Firewall configured." -ForegroundColor Green

# ════════════════════════════════════════════════════════════════
# FINAL — Start the site and print summary
# ════════════════════════════════════════════════════════════════
Start-WebSite -Name $SiteName

Write-Host ""
Write-Host "╔══════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║   Installation Complete!                                  ║" -ForegroundColor Green
Write-Host "╠══════════════════════════════════════════════════════════╣" -ForegroundColor Green
Write-Host "║  Dashboard URL : http://$HostName`:$Port" -ForegroundColor Green
if ($CertThumbprint) {
Write-Host "║  Secure URL    : https://$HostName" -ForegroundColor Green
}
Write-Host "║  API base      : http://$HostName`:$Port/api" -ForegroundColor Green
Write-Host "║  Physical Path : $PhysicalPath" -ForegroundColor Green
Write-Host "║  App Pool      : $poolName" -ForegroundColor Green
Write-Host "║  SQL Server    : $SqlServer" -ForegroundColor Green
Write-Host "╠══════════════════════════════════════════════════════════╣" -ForegroundColor Green
Write-Host "║  Next steps:                                              ║" -ForegroundColor Cyan
Write-Host "║  1. Verify SQL login: Test-GOASQLConnection.ps1           ║" -ForegroundColor Cyan
Write-Host "║  2. Add DNS A-record: $HostName → this server IP  ║" -ForegroundColor Cyan
Write-Host "║  3. Add to AD group for restricted access (optional)      ║" -ForegroundColor Cyan
Write-Host "║  4. Schedule log rotation: Manage-GOALogs.ps1             ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
