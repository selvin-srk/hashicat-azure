#Requires -Version 5.1
<#
.SYNOPSIS
    Tests SQL Server connectivity and verifies the GOALogins table is accessible.

.DESCRIPTION
    Run this on the IIS server (as the App Pool service account) to confirm
    the database connection will work before opening the dashboard to users.

.PARAMETER SqlServer
    SQL Server hostname or instance. Default: SQL-PROD-01

.PARAMETER UseWindowsAuth
    If $true (default), uses Integrated Security (current Windows identity).
    If $false, prompts for SQL login credentials.

.EXAMPLE
    # Test as current user
    .\Test-GOASQLConnection.ps1

    # Test using the service account
    runas /user:GOA\svc_goaforensics powershell -File .\Test-GOASQLConnection.ps1
#>

param(
    [string]$SqlServer     = "SQL-PROD-01",
    [switch]$UseWindowsAuth = $true
)

$database = "REMEDY_Info"
$table    = "[dbo].[GOALogins]"

Write-Host ""
Write-Host "GOA Login Forensics — SQL Connection Test" -ForegroundColor Cyan
Write-Host "Running as: $env:USERDOMAIN\$env:USERNAME" -ForegroundColor DarkGray
Write-Host "Target    : $SqlServer\$database" -ForegroundColor DarkGray
Write-Host ""

try {
    Add-Type -AssemblyName "System.Data"

    $connStr = if ($UseWindowsAuth) {
        "Server=$SqlServer;Database=$database;Integrated Security=True;TrustServerCertificate=True;Connection Timeout=10;"
    } else {
        $cred = Get-Credential -Message "Enter SQL Server credentials"
        "Server=$SqlServer;Database=$database;User Id=$($cred.UserName);Password=$($cred.GetNetworkCredential().Password);TrustServerCertificate=True;"
    }

    $conn = New-Object System.Data.SqlClient.SqlConnection($connStr)
    $conn.Open()
    Write-Host "[OK] Connected to SQL Server." -ForegroundColor Green

    # Test 1: Row count
    $cmd = $conn.CreateCommand()
    $cmd.CommandText = "SELECT COUNT(*) FROM $table WITH (NOLOCK)"
    $count = $cmd.ExecuteScalar()
    Write-Host "[OK] Total rows in GOALogins: $($count.ToString('N0'))" -ForegroundColor Green

    # Test 2: Date range
    $cmd.CommandText = "SELECT MIN(LogonDate), MAX(LogonDate) FROM $table WITH (NOLOCK)"
    $reader = $cmd.ExecuteReader()
    if ($reader.Read()) {
        Write-Host "[OK] Date range: $($reader[0]) — $($reader[1])" -ForegroundColor Green
    }
    $reader.Close()

    # Test 3: Column check
    $cmd.CommandText = @"
        SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'GOALogins'
        ORDER BY ORDINAL_POSITION
"@
    $reader = $cmd.ExecuteReader()
    $cols = @()
    while ($reader.Read()) { $cols += $reader[0] }
    $reader.Close()

    $required = @('Id','DateUploaded','MachineName','LastLogonID','LogonDate','LogonTime',
                  'LogonWeekday','LogonServer','UserDistinguishedName','AdsSiteName',
                  'MachineDistinguishedName','MachineOS','Event',
                  'NetworkInfoPrimaryHostName','NetworkInfoPrimaryIP',
                  'NetworkInfoPrimarySubnet','NetworkInfoPrimaryMask')

    $missing = $required | Where-Object { $_ -notin $cols }
    if ($missing) {
        Write-Host "[WARN] Missing columns: $($missing -join ', ')" -ForegroundColor Yellow
    } else {
        Write-Host "[OK] All 17 required columns present." -ForegroundColor Green
    }

    # Test 4: Sample query (mimics the KPI endpoint)
    $cmd.CommandText = @"
        SELECT TOP 1
            COUNT(*) OVER ()      AS TotalRows,
            COUNT(DISTINCT LastLogonID) OVER () AS UniqueUsers
        FROM $table WITH (NOLOCK)
"@
    $reader = $cmd.ExecuteReader()
    if ($reader.Read()) {
        Write-Host "[OK] Sample KPI query succeeded." -ForegroundColor Green
    }
    $reader.Close()

    $conn.Close()

    Write-Host ""
    Write-Host "All tests passed. SQL Server is ready for GOA Forensics." -ForegroundColor Green

} catch {
    Write-Host "[FAIL] $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "Troubleshooting checklist:" -ForegroundColor Yellow
    Write-Host "  1. Can you ping $SqlServer from this server?"
    Write-Host "  2. Is SQL Server Browser service running on $SqlServer?"
    Write-Host "  3. Is TCP/IP enabled in SQL Server Configuration Manager?"
    Write-Host "  4. Does $env:USERDOMAIN\$env:USERNAME have db_datareader on REMEDY_Info?"
    Write-Host "  5. Check Windows Firewall on $SqlServer allows TCP 1433."
    exit 1
}
