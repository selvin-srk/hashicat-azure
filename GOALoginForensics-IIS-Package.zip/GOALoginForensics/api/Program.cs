// ============================================================
// GOA Login Forensics — ASP.NET Core 8 Minimal API
// File    : api/Program.cs
// Deploy  : IIS with ASP.NET Core Hosting Bundle
// DB      : [REMEDY_Info].[dbo].[GOALogins]  (SQL Server)
// ============================================================

using Microsoft.Data.SqlClient;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// ── Services ────────────────────────────────────────────────
builder.Services.AddCors(opt =>
    opt.AddDefaultPolicy(p =>
        p.WithOrigins("http://goaforensics.gov.ab.ca",
                      "https://goaforensics.gov.ab.ca",
                      "http://localhost")
         .AllowAnyHeader()
         .WithMethods("GET")));

builder.Services.AddResponseCompression();
builder.Services.AddOutputCache(opt =>
{
    opt.AddBasePolicy(b => b.Expire(TimeSpan.FromSeconds(30)));   // live data: 30 s
    opt.AddPolicy("historic", b => b.Expire(TimeSpan.FromMinutes(15))); // charts: 15 min
});

// ── Connection string comes from appsettings.json / env vars ─
var connStr = builder.Configuration.GetConnectionString("GOALogins")
    ?? throw new InvalidOperationException("Connection string 'GOALogins' is missing.");

var app = builder.Build();

app.UseCors();
app.UseResponseCompression();
app.UseOutputCache();

// ══════════════════════════════════════════════════════════════
//  HELPER
// ══════════════════════════════════════════════════════════════
async Task<List<Dictionary<string, object?>>> QueryAsync(string sql,
    Dictionary<string, object>? parameters = null)
{
    await using var conn = new SqlConnection(connStr);
    await conn.OpenAsync();
    await using var cmd  = new SqlCommand(sql, conn) { CommandTimeout = 60 };

    if (parameters != null)
        foreach (var (k, v) in parameters)
            cmd.Parameters.AddWithValue(k, v ?? DBNull.Value);

    await using var reader = await cmd.ExecuteReaderAsync();
    var rows = new List<Dictionary<string, object?>>();
    while (await reader.ReadAsync())
    {
        var row = new Dictionary<string, object?>();
        for (int i = 0; i < reader.FieldCount; i++)
            row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
        rows.Add(row);
    }
    return rows;
}

// ══════════════════════════════════════════════════════════════
//  ENDPOINTS
// ══════════════════════════════════════════════════════════════

// ── GET /api/health ──────────────────────────────────────────
app.MapGet("/api/health", () => Results.Ok(new { status = "ok", utc = DateTime.UtcNow }));

// ── GET /api/kpi  ────────────────────────────────────────────
// Returns headline numbers for the Overview KPI cards
app.MapGet("/api/kpi", async (string? from, string? to, string? site, string? eventType) =>
{
    var where = BuildWhere(from, to, site, eventType, out var parms);
    var sql = $@"
        SELECT
            COUNT(*)                                       AS TotalLogins,
            COUNT(DISTINCT LastLogonID)                    AS UniqueUsers,
            COUNT(DISTINCT MachineName)                    AS UniqueMachines,
            SUM(CASE WHEN Event LIKE '%VPN%' THEN 1 ELSE 0 END)  AS VPNSessions,
            SUM(CASE WHEN CAST(LogonTime AS TIME) < '06:00' OR
                          CAST(LogonTime AS TIME) > '20:00' THEN 1 ELSE 0 END) AS AfterHoursLogins
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {where}";
    var rows = await QueryAsync(sql, parms);
    return Results.Ok(rows.FirstOrDefault());
})
.CacheOutput();

// ── GET /api/logins  ─────────────────────────────────────────
// Paged login records for the live table
app.MapGet("/api/logins", async (
    string? from, string? to, string? site, string? eventType,
    string? user, string? machine,
    int page = 1, int pageSize = 25) =>
{
    pageSize = Math.Clamp(pageSize, 1, 200);
    page     = Math.Max(page, 1);
    int offset = (page - 1) * pageSize;

    var where = BuildWhere(from, to, site, eventType, out var parms, user, machine);

    var countSql = $"SELECT COUNT(*) FROM [REMEDY_Info].[dbo].[GOALogins] {where}";
    var dataSql  = $@"
        SELECT
            Id, DateUploaded, MachineName, LastLogonID,
            LogonDate, LogonTime, LogonWeekday, LogonServer,
            UserDistinguishedName, AdsSiteName, MachineDistinguishedName,
            MachineOS, Event,
            NetworkInfoPrimaryHostName, NetworkInfoPrimaryIP,
            NetworkInfoPrimarySubnet,  NetworkInfoPrimaryMask
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {where}
        ORDER BY LogonDate DESC, LogonTime DESC
        OFFSET {offset} ROWS FETCH NEXT {pageSize} ROWS ONLY";

    var countRows = await QueryAsync(countSql, parms);
    var total     = Convert.ToInt32(countRows[0].Values.First());
    var dataRows  = await QueryAsync(dataSql, parms);

    return Results.Ok(new { total, page, pageSize, data = dataRows });
});

// ── GET /api/chart/daily  ────────────────────────────────────
// Daily login counts for the main trend chart
app.MapGet("/api/chart/daily", async (string? from, string? to, string? site, string? eventType) =>
{
    var where = BuildWhere(from, to, site, eventType, out var parms);
    var sql = $@"
        SELECT
            CAST(LogonDate AS DATE)   AS Day,
            COUNT(*)                  AS LoginCount
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {where}
        GROUP BY CAST(LogonDate AS DATE)
        ORDER BY Day";
    var rows = await QueryAsync(sql, parms);
    return Results.Ok(rows);
})
.CacheOutput("historic");

// ── GET /api/chart/event-types  ──────────────────────────────
app.MapGet("/api/chart/event-types", async (string? from, string? to) =>
{
    var where = BuildWhere(from, to, null, null, out var parms);
    var sql = $@"
        SELECT Event, COUNT(*) AS LoginCount
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {where}
        GROUP BY Event
        ORDER BY LoginCount DESC";
    return Results.Ok(await QueryAsync(sql, parms));
})
.CacheOutput("historic");

// ── GET /api/chart/weekday  ──────────────────────────────────
app.MapGet("/api/chart/weekday", async (string? from, string? to) =>
{
    var where = BuildWhere(from, to, null, null, out var parms);
    var sql = $@"
        SELECT LogonWeekday, COUNT(*) AS LoginCount
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {where}
        GROUP BY LogonWeekday
        ORDER BY
          CASE LogonWeekday
            WHEN 'Monday'    THEN 1 WHEN 'Tuesday'  THEN 2 WHEN 'Wednesday' THEN 3
            WHEN 'Thursday'  THEN 4 WHEN 'Friday'   THEN 5 WHEN 'Saturday'  THEN 6
            WHEN 'Sunday'    THEN 7 ELSE 8 END";
    return Results.Ok(await QueryAsync(sql, parms));
})
.CacheOutput("historic");

// ── GET /api/chart/hourly  ───────────────────────────────────
app.MapGet("/api/chart/hourly", async (string? from, string? to) =>
{
    var where = BuildWhere(from, to, null, null, out var parms);
    var sql = $@"
        SELECT DATEPART(HOUR, LogonTime) AS Hour, COUNT(*) AS LoginCount
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {where}
        GROUP BY DATEPART(HOUR, LogonTime)
        ORDER BY Hour";
    return Results.Ok(await QueryAsync(sql, parms));
})
.CacheOutput("historic");

// ── GET /api/chart/heatmap  ──────────────────────────────────
// Returns 7×24 grid: weekday + hour + count
app.MapGet("/api/chart/heatmap", async (int? year) =>
{
    var parms = new Dictionary<string, object>();
    string yearFilter = "";
    if (year.HasValue)
    {
        yearFilter = "WHERE YEAR(LogonDate) = @Year";
        parms["@Year"] = year.Value;
    }
    var sql = $@"
        SELECT
            LogonWeekday                  AS Weekday,
            DATEPART(HOUR, LogonTime)     AS Hour,
            COUNT(*)                      AS LoginCount
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {yearFilter}
        GROUP BY LogonWeekday, DATEPART(HOUR, LogonTime)";
    return Results.Ok(await QueryAsync(sql, parms));
})
.CacheOutput("historic");

// ── GET /api/chart/historic  ─────────────────────────────────
// Monthly aggregates for the 10-year trend
app.MapGet("/api/chart/historic", async (int? fromYear, int? toYear) =>
{
    var parms = new Dictionary<string, object>();
    var conditions = new List<string>();
    if (fromYear.HasValue) { conditions.Add("YEAR(LogonDate) >= @FromYear"); parms["@FromYear"] = fromYear.Value; }
    if (toYear.HasValue)   { conditions.Add("YEAR(LogonDate) <= @ToYear");   parms["@ToYear"]   = toYear.Value; }
    var where = conditions.Any() ? "WHERE " + string.Join(" AND ", conditions) : "";

    var sql = $@"
        SELECT
            YEAR(LogonDate)                  AS Yr,
            MONTH(LogonDate)                 AS Mo,
            COUNT(*)                         AS TotalLogins,
            COUNT(DISTINCT LastLogonID)      AS UniqueUsers,
            SUM(CASE WHEN Event LIKE '%VPN%' THEN 1 ELSE 0 END) AS VPNSessions
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {where}
        GROUP BY YEAR(LogonDate), MONTH(LogonDate)
        ORDER BY Yr, Mo";
    return Results.Ok(await QueryAsync(sql, parms));
})
.CacheOutput("historic");

// ── GET /api/user/{samAccount}  ──────────────────────────────
// Full profile for a single user
app.MapGet("/api/user/{samAccount}", async (string samAccount) =>
{
    var parms = new Dictionary<string, object> { ["@User"] = $"%{samAccount}%" };

    var profileSql = @"
        SELECT
            LastLogonID,
            UserDistinguishedName,
            MIN(LogonDate)                        AS FirstSeen,
            MAX(LogonDate)                        AS LastSeen,
            COUNT(*)                              AS TotalLogins,
            COUNT(DISTINCT MachineName)           AS UniqueMachines,
            COUNT(DISTINCT AdsSiteName)           AS UniqueSites,
            SUM(CASE WHEN Event LIKE '%VPN%' THEN 1 ELSE 0 END) AS VPNSessions,
            SUM(CASE WHEN CAST(LogonTime AS TIME) < '06:00' OR
                          CAST(LogonTime AS TIME) > '20:00' THEN 1 ELSE 0 END) AS AfterHoursLogins
        FROM [REMEDY_Info].[dbo].[GOALogins]
        WHERE LastLogonID LIKE @User
           OR UserDistinguishedName LIKE @User
        GROUP BY LastLogonID, UserDistinguishedName";

    var machinesSql = @"
        SELECT MachineName, COUNT(*) AS LoginCount
        FROM [REMEDY_Info].[dbo].[GOALogins]
        WHERE LastLogonID LIKE @User
        GROUP BY MachineName
        ORDER BY LoginCount DESC";

    var monthlySql = @"
        SELECT YEAR(LogonDate) AS Yr, MONTH(LogonDate) AS Mo, COUNT(*) AS LoginCount
        FROM [REMEDY_Info].[dbo].[GOALogins]
        WHERE LastLogonID LIKE @User
        GROUP BY YEAR(LogonDate), MONTH(LogonDate)
        ORDER BY Yr, Mo";

    var hoursSql = @"
        SELECT DATEPART(HOUR, LogonTime) AS Hour, COUNT(*) AS LoginCount
        FROM [REMEDY_Info].[dbo].[GOALogins]
        WHERE LastLogonID LIKE @User
        GROUP BY DATEPART(HOUR, LogonTime)
        ORDER BY Hour";

    var profile  = (await QueryAsync(profileSql,  parms)).FirstOrDefault();
    var machines = await QueryAsync(machinesSql, parms);
    var monthly  = await QueryAsync(monthlySql,  parms);
    var hours    = await QueryAsync(hoursSql,    parms);

    return Results.Ok(new { profile, machines, monthly, hours });
});

// ── GET /api/sites  ──────────────────────────────────────────
app.MapGet("/api/sites", async (string? from, string? to) =>
{
    var where = BuildWhere(from, to, null, null, out var parms);
    var sql = $@"
        SELECT
            AdsSiteName                       AS SiteName,
            COUNT(*)                          AS TotalLogins,
            COUNT(DISTINCT LastLogonID)        AS UniqueUsers,
            COUNT(DISTINCT MachineName)        AS UniqueMachines,
            MAX(LogonDate)                    AS LastActivity
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {where}
        GROUP BY AdsSiteName
        ORDER BY TotalLogins DESC";
    return Results.Ok(await QueryAsync(sql, parms));
})
.CacheOutput("historic");

// ── GET /api/servers  ────────────────────────────────────────
app.MapGet("/api/servers", async (string? from, string? to) =>
{
    var where = BuildWhere(from, to, null, null, out var parms);
    var sql = $@"
        SELECT
            LogonServer,
            COUNT(*)                   AS TotalLogins,
            COUNT(DISTINCT LastLogonID) AS UniqueUsers,
            MAX(LogonDate)             AS LastActivity
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {where}
        GROUP BY LogonServer
        ORDER BY TotalLogins DESC";
    return Results.Ok(await QueryAsync(sql, parms));
})
.CacheOutput("historic");

// ── GET /api/subnets  ────────────────────────────────────────
app.MapGet("/api/subnets", async (string? from, string? to) =>
{
    var where = BuildWhere(from, to, null, null, out var parms);
    var sql = $@"
        SELECT
            NetworkInfoPrimarySubnet   AS Subnet,
            NetworkInfoPrimaryMask     AS Mask,
            NetworkInfoPrimaryHostName AS HostName,
            AdsSiteName                AS SiteName,
            COUNT(*)                   AS TotalLogins,
            COUNT(DISTINCT LastLogonID) AS UniqueUsers,
            MAX(LogonDate)             AS LastActivity
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {where}
        GROUP BY NetworkInfoPrimarySubnet, NetworkInfoPrimaryMask, NetworkInfoPrimaryHostName, AdsSiteName
        ORDER BY TotalLogins DESC";
    return Results.Ok(await QueryAsync(sql, parms));
})
.CacheOutput("historic");

// ── GET /api/machines  ───────────────────────────────────────
app.MapGet("/api/machines", async (string? from, string? to, string? os, string? search) =>
{
    var where = BuildWhere(from, to, null, null, out var parms, machineSearch: search, os: os);
    var sql = $@"
        SELECT
            MachineName,
            MachineDistinguishedName,
            MachineOS,
            AdsSiteName,
            COUNT(*)                   AS TotalLogins,
            COUNT(DISTINCT LastLogonID) AS UniqueUsers,
            MAX(LastLogonID)           AS LastUser,
            MAX(LogonDate)             AS LastLogin
        FROM [REMEDY_Info].[dbo].[GOALogins]
        {where}
        GROUP BY MachineName, MachineDistinguishedName, MachineOS, AdsSiteName
        ORDER BY TotalLogins DESC";
    return Results.Ok(await QueryAsync(sql, parms));
});

// ── GET /api/anomalies  ──────────────────────────────────────
// Returns detected anomalies: after-hours, multi-site, high-freq, new machine
app.MapGet("/api/anomalies", async (string? date) =>
{
    var checkDate = date ?? DateTime.Today.ToString("yyyy-MM-dd");
    var parms = new Dictionary<string, object> { ["@Date"] = checkDate };

    // After-hours (before 06:00 or after 20:00)
    var afterHoursSql = @"
        SELECT 'After-Hours' AS AnomalyType, 'WARNING' AS Severity,
               LastLogonID, MachineName, AdsSiteName, LogonDate, LogonTime, Event
        FROM [REMEDY_Info].[dbo].[GOALogins]
        WHERE CAST(LogonDate AS DATE) = @Date
          AND (CAST(LogonTime AS TIME) < '06:00:00' OR CAST(LogonTime AS TIME) > '20:00:00')
        ORDER BY LogonTime";

    // Multi-site same user same day
    var multiSiteSql = @"
        SELECT 'Multi-Site' AS AnomalyType, 'CRITICAL' AS Severity,
               LastLogonID,
               COUNT(DISTINCT AdsSiteName) AS SiteCount,
               STRING_AGG(DISTINCT AdsSiteName, ', ') AS Sites,
               LogonDate
        FROM [REMEDY_Info].[dbo].[GOALogins]
        WHERE CAST(LogonDate AS DATE) = @Date
        GROUP BY LastLogonID, LogonDate
        HAVING COUNT(DISTINCT AdsSiteName) > 1
        ORDER BY SiteCount DESC";

    // High frequency (>200 events same user same day)
    var highFreqSql = @"
        SELECT 'High-Frequency' AS AnomalyType, 'WARNING' AS Severity,
               LastLogonID, LogonDate, COUNT(*) AS EventCount
        FROM [REMEDY_Info].[dbo].[GOALogins]
        WHERE CAST(LogonDate AS DATE) = @Date
        GROUP BY LastLogonID, LogonDate
        HAVING COUNT(*) > 200
        ORDER BY EventCount DESC";

    // New machine (first time seen in the last 7 days, previously never appeared)
    var newMachineSql = @"
        SELECT 'New-Machine' AS AnomalyType, 'INFO' AS Severity,
               MachineName, LastLogonID, LogonDate, AdsSiteName
        FROM [REMEDY_Info].[dbo].[GOALogins] a
        WHERE CAST(LogonDate AS DATE) = @Date
          AND NOT EXISTS (
            SELECT 1 FROM [REMEDY_Info].[dbo].[GOALogins] b
            WHERE b.MachineName = a.MachineName
              AND CAST(b.LogonDate AS DATE) < @Date
          )
        GROUP BY MachineName, LastLogonID, LogonDate, AdsSiteName";

    return Results.Ok(new
    {
        afterHours = await QueryAsync(afterHoursSql, parms),
        multiSite  = await QueryAsync(multiSiteSql,  parms),
        highFreq   = await QueryAsync(highFreqSql,   parms),
        newMachine = await QueryAsync(newMachineSql, parms)
    });
});

// ── GET /api/compare  ────────────────────────────────────────
app.MapGet("/api/compare", async (string entityA, string entityB, string compareType,
    string? from, string? to) =>
{
    async Task<object> GetStats(string entity)
    {
        var p = new Dictionary<string, object>
        {
            ["@Entity"] = $"%{entity}%",
            ["@From"]   = from ?? "2015-01-01",
            ["@To"]     = to   ?? DateTime.Today.ToString("yyyy-MM-dd")
        };

        string field = compareType switch
        {
            "Site vs Site"    => "AdsSiteName",
            "Machine vs Machine" => "MachineName",
            _                 => "LastLogonID"    // User vs User + Period vs Period
        };

        var sql = $@"
            SELECT
                COUNT(*)                              AS TotalLogins,
                COUNT(DISTINCT LastLogonID)            AS UniqueUsers,
                COUNT(DISTINCT MachineName)            AS UniqueMachines,
                COUNT(DISTINCT CAST(LogonDate AS DATE)) AS ActiveDays,
                SUM(CASE WHEN Event LIKE '%VPN%' THEN 1 ELSE 0 END) AS VPNSessions,
                SUM(CASE WHEN CAST(LogonTime AS TIME) < '06:00' OR
                              CAST(LogonTime AS TIME) > '20:00' THEN 1 ELSE 0 END) AS AfterHours
            FROM [REMEDY_Info].[dbo].[GOALogins]
            WHERE {field} LIKE @Entity
              AND CAST(LogonDate AS DATE) BETWEEN @From AND @To";

        var monthlySql = $@"
            SELECT YEAR(LogonDate) AS Yr, MONTH(LogonDate) AS Mo, COUNT(*) AS LoginCount
            FROM [REMEDY_Info].[dbo].[GOALogins]
            WHERE {field} LIKE @Entity
              AND CAST(LogonDate AS DATE) BETWEEN @From AND @To
            GROUP BY YEAR(LogonDate), MONTH(LogonDate)
            ORDER BY Yr, Mo";

        return new
        {
            summary = (await QueryAsync(sql, p)).FirstOrDefault(),
            monthly = await QueryAsync(monthlySql, p)
        };
    }

    return Results.Ok(new
    {
        a = await GetStats(entityA),
        b = await GetStats(entityB)
    });
});

app.Run();

// ══════════════════════════════════════════════════════════════
//  WHERE CLAUSE BUILDER
// ══════════════════════════════════════════════════════════════
static string BuildWhere(
    string? from, string? to, string? site, string? eventType,
    out Dictionary<string, object> parms,
    string? userSearch = null, string? machineSearch = null, string? os = null)
{
    parms = new Dictionary<string, object>();
    var conditions = new List<string>();

    if (!string.IsNullOrEmpty(from))
    {
        conditions.Add("CAST(LogonDate AS DATE) >= @From");
        parms["@From"] = from;
    }
    if (!string.IsNullOrEmpty(to))
    {
        conditions.Add("CAST(LogonDate AS DATE) <= @To");
        parms["@To"] = to;
    }
    if (!string.IsNullOrEmpty(site))
    {
        conditions.Add("AdsSiteName = @Site");
        parms["@Site"] = site;
    }
    if (!string.IsNullOrEmpty(eventType))
    {
        conditions.Add("Event = @EventType");
        parms["@EventType"] = eventType;
    }
    if (!string.IsNullOrEmpty(userSearch))
    {
        conditions.Add("(LastLogonID LIKE @UserSearch OR UserDistinguishedName LIKE @UserSearch)");
        parms["@UserSearch"] = $"%{userSearch}%";
    }
    if (!string.IsNullOrEmpty(machineSearch))
    {
        conditions.Add("(MachineName LIKE @MachineSearch OR MachineDistinguishedName LIKE @MachineSearch)");
        parms["@MachineSearch"] = $"%{machineSearch}%";
    }
    if (!string.IsNullOrEmpty(os))
    {
        conditions.Add("MachineOS LIKE @OS");
        parms["@OS"] = $"%{os}%";
    }

    return conditions.Any() ? "WHERE " + string.Join(" AND ", conditions) : "";
}
