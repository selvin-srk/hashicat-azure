# GOA Login Forensics Dashboard — IIS Deployment Guide

## Architecture Overview

```
                     INTRANET (Domain only)
                     ┌─────────────────────────────────────┐
  Domain Users ──────►  IIS 10 (Windows Server 2019/2022)  │
  (Windows Auth)      │  Port 8080 (or 443 HTTPS)          │
                      │                                      │
                      │  ┌──────────────────────────────┐  │
                      │  │  Site: GOALoginForensics      │  │
                      │  │  App Pool: GOALoginForensics- │  │
                      │  │            Pool (.NET CLR: ∅) │  │
                      │  │                               │  │
                      │  │  /wwwroot  ──── index.html    │  │
                      │  │            ──── web.config    │  │
                      │  │                               │  │
                      │  │  /api  ─── ASP.NET Core 8 ───┼──┼──► SQL-PROD-01
                      │  │            (ANCM In-Process)  │  │    REMEDY_Info
                      │  │            localhost:5000      │  │    dbo.GOALogins
                      │  └──────────────────────────────┘  │
                      └─────────────────────────────────────┘
```

## Prerequisites

| Requirement | Minimum Version | Notes |
|---|---|---|
| Windows Server | 2019 (1809) | 2022 preferred |
| IIS | 10.0 | Included with Windows Server |
| .NET 8 Hosting Bundle | 8.0.x | Installed by setup script |
| URL Rewrite Module | 2.1 | Installed by setup script if missing |
| SQL Server | 2016+ | `STRING_AGG` requires 2017+ |
| PowerShell | 5.1+ | For setup scripts |

---

## Quick Start

### Step 1 — Prepare the SQL Server
Run on **SQL-PROD-01** as sysadmin:
```sql
-- Creates read-only service account, grants db_datareader
sqlcmd -S SQL-PROD-01 -d master -i scripts\Setup-DBPermissions.sql
```

### Step 2 — Run the IIS Installer
Run on the **web server** as a local administrator:
```powershell
cd GOALoginForensics
.\scripts\Install-GOAForensicsDashboard.ps1 `
    -SqlServer    "SQL-PROD-01" `
    -AppPoolUser  "GOA\svc_goaforensics" `
    -AppPoolPassword "YourPassword" `
    -HostName     "goaforensics.gov.ab.ca" `
    -Port         8080
```

### Step 3 — Verify the Database Connection
```powershell
# Run AS the service account to confirm SQL access
runas /user:GOA\svc_goaforensics `
    powershell -File .\scripts\Test-GOASQLConnection.ps1
```

### Step 4 — Add the DNS Record
In your DNS server (or AD DNS zone), add:
```
goaforensics.gov.ab.ca  A  <IIS server IP>
```

### Step 5 — Open the Dashboard
```
http://goaforensics.gov.ab.ca:8080
```

---

## Directory Structure (after install)

```
C:\inetpub\GOALoginForensics\
├── wwwroot\                  ← IIS site root (static HTML)
│   ├── index.html            ← Main dashboard (all tabs)
│   ├── web.config            ← IIS config: auth, headers, rewrite
│   └── errors\               ← Custom error pages (400/401/403/404/500)
│
├── api\                      ← ASP.NET Core 8 API sub-application
│   ├── GOALoginForensicsApi.dll
│   ├── appsettings.json      ← Connection string, Kestrel settings
│   └── web.config            ← ANCM in-process hosting config
│
├── logs\                     ← IIS W3C logs + app stdout logs
├── config\                   ← Reserved for future config files
└── scripts\                  ← Setup and maintenance scripts
```

---

## API Endpoints

All endpoints are **GET only**, **read-only**, require **Windows Authentication**.

| Endpoint | Description | Cache |
|---|---|---|
| `GET /api/health` | Liveness check | None |
| `GET /api/kpi` | KPI card numbers | 30 s |
| `GET /api/logins` | Paged login records | None |
| `GET /api/chart/daily` | Daily login counts | 15 min |
| `GET /api/chart/event-types` | Event type breakdown | 15 min |
| `GET /api/chart/weekday` | Day-of-week distribution | 15 min |
| `GET /api/chart/hourly` | Hour-of-day distribution | 15 min |
| `GET /api/chart/heatmap` | 7×24 weekday/hour grid | 15 min |
| `GET /api/chart/historic` | Monthly 10-year trend | 15 min |
| `GET /api/user/{samAccount}` | Full user profile + charts | None |
| `GET /api/sites` | Login volume by AD Site | 15 min |
| `GET /api/servers` | Login volume by Logon Server | 15 min |
| `GET /api/subnets` | Subnet activity table | 15 min |
| `GET /api/machines` | Machine registry with stats | None |
| `GET /api/anomalies` | Anomaly detection results | None |
| `GET /api/compare` | Side-by-side entity comparison | None |

### Common Query Parameters
| Parameter | Example | Description |
|---|---|---|
| `from` | `2025-01-01` | Start date (LogonDate) |
| `to` | `2025-12-31` | End date (LogonDate) |
| `site` | `Edmonton-Gov` | Filter by AdsSiteName |
| `eventType` | `Logon` | Filter by Event |
| `page` | `1` | Page number (default 1) |
| `pageSize` | `25` | Rows per page (max 200) |

---

## Security

### Authentication
- **Windows Authentication** (Kerberos/NTLM) is enabled by default.
- Anonymous access is **disabled**. Only domain users with a valid AD session can access the site.
- The logged-in user's identity (`DOMAIN\username`) is passed to the API for audit logging if needed.

### Authorization (optional — restrict to a security group)
Add URL Authorization rules in `web.config` to restrict access to a specific AD group:
```xml
<system.web>
  <authorization>
    <allow roles="GOA\GOA-Forensics-Readers" />
    <deny users="*" />
  </authorization>
</system.web>
```
Create the group in AD:
```powershell
New-ADGroup -Name "GOA-Forensics-Readers" -GroupScope Global -GroupCategory Security
Add-ADGroupMember -Identity "GOA-Forensics-Readers" -Members "analyst1","analyst2"
```

### SQL Security
- The API uses a **read-only** service account (`svc_goaforensics`) with only `db_datareader` on `REMEDY_Info`.
- Write operations (`INSERT`, `UPDATE`, `DELETE`, `ALTER`) are explicitly **denied**.
- The connection uses **Integrated Security** (no passwords in config files).
- All SQL queries use **parameterized inputs** — no dynamic SQL construction.

### HTTP Headers
The `web.config` sets:
- `X-Frame-Options: SAMEORIGIN`
- `X-Content-Type-Options: nosniff`
- `X-XSS-Protection: 1; mode=block`
- `Content-Security-Policy` (locks down script/style sources)
- Removes `X-Powered-By` and `Server` headers

---

## Connecting the Dashboard to the Live API

The `index.html` currently uses **simulated data**. To wire it to the real SQL data,
replace the `records` array initialization in the `<script>` block with fetch calls.

**Example — replace KPI cards:**
```javascript
// In index.html, replace the static kpi-value spans with:
async function loadKPIs() {
    const params = new URLSearchParams({
        from: document.getElementById('ov-from').value,
        to:   document.getElementById('ov-to').value
    });
    const res  = await fetch(`/api/kpi?${params}`);
    const data = await res.json();
    document.getElementById('kpi-total').textContent =
        Number(data.TotalLogins).toLocaleString();
    document.getElementById('kpi-users').textContent =
        Number(data.UniqueUsers).toLocaleString();
}
loadKPIs();
```

All API endpoints return plain JSON and are on the same origin as the HTML,
so no CORS configuration is needed for the intranet deployment.

---

## Maintenance

### Recycle the App Pool after deployment
```powershell
Import-Module WebAdministration
Restart-WebAppPool -Name "GOALoginForensics-Pool"
```

### View IIS logs
```
C:\inetpub\GOALoginForensics\logs\
C:\Windows\System32\LogFiles\W3SVC<site-id>\
```

### Update the dashboard (re-deploy)
```powershell
# Copy new index.html to wwwroot
Copy-Item .\wwwroot\index.html C:\inetpub\GOALoginForensics\wwwroot\ -Force

# Re-publish API after code changes
dotnet publish .\api\GOALoginForensicsApi.csproj -c Release `
    -o C:\inetpub\GOALoginForensics\api --no-self-contained
Restart-WebAppPool -Name "GOALoginForensics-Pool"
```

### Add HTTPS later
```powershell
# Import the certificate
$cert = Import-PfxCertificate -FilePath .\goaforensics.pfx `
    -CertStoreLocation Cert:\LocalMachine\My -Password (Read-Host -AsSecureString)

# Add binding
New-WebBinding -Name "GOALoginForensics" -Protocol https -Port 443 `
    -HostHeader "goaforensics.gov.ab.ca"
(Get-WebBinding -Name "GOALoginForensics" -Protocol https).AddSslCertificate(
    $cert.Thumbprint, "My")
```

---

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---|---|---|
| 401 Unauthorized | Browser not sending Kerberos ticket | Ensure site is in IE/Edge Intranet Zone; add to Trusted Sites |
| 500 on /api/* | .NET Hosting Bundle not installed | Re-run installer; check Event Viewer → Application |
| Charts show no data | API can't reach SQL Server | Run `Test-GOASQLConnection.ps1` as the service account |
| Blank page | index.html not in wwwroot | Check physical path in IIS Manager |
| URL Rewrite rule not matching | Module not installed | Check IIS Modules list for `RewriteModule` |
| App Pool stops immediately | Missing .NET runtime | Install ASP.NET Core 8 Hosting Bundle and restart IIS |

---

*GOA Login Forensics Dashboard — Alberta Government Domain Security*
*Deployed via IIS 10 + ASP.NET Core 8 — Read-only access to REMEDY_Info.dbo.GOALogins*
