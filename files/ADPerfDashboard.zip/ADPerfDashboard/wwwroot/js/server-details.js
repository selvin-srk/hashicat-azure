/* ===========================================================================
   server-details.js — Server Details page: every metric with sparkline,
   min / max / average, click-to-plot 90-day historical chart, export links.
   ======================================================================== */
(function () {
    'use strict';

    const cfg = window.DETAIL_CONFIG;
    let stats = [];          // MetricStatDto[]
    let history = [];        // raw AdPerfRecord[] for the big chart
    let selectedMetric = null;

    function days() { return parseInt($('#detailDays').val(), 10) || cfg.days; }

    function exportUrls() {
        const q = 'server=' + encodeURIComponent(cfg.server) + '&days=' + days();
        $('#expHistCsv').attr('href', '/api/export/history/csv?' + q);
        $('#expHistExcel').attr('href', '/api/export/history/excel?' + q);
    }

    async function load() {
        exportUrls();
        const q = 'server=' + encodeURIComponent(cfg.server) + '&days=' + days();
        [stats, history] = await Promise.all([
            dashFetch('/api/dashboard/serverstats?' + q),
            dashFetch('/api/dashboard/history?' + q)
        ]);
        renderTable();
        updateBadge();
        // keep current selection when the window changes
        if (selectedMetric) plotMetric(selectedMetric);
    }

    function renderTable() {
        $('#metricTable tbody').html(stats.map(m => `
            <tr data-metric="${m.metric}">
                <td class="fw-semibold">${esc(m.label)}</td>
                <td><canvas class="sparkline" data-metric="${m.metric}"></canvas></td>
                <td class="text-end">${fmt.num(m.latest, 2)}</td>
                <td class="text-end text-dim">${fmt.num(m.min, 2)}</td>
                <td class="text-end text-dim">${fmt.num(m.max, 2)}</td>
                <td class="text-end">${fmt.num(m.avg, 2)}</td>
                <td class="text-dim">${esc(m.unit)}</td>
            </tr>`).join(''));

        // draw sparklines after the canvases exist in the DOM
        requestAnimationFrame(() => {
            document.querySelectorAll('#metricTable .sparkline').forEach(cv => {
                const m = stats.find(x => x.metric === cv.dataset.metric);
                if (m) drawSparkline(cv, m.spark);
            });
        });
    }

    /** Rough health badge from the latest snapshot (mirrors server rules). */
    function updateBadge() {
        if (!history.length) return;
        const r = history[history.length - 1];
        let cls = 'health-healthy', text = 'Healthy';
        const maxDisk = Math.max(r.diskCReadMs || 0, r.diskDReadMs || 0, r.diskTotalReadMs || 0,
                                 r.diskCWriteMs || 0, r.diskDWriteMs || 0, r.diskTotalWriteMs || 0);
        if ((r.memoryAvailableMBytes ?? 1e9) < 2048 || maxDisk > 20 || (r.ldapBindTime ?? 0) > 100 ||
            (r.serverErrorsLogon ?? 0) > 10 || (r.lsassProcessorTime ?? 0) > 70) {
            cls = 'health-critical'; text = 'Critical';
        } else if ((r.memoryAvailableMBytes ?? 1e9) < 4096 || maxDisk > 10 ||
                   (r.ldapBindTime ?? 0) > 50 || (r.lsassProcessorTime ?? 0) > 40) {
            cls = 'health-warning'; text = 'Warning';
        }
        $('#detailHealthBadge').attr('class', 'badge ms-2 ' + cls).text(text);
    }

    /** Metric name → property on the raw history record. */
    const METRIC_PROP = m => m.charAt(0).toLowerCase() + m.slice(1);

    function plotMetric(metric) {
        selectedMetric = metric;
        const stat = stats.find(x => x.metric === metric);
        if (!stat) return;

        $('#historyChartTitle').html('<i class="fa-solid fa-chart-line me-1"></i>' +
            esc(stat.label) + ' — last ' + days() + ' days' + (stat.unit ? ' (' + esc(stat.unit) + ')' : ''));

        const prop = METRIC_PROP(metric);
        const pts = history.map(r => ({
            x: fmt.date(r.reportDate),
            y: metric === 'SystemUpTimeSeconds'
                ? (r.systemUpTimeSeconds != null ? r.systemUpTimeSeconds / 86400 : null)
                : r[prop]
        }));

        // threshold guides for the metrics that have official thresholds
        const THRESHOLDS = {
            MemoryAvailableMBytes: { warning: 4096, critical: 2048 },
            LdapBindTime: { warning: 50, critical: 100 },
            LsassProcessorTime: { warning: 40, critical: 70 },
            DiskCReadMs: { warning: 10, critical: 20 }, DiskDReadMs: { warning: 10, critical: 20 },
            DiskTotalReadMs: { warning: 10, critical: 20 }, DiskCWriteMs: { warning: 10, critical: 20 },
            DiskDWriteMs: { warning: 10, critical: 20 }, DiskTotalWriteMs: { warning: 10, critical: 20 },
            ServerErrorsLogon: { critical: 10 }
        };

        buildLineChart('chHistory', { [stat.label]: pts },
            { fill: true, thresholds: THRESHOLDS[metric] });

        $('#metricTable tbody tr').removeClass('table-active');
        $('#metricTable tbody tr[data-metric="' + metric + '"]').addClass('table-active');
    }

    $(document).on('click', '#metricTable tbody tr[data-metric]', function () {
        plotMetric($(this).data('metric'));
    });

    $('#detailDays').on('change', () => load().catch(console.error));
    document.addEventListener('themechanged', () => renderTable());

    $(() => load().then(() => plotMetric('MemoryAvailableMBytes')).catch(e => {
        $('#metricTable tbody').html('<tr><td colspan="7" class="text-center py-4 cell-critical">' + esc(e.message) + '</td></tr>');
    }));
})();
