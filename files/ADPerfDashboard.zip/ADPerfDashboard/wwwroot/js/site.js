/* ===========================================================================
   site.js — shared helpers: theme toggle, AJAX wrapper, formatting.
   ======================================================================== */
(function () {
    'use strict';

    // ---------------- theme (persisted in localStorage) ----------------
    const saved = localStorage.getItem('adperf-theme');
    if (saved) document.documentElement.setAttribute('data-theme', saved);

    document.addEventListener('DOMContentLoaded', function () {
        const btn = document.getElementById('btnTheme');
        if (btn) btn.addEventListener('click', function () {
            const cur = document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
            document.documentElement.setAttribute('data-theme', cur);
            localStorage.setItem('adperf-theme', cur);
            // Charts must re-read CSS colours
            document.dispatchEvent(new CustomEvent('themechanged'));
        });
    });

    // ---------------- AJAX helper (fetch, Windows-auth friendly) --------
    window.dashFetch = async function (url) {
        const res = await fetch(url, { credentials: 'same-origin', headers: { 'Accept': 'application/json' } });
        if (!res.ok) {
            let msg = 'Request failed (' + res.status + ')';
            try { const body = await res.json(); if (body.error) msg = body.error + ' [ref ' + body.referenceId + ']'; } catch { /* ignore */ }
            throw new Error(msg);
        }
        return res.json();
    };

    // ---------------- number / date formatting ----------------
    window.fmt = {
        num: (v, d = 1) => (v === null || v === undefined) ? '–' : Number(v).toLocaleString(undefined, { maximumFractionDigits: d }),
        int: v => (v === null || v === undefined) ? '–' : Math.round(v).toLocaleString(),
        bytes: v => {
            if (v === null || v === undefined) return '–';
            const units = ['B', 'KB', 'MB', 'GB'];
            let i = 0; v = Number(v);
            while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
            return v.toFixed(1) + ' ' + units[i];
        },
        date: v => v ? new Date(v).toLocaleString() : '–',
        day: v => v ? new Date(v).toLocaleDateString() : '–'
    };

    // Read a CSS custom property (used by chart theming)
    window.cssVar = name =>
        getComputedStyle(document.documentElement).getPropertyValue(name).trim();

    // Disk latency colour class per the recommended thresholds
    window.latencyClass = ms => {
        if (ms === null || ms === undefined) return '';
        if (ms > 20) return 'cell-critical';
        if (ms > 10) return 'cell-warning';
        return 'cell-healthy';
    };

    // HTML-escape untrusted strings before injecting into the DOM
    window.esc = s => String(s ?? '').replace(/[&<>"']/g,
        c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
})();
