/* ===========================================================================
   dashboard.js — main page logic: summary cards, overview grid (search /
   sort / paginate), lazy-loaded tab charts, filters, exports, 12-hour
   auto-refresh. All data arrives via AJAX from /api/dashboard/*.
   ======================================================================== */
(function () {
    'use strict';

    const cfg = window.DASH_CONFIG || { autoRefreshHours: 12, defaultTrendDays: 30 };
    const PAGE_SIZE = 25;

    // client state
    let overviewRows = [];          // full filtered set from the API
    let gridPage = 0;
    let sortKey = null, sortDir = 1;
    let trendCache = null;          // TrendPointDto[] for the current filter
    let loadedTabs = new Set();     // lazy loading: fetch a tab only once
    let diskScope = 'c';

    // ------------------------------------------------------------ filters
    function currentFilter() {
        return {
            server: $('#fltServer').val() || '',
            site: $('#fltSite').val() || '',
            health: $('#fltHealth').val() || '',
            dateFrom: $('#fltFrom').val() || '',
            dateTo: $('#fltTo').val() || '',
            days: $('#fltDays').val() || cfg.defaultTrendDays
        };
    }

    function qs(extra) {
        const f = { ...currentFilter(), ...(extra || {}) };
        const p = new URLSearchParams();
        if (f.server) p.set('server', f.server);
        if (f.site) p.set('site', f.site);
        if (f.health) p.set('health', f.health);
        if (f.dateFrom) p.set('dateFrom', f.dateFrom);
        if (f.dateTo) p.set('dateTo', f.dateTo);
        if (f.days) p.set('days', f.days);
        return p.toString();
    }

    // ------------------------------------------------------------ summary
    async function loadSummary() {
        const s = await dashFetch('/api/dashboard/summary?' + qs());
        const cards = [
            { icon: 'fa-calendar-check', label: 'Latest Collection', value: fmt.date(s.latestCollectionDate), cls: '' },
            { icon: 'fa-server', label: 'Domain Controllers', value: fmt.int(s.totalDomainControllers), cls: '' },
            { icon: 'fa-circle-check', label: 'Healthy', value: fmt.int(s.healthyCount), cls: 'kpi-healthy' },
            { icon: 'fa-triangle-exclamation', label: 'Warning', value: fmt.int(s.warningCount), cls: 'kpi-warning' },
            { icon: 'fa-circle-xmark', label: 'Critical', value: fmt.int(s.criticalCount), cls: 'kpi-critical' },
            { icon: 'fa-magnifying-glass', label: 'Avg LDAP Searches/sec', value: fmt.num(s.avgLdapSearchesSec), cls: '' },
            { icon: 'fa-ticket', label: 'Avg Kerberos/sec', value: fmt.num(s.avgKerberosAuthSec), cls: '' },
            { icon: 'fa-key', label: 'Avg NTLM/sec', value: fmt.num(s.avgNtlmAuthSec), cls: '' },
            { icon: 'fa-memory', label: 'Avg Available Memory', value: fmt.int(s.avgAvailableMemoryMB) + ' MB', cls: '' },
            { icon: 'fa-microchip', label: 'Highest LSASS CPU', value: fmt.num(s.highestLsassCpu) + '%', sub: s.highestLsassCpuServer, cls: s.highestLsassCpu > 70 ? 'kpi-critical' : s.highestLsassCpu > 40 ? 'kpi-warning' : '' },
            { icon: 'fa-hard-drive', label: 'Highest Disk Latency', value: fmt.num(s.highestDiskLatencyMs) + ' ms', sub: s.highestDiskLatencyServer, cls: s.highestDiskLatencyMs > 20 ? 'kpi-critical' : s.highestDiskLatencyMs > 10 ? 'kpi-warning' : '' },
            { icon: 'fa-stopwatch', label: 'Highest LDAP Bind Time', value: fmt.num(s.highestLdapBindTime, 0), sub: s.highestLdapBindTimeServer, cls: s.highestLdapBindTime > 100 ? 'kpi-critical' : s.highestLdapBindTime > 50 ? 'kpi-warning' : '' }
        ];
        $('#summaryCards').html(cards.map(c => `
            <div class="col-6 col-md-4 col-xl-2">
                <div class="kpi-card ${c.cls}">
                    <div class="kpi-label"><i class="fa-solid ${c.icon} me-1"></i>${c.label}</div>
                    <div class="kpi-value">${c.value}</div>
                    ${c.sub ? `<div class="kpi-sub">${esc(c.sub)}</div>` : ''}
                </div>
            </div>`).join(''));
    }

    // ------------------------------------------------------------ overview grid
    async function loadOverview() {
        overviewRows = await dashFetch('/api/dashboard/overview?' + qs());
        gridPage = 0;
        renderGrid();
    }

    function visibleRows() {
        const q = ($('#fltSearch').val() || '').toLowerCase();
        let rows = q ? overviewRows.filter(r => r.server.toLowerCase().includes(q)) : overviewRows.slice();
        if (sortKey) {
            rows.sort((a, b) => {
                const av = a[sortKey], bv = b[sortKey];
                if (av === null || av === undefined) return 1;
                if (bv === null || bv === undefined) return -1;
                return (av < bv ? -1 : av > bv ? 1 : 0) * sortDir;
            });
        }
        return rows;
    }

    function renderGrid() {
        const rows = visibleRows();
        const start = gridPage * PAGE_SIZE;
        const page = rows.slice(start, start + PAGE_SIZE);

        const body = page.length === 0
            ? '<tr><td colspan="12" class="text-center py-4 text-dim">No matching data</td></tr>'
            : page.map(r => {
                const hb = 'health-' + r.healthStatus.toLowerCase();
                const issues = (r.healthIssues || []).map(esc).join('&#10;');
                return `<tr data-server="${esc(r.server)}" title="${issues}">
                    <td class="fw-semibold">${esc(r.server)}${r.site ? ' <span class="text-dim small">(' + esc(r.site) + ')</span>' : ''}</td>
                    <td><span class="badge ${hb}">${r.healthStatus}</span></td>
                    <td class="${r.memoryAvailableMBytes < 2048 ? 'cell-critical' : r.memoryAvailableMBytes < 4096 ? 'cell-warning' : 'cell-healthy'}">${fmt.int(r.memoryAvailableMBytes)}</td>
                    <td class="${r.lsassCpu > 70 ? 'cell-critical' : r.lsassCpu > 40 ? 'cell-warning' : 'cell-healthy'}">${fmt.num(r.lsassCpu)}</td>
                    <td>${fmt.num(r.ldapSearchesSec)}</td>
                    <td>${fmt.num(r.kerberosAuthentications)}</td>
                    <td>${fmt.num(r.ntlmAuthentications)} <span class="text-dim small">${fmt.num(r.ntlmPercent)}%</span></td>
                    <td class="${latencyClass(r.diskReadMs)}">${fmt.num(r.diskReadMs)}</td>
                    <td class="${latencyClass(r.diskWriteMs)}">${fmt.num(r.diskWriteMs)}</td>
                    <td>${fmt.num(r.uptimeDays)}</td>
                    <td>${fmt.num(r.logonSec)}</td>
                    <td class="text-dim">${fmt.date(r.reportDate)}</td>
                </tr>`;
            }).join('');
        $('#overviewGrid tbody').html(body);
        $('#gridInfo').text(rows.length + ' domain controllers' + (rows.length > PAGE_SIZE ? ' · page ' + (gridPage + 1) + ' of ' + Math.ceil(rows.length / PAGE_SIZE) : ''));

        // pager
        const pages = Math.ceil(rows.length / PAGE_SIZE);
        let pager = '';
        if (pages > 1) {
            pager += `<li class="page-item ${gridPage === 0 ? 'disabled' : ''}"><a class="page-link" data-p="${gridPage - 1}" href="#">&laquo;</a></li>`;
            for (let i = 0; i < pages && i < 10; i++)
                pager += `<li class="page-item ${i === gridPage ? 'active' : ''}"><a class="page-link" data-p="${i}" href="#">${i + 1}</a></li>`;
            pager += `<li class="page-item ${gridPage >= pages - 1 ? 'disabled' : ''}"><a class="page-link" data-p="${gridPage + 1}" href="#">&raquo;</a></li>`;
        }
        $('#gridPager').html(pager);
    }

    // row click → server details page
    $(document).on('click', '#overviewGrid tbody tr[data-server]', function () {
        location.href = '/Server/Details?name=' + encodeURIComponent($(this).data('server'));
    });
    // pager click
    $(document).on('click', '#gridPager a', function (e) {
        e.preventDefault();
        const p = parseInt($(this).data('p'), 10);
        if (!isNaN(p) && p >= 0) { gridPage = p; renderGrid(); }
    });
    // column sort
    $(document).on('click', '#overviewGrid thead th[data-sort]', function () {
        const key = $(this).data('sort');
        if (sortKey === key) sortDir = -sortDir; else { sortKey = key; sortDir = 1; }
        renderGrid();
    });

    // ------------------------------------------------------------ trends
    async function getTrends() {
        if (!trendCache) trendCache = await dashFetch('/api/dashboard/trends?' + qs());
        return trendCache;
    }

    /** Groups trend points into { server: [{x, y}] } for one metric. */
    function seriesFor(trends, metric) {
        const map = {};
        trends.forEach(t => {
            (map[t.server] = map[t.server] || []).push({ x: fmt.day(t.day), y: t[metric] });
        });
        return map;
    }

    function lastPointPerServer(trends, metric) {
        const last = {};
        trends.forEach(t => { last[t.server] = t[metric]; });
        return last;
    }

    // ---------------- tab: authentication ----------------
    async function loadAuthTab() {
        const t = await getTrends();
        buildLineChart('chKerberos', seriesFor(t, 'kerberos'));
        buildLineChart('chNtlm', seriesFor(t, 'ntlm'));
        buildLineChart('chLogonSec', seriesFor(t, 'logonSec'));
        buildLineChart('chLogonErrors', seriesFor(t, 'logonErrors'), { thresholds: { critical: 10 } });
        buildLineChart('chLogonTotal', seriesFor(t, 'logonTotal'));

        // top busiest DCs: latest kerberos + ntlm
        const k = lastPointPerServer(t, 'kerberos'), n = lastPointPerServer(t, 'ntlm');
        const totals = Object.keys(k).map(s => ({ s, v: (k[s] || 0) + (n[s] || 0) }))
            .sort((a, b) => b.v - a.v).slice(0, 10);
        buildBarChart('chTopAuth', totals.map(x => x.s), totals.map(x => Math.round(x.v * 100) / 100), 'Auth/sec');
    }

    // ---------------- tab: LDAP ----------------
    async function loadLdapTab() {
        const t = await getTrends();
        buildLineChart('chLdapSearches', seriesFor(t, 'ldapSearchesSec'));
        buildLineChart('chLdapBind', seriesFor(t, 'ldapBindTime'), { thresholds: { warning: 50, critical: 100 } });
        buildLineChart('chLdapSessions', seriesFor(t, 'ldapClientSessions'));
        buildLineChart('chLdapBinds', seriesFor(t, 'ldapSuccessfulBindsSec'));

        // new vs closed connections, aggregated across selected servers
        const agg = {};
        t.forEach(p => {
            const d = fmt.day(p.day);
            agg[d] = agg[d] || { n: 0, c: 0 };
            agg[d].n += p.ldapNewConnectionsSec || 0;
            agg[d].c += p.ldapClosedConnectionsSec || 0;
        });
        buildLineChart('chLdapConns', {
            'New connections/sec': Object.keys(agg).map(d => ({ x: d, y: agg[d].n })),
            'Closed connections/sec': Object.keys(agg).map(d => ({ x: d, y: agg[d].c }))
        });

        const agg2 = {};
        t.forEach(p => {
            const d = fmt.day(p.day);
            agg2[d] = agg2[d] || { s: 0, c: 0 };
            agg2[d].s += p.serverNameTranslationsSec || 0;
            agg2[d].c += p.clientNameTranslationsSec || 0;
        });
        buildLineChart('chNameTrans', {
            'Server translations/sec': Object.keys(agg2).map(d => ({ x: d, y: agg2[d].s })),
            'Client translations/sec': Object.keys(agg2).map(d => ({ x: d, y: agg2[d].c }))
        });

        // heatmap: LDAP searches per server per day
        buildTrendHeatmap('ldapHeatmap', t, 'ldapSearchesSec', 'volume');
    }

    // ---------------- tab: memory ----------------
    async function loadMemoryTab() {
        const t = await getTrends();

        // cards computed from the latest overview snapshot
        const rows = overviewRows.length ? overviewRows : await dashFetch('/api/dashboard/overview?' + qs());
        const avg = (sel) => rows.length ? rows.reduce((a, r) => a + (sel(r) || 0), 0) / rows.length : 0;
        // memory pool details come from trends (latest day per server)
        const paged = lastAvg(t, 'memoryPoolPagedBytes'), nonpaged = lastAvg(t, 'memoryPoolNonPagedBytes');
        const pages = lastAvg(t, 'memoryPagesSec'), ptes = lastAvg(t, 'memoryFreePageTableEntries');

        const cards = [
            { label: 'Avg Available MB', value: fmt.int(avg(r => r.memoryAvailableMBytes)) },
            { label: 'Avg Pages/sec', value: fmt.num(pages) },
            { label: 'Avg Paged Pool', value: fmt.bytes(paged) },
            { label: 'Avg NonPaged Pool', value: fmt.bytes(nonpaged) },
            { label: 'Avg Free PTEs', value: fmt.int(ptes) }
        ];
        $('#memoryCards').html(cards.map(c => `
            <div class="col-6 col-md-4 col-xl-2">
                <div class="kpi-card"><div class="kpi-label">${c.label}</div><div class="kpi-value">${c.value}</div></div>
            </div>`).join(''));

        buildLineChart('chMemTrend', seriesFor(t, 'memoryAvailableMBytes'), { thresholds: { warning: 4096, critical: 2048 } });
        buildLineChart('chMemPages', seriesFor(t, 'memoryPagesSec'));

        // top memory consumers = lowest available memory
        const low = rows.slice().sort((a, b) => (a.memoryAvailableMBytes || 0) - (b.memoryAvailableMBytes || 0)).slice(0, 10);
        buildBarChart('chMemTop', low.map(r => r.server), low.map(r => r.memoryAvailableMBytes),
            'Available MB', v => v < 2048 ? cssVar('--critical') : v < 4096 ? cssVar('--warning') : cssVar('--healthy'));

        // pools aggregated per day
        const agg = {};
        t.forEach(p => {
            const d = fmt.day(p.day);
            agg[d] = agg[d] || { p: [], n: [] };
            if (p.memoryPoolPagedBytes != null) agg[d].p.push(p.memoryPoolPagedBytes);
            if (p.memoryPoolNonPagedBytes != null) agg[d].n.push(p.memoryPoolNonPagedBytes);
        });
        const mean = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : null;
        buildLineChart('chMemPools', {
            'Paged pool (avg bytes)': Object.keys(agg).map(d => ({ x: d, y: mean(agg[d].p) })),
            'NonPaged pool (avg bytes)': Object.keys(agg).map(d => ({ x: d, y: mean(agg[d].n) }))
        });
    }

    function lastAvg(trends, metric) {
        const last = lastPointPerServer(trends, metric);
        const vals = Object.values(last).filter(v => v != null);
        return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
    }

    // ---------------- tab: disk ----------------
    const DISK_METRICS = {
        c:     { read: 'diskCReadMs',     write: 'diskCWriteMs' },
        d:     { read: 'diskDReadMs',     write: 'diskDWriteMs' },
        total: { read: 'diskTotalReadMs', write: 'diskTotalWriteMs' }
    };

    async function loadDiskTab() {
        const t = await getTrends();
        const th = { thresholds: { warning: 10, critical: 20 } };

        if (diskScope === 'cd') {
            // combined view: sum C + D per point
            const mk = (rk, dk) => {
                const map = {};
                t.forEach(p => {
                    (map[p.server] = map[p.server] || []).push({
                        x: fmt.day(p.day),
                        y: (p[rk] != null || p[dk] != null) ? (p[rk] || 0) + (p[dk] || 0) : null
                    });
                });
                return map;
            };
            buildLineChart('chDiskRead', mk('diskCReadMs', 'diskDReadMs'), th);
            buildLineChart('chDiskWrite', mk('diskCWriteMs', 'diskDWriteMs'), th);
        } else {
            const m = DISK_METRICS[diskScope];
            buildLineChart('chDiskRead', seriesFor(t, m.read), th);
            buildLineChart('chDiskWrite', seriesFor(t, m.write), th);
        }

        // heatmap: worst of read/write for the chosen scope
        buildTrendHeatmap('diskHeatmap', t, null, 'latency');
    }

    $(document).on('click', '#diskScope button', function () {
        $('#diskScope button').removeClass('active');
        $(this).addClass('active');
        diskScope = $(this).data('scope');
        loadDiskTab();
    });

    // ---------------- heatmaps ----------------
    function buildTrendHeatmap(containerId, trends, metric, mode) {
        const servers = [...new Set(trends.map(p => p.server))].sort();
        const days = [...new Set(trends.map(p => p.day))].sort();
        const idx = {};
        trends.forEach(p => { idx[p.server + '|' + p.day] = p; });

        let valueFn, scaleFn, fmtFn;
        if (mode === 'latency') {
            const m = diskScope === 'cd' || diskScope === 'total' ? DISK_METRICS.total : DISK_METRICS[diskScope];
            valueFn = (s, d) => {
                const p = idx[s + '|' + d];
                if (!p) return null;
                const vals = [p[m.read], p[m.write]].filter(v => v != null);
                return vals.length ? Math.max(...vals) : null;
            };
            scaleFn = heatScale(10, 20);
            fmtFn = v => fmt.num(v) + ' ms';
        } else {
            const max = Math.max(1, ...trends.map(p => p[metric] || 0));
            valueFn = (s, d) => { const p = idx[s + '|' + d]; return p ? p[metric] : null; };
            scaleFn = blueScale(max);
            fmtFn = v => fmt.num(v) + '/sec';
        }
        buildHeatmap(containerId, servers, days, valueFn, scaleFn, fmtFn);
    }

    // ---------------- tab: server details launcher ----------------
    async function loadDetailsTab() {
        const servers = await dashFetch('/api/dashboard/servers');
        $('#serverLinkList').html(servers.map(s =>
            `<a class="server-chip" href="/Server/Details?name=${encodeURIComponent(s)}">
                <i class="fa-solid fa-server me-1"></i>${esc(s)}</a>`).join(''));
    }

    // ------------------------------------------------------------ tab lazy loading
    const TAB_LOADERS = { auth: loadAuthTab, ldap: loadLdapTab, memory: loadMemoryTab, disk: loadDiskTab, details: loadDetailsTab };

    $(document).on('shown.bs.tab', '#dashTabs button', function () {
        const tab = $(this).data('tab');
        if (loadedTabs.has(tab)) return;
        loadedTabs.add(tab);
        const loader = TAB_LOADERS[tab];
        if (loader) loader().catch(showError);
    });

    // ------------------------------------------------------------ filters / refresh
    async function refreshAll() {
        trendCache = null;
        loadedTabs.clear();
        try {
            await Promise.all([loadSummary(), loadOverview()]);
            // reload whichever tab is currently visible (overview needs nothing extra)
            const active = $('#dashTabs .nav-link.active').data('tab');
            if (active && TAB_LOADERS[active]) { loadedTabs.add(active); await TAB_LOADERS[active](); }
            $('#lastRefreshed').text('Updated ' + new Date().toLocaleTimeString());
        } catch (e) { showError(e); }
    }

    function showError(e) {
        console.error(e);
        $('#overviewGrid tbody').html('<tr><td colspan="12" class="text-center py-4 cell-critical"><i class="fa-solid fa-triangle-exclamation me-1"></i>' + esc(e.message) + '</td></tr>');
    }

    $('#btnApplyFilters, #btnRefresh').on('click', refreshAll);
    $('#btnClearFilters').on('click', function () {
        $('#fltSearch,#fltServer,#fltSite,#fltHealth,#fltFrom,#fltTo').val('');
        $('#fltDays').val(cfg.defaultTrendDays);
        refreshAll();
    });
    $('#fltSearch').on('input', function () { gridPage = 0; renderGrid(); });

    // exports honour the current filters
    $('#expCsv').on('click', e => { e.preventDefault(); location.href = '/api/export/overview/csv?' + qs(); });
    $('#expExcel').on('click', e => { e.preventDefault(); location.href = '/api/export/overview/excel?' + qs(); });

    // ------------------------------------------------------------ init
    async function init() {
        // populate filter drop-downs
        try {
            const [servers, sites] = await Promise.all([
                dashFetch('/api/dashboard/servers'),
                dashFetch('/api/dashboard/sites')
            ]);
            $('#fltServer').append(servers.map(s => `<option>${esc(s)}</option>`).join(''));
            $('#fltSite').append(sites.map(s => `<option>${esc(s)}</option>`).join(''));
        } catch { /* site table may be empty — non-fatal */ }

        await refreshAll();

        // auto refresh every N hours (default 12) without a page reload
        setInterval(refreshAll, (cfg.autoRefreshHours || 12) * 3600 * 1000);
    }

    $(init);
})();
