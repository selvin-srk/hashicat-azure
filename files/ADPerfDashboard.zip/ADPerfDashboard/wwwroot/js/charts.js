/* ===========================================================================
   charts.js — Chart.js factory helpers shared by the dashboard and the
   server details page. All colours come from CSS variables so the charts
   follow the dark / light theme automatically.
   ======================================================================== */
(function () {
    'use strict';

    // Distinct series palette (Azure chart colours)
    const COLORS = ['#2899f5', '#6ccb5f', '#ffb900', '#f1707b', '#b4a0ff',
                    '#00b7c3', '#ff8c00', '#e3008c', '#8cbd18', '#a0aeb2'];

    const registry = [];   // every chart we create, for theme refresh / destroy

    function baseOptions() {
        const dim = cssVar('--text-dim');
        const grid = cssVar('--grid-line');
        return {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'nearest', axis: 'x', intersect: false },
            plugins: {
                legend: { labels: { color: dim, boxWidth: 12, font: { size: 11 } } },
                tooltip: { backgroundColor: cssVar('--bg-panel'), titleColor: cssVar('--text'), bodyColor: cssVar('--text'), borderColor: grid, borderWidth: 1 }
            },
            scales: {
                x: { ticks: { color: dim, font: { size: 11 }, maxRotation: 45 }, grid: { color: grid } },
                y: { ticks: { color: dim, font: { size: 11 } }, grid: { color: grid }, beginAtZero: true }
            }
        };
    }

    /**
     * Build (or rebuild) a multi-series line chart.
     * seriesMap: { serverName: [{x: dayString, y: value}, ...] }
     */
    window.buildLineChart = function (canvasId, seriesMap, opts) {
        opts = opts || {};
        destroyChart(canvasId);
        const el = document.getElementById(canvasId);
        if (!el) return null;

        const datasets = Object.keys(seriesMap).map((name, i) => ({
            label: name,
            data: seriesMap[name],
            borderColor: COLORS[i % COLORS.length],
            backgroundColor: COLORS[i % COLORS.length] + '33',
            borderWidth: 1.6,
            pointRadius: 0,
            pointHitRadius: 6,
            tension: .25,
            fill: !!opts.fill
        }));

        const options = baseOptions();
        if (opts.thresholds) {
            // draw warning / critical guide lines via a tiny inline plugin
            options.plugins.thresholdLines = opts.thresholds;
        }

        // Category axis needs explicit labels: use the union of all x values
        // in first-seen order so every dataset aligns on the same axis.
        const labels = [];
        const seen = new Set();
        Object.values(seriesMap).forEach(pts => pts.forEach(p => {
            if (!seen.has(p.x)) { seen.add(p.x); labels.push(p.x); }
        }));

        const chart = new Chart(el, {
            type: 'line',
            data: { labels, datasets },
            options,
            plugins: [thresholdPlugin]
        });
        registry.push({ id: canvasId, chart });
        return chart;
    };

    /** Horizontal bar chart: labels[] + values[] (used by "top N" panels). */
    window.buildBarChart = function (canvasId, labels, values, label, colorByValue) {
        destroyChart(canvasId);
        const el = document.getElementById(canvasId);
        if (!el) return null;

        const bg = values.map((v, i) => colorByValue ? colorByValue(v) : COLORS[i % COLORS.length]);
        const options = baseOptions();
        options.indexAxis = 'y';
        options.plugins.legend.display = false;

        const chart = new Chart(el, {
            type: 'bar',
            data: { labels, datasets: [{ label, data: values, backgroundColor: bg, borderWidth: 0 }] },
            options
        });
        registry.push({ id: canvasId, chart });
        return chart;
    };

    /** Draws horizontal threshold guide lines (warning / critical). */
    const thresholdPlugin = {
        id: 'thresholdLines',
        afterDraw(chart) {
            const t = chart.options.plugins.thresholdLines;
            if (!t) return;
            const { ctx, chartArea, scales } = chart;
            const draw = (value, color) => {
                if (value === undefined) return;
                const y = scales.y.getPixelForValue(value);
                if (y < chartArea.top || y > chartArea.bottom) return;
                ctx.save();
                ctx.strokeStyle = color;
                ctx.setLineDash([6, 4]);
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(chartArea.left, y);
                ctx.lineTo(chartArea.right, y);
                ctx.stroke();
                ctx.restore();
            };
            draw(t.warning, cssVar('--warning'));
            draw(t.critical, cssVar('--critical'));
        }
    };

    /** Destroy one chart by canvas id (before rebuilding). */
    window.destroyChart = function (canvasId) {
        const i = registry.findIndex(r => r.id === canvasId);
        if (i >= 0) { registry[i].chart.destroy(); registry.splice(i, 1); }
    };

    /** Tiny inline sparkline rendered straight onto a canvas (no Chart.js —
        hundreds of sparklines must stay cheap). */
    window.drawSparkline = function (canvas, values) {
        const ctx = canvas.getContext('2d');
        const w = canvas.width = canvas.offsetWidth || 170;
        const h = canvas.height = canvas.offsetHeight || 34;
        ctx.clearRect(0, 0, w, h);

        const pts = values.map(v => (v === null || v === undefined) ? null : Number(v));
        const nums = pts.filter(v => v !== null);
        if (nums.length < 2) return;

        const min = Math.min(...nums), max = Math.max(...nums);
        const span = (max - min) || 1;
        const step = w / (pts.length - 1);

        ctx.strokeStyle = cssVar('--accent');
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        let started = false;
        pts.forEach((v, i) => {
            if (v === null) return;
            const x = i * step;
            const y = h - 3 - ((v - min) / span) * (h - 6);
            if (!started) { ctx.moveTo(x, y); started = true; } else { ctx.lineTo(x, y); }
        });
        ctx.stroke();
    };

    /**
     * Renders a server × day heatmap table.
     * data: { servers: [], days: [], value: (server, day) => number|null }
     * scale: value => css colour
     */
    window.buildHeatmap = function (containerId, servers, days, valueFn, scaleFn, fmtFn) {
        const host = document.getElementById(containerId);
        if (!host) return;
        let html = '<table class="heatmap-table"><thead><tr><th></th>';
        days.forEach(d => { html += '<th>' + new Date(d).getDate() + '</th>'; });
        html += '</tr></thead><tbody>';
        servers.forEach(s => {
            html += '<tr><th>' + esc(s) + '</th>';
            days.forEach(d => {
                const v = valueFn(s, d);
                const bg = v === null ? 'transparent' : scaleFn(v);
                const title = esc(s) + ' · ' + new Date(d).toLocaleDateString() + ' : ' + (v === null ? 'no data' : fmtFn(v));
                html += '<td style="background:' + bg + '" title="' + title + '"></td>';
            });
            html += '</tr>';
        });
        html += '</tbody></table>';
        host.innerHTML = html;
    };

    // Green→yellow→red scale helper for latency-style heatmaps
    window.heatScale = function (warn, crit) {
        return v => {
            if (v <= warn) return 'rgba(108,203,95,' + Math.max(.25, Math.min(1, v / warn)) + ')';
            if (v <= crit) return 'rgba(255,185,0,.75)';
            return 'rgba(241,112,123,.9)';
        };
    };

    // Blue intensity scale for volume-style heatmaps (LDAP searches)
    window.blueScale = function (max) {
        return v => 'rgba(40,153,245,' + Math.max(.08, Math.min(1, max ? v / max : 0)) + ')';
    };

    // Rebuild chart colours when the theme flips
    document.addEventListener('themechanged', () => {
        registry.forEach(r => {
            const o = baseOptions();
            r.chart.options.plugins.legend.labels.color = o.plugins.legend.labels.color;
            r.chart.options.scales.x.ticks.color = o.scales.x.ticks.color;
            r.chart.options.scales.y.ticks.color = o.scales.y.ticks.color;
            r.chart.options.scales.x.grid.color = o.scales.x.grid.color;
            r.chart.options.scales.y.grid.color = o.scales.y.grid.color;
            r.chart.update('none');
        });
    });
})();
