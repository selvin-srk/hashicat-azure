using ADPerfDashboard.Models;

namespace ADPerfDashboard.Services;

/// <summary>Evaluates a server snapshot against the configured health rules.</summary>
public interface IHealthEngine
{
    HealthResult Evaluate(AdPerfRecord record);
}
