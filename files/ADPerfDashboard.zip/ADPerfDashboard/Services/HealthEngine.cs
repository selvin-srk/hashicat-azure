using ADPerfDashboard.Models;

namespace ADPerfDashboard.Services;

/// <summary>
/// Health Engine — applies the operational rules to a single snapshot:
///   Memory Available : Critical &lt; 2048 MB, Warning &lt; 4096 MB
///   Disk Read        : Critical &gt; 20 ms,  Warning &gt; 10 ms
///   Disk Write       : Critical &gt; 20 ms,  Warning &gt; 10 ms
///   LDAP Bind Time   : Critical &gt; 100,    Warning &gt; 50
///   Logon Errors     : Critical &gt; 10
///   LSASS CPU        : Critical &gt; 70 %,   Warning &gt; 40 %
///   NTLM ratio       : Warning when NTLM share of auth exceeds threshold
/// All thresholds are configurable via appsettings.json.
/// </summary>
public class HealthEngine : IHealthEngine
{
    private readonly HealthThresholdOptions _t;

    public HealthEngine(IConfiguration configuration)
    {
        _t = configuration.GetSection(HealthThresholdOptions.SectionName)
                 .Get<HealthThresholdOptions>() ?? new HealthThresholdOptions();
    }

    public HealthResult Evaluate(AdPerfRecord r)
    {
        var result = new HealthResult();

        // Memory available
        if (r.MemoryAvailableMBytes is { } mem)
        {
            if (mem < _t.MemoryAvailableCriticalMB)
                Critical(result, $"Available memory {mem:N0} MB below critical threshold {_t.MemoryAvailableCriticalMB:N0} MB");
            else if (mem < _t.MemoryAvailableWarningMB)
                Warning(result, $"Available memory {mem:N0} MB below warning threshold {_t.MemoryAvailableWarningMB:N0} MB");
        }

        // Disk read latency (worst of C, D, Total)
        var read = MaxOf(r.DiskCReadMs, r.DiskDReadMs, r.DiskTotalReadMs);
        if (read is { } rd)
        {
            if (rd > _t.DiskReadCriticalMs)
                Critical(result, $"Disk read latency {rd:N1} ms exceeds {_t.DiskReadCriticalMs} ms");
            else if (rd > _t.DiskReadWarningMs)
                Warning(result, $"Disk read latency {rd:N1} ms exceeds {_t.DiskReadWarningMs} ms");
        }

        // Disk write latency
        var write = MaxOf(r.DiskCWriteMs, r.DiskDWriteMs, r.DiskTotalWriteMs);
        if (write is { } wr)
        {
            if (wr > _t.DiskWriteCriticalMs)
                Critical(result, $"Disk write latency {wr:N1} ms exceeds {_t.DiskWriteCriticalMs} ms");
            else if (wr > _t.DiskWriteWarningMs)
                Warning(result, $"Disk write latency {wr:N1} ms exceeds {_t.DiskWriteWarningMs} ms");
        }

        // LDAP bind time
        if (r.LdapBindTime is { } bind)
        {
            if (bind > _t.LdapBindTimeCriticalMs)
                Critical(result, $"LDAP bind time {bind:N0} exceeds critical threshold {_t.LdapBindTimeCriticalMs}");
            else if (bind > _t.LdapBindTimeWarningMs)
                Warning(result, $"LDAP bind time {bind:N0} exceeds warning threshold {_t.LdapBindTimeWarningMs}");
        }

        // Logon errors
        if (r.ServerErrorsLogon is { } errs && errs > _t.LogonErrorsCritical)
            Critical(result, $"Logon errors {errs:N0} exceed critical threshold {_t.LogonErrorsCritical:N0}");

        // LSASS CPU
        if (r.LsassProcessorTime is { } cpu)
        {
            if (cpu > _t.LsassCpuCriticalPercent)
                Critical(result, $"LSASS CPU {cpu:N1}% exceeds {_t.LsassCpuCriticalPercent}%");
            else if (cpu > _t.LsassCpuWarningPercent)
                Warning(result, $"LSASS CPU {cpu:N1}% exceeds {_t.LsassCpuWarningPercent}%");
        }

        // High NTLM percentage — indicates legacy auth still in heavy use
        if (r.NtlmPercent > _t.NtlmRatioWarningPercent)
            Warning(result, $"NTLM is {r.NtlmPercent:N1}% of authentications (threshold {_t.NtlmRatioWarningPercent}%)");

        return result;
    }

    /// <summary>Escalate to Critical (Critical always wins over Warning).</summary>
    private static void Critical(HealthResult res, string issue)
    {
        res.Status = HealthStatus.Critical;
        res.Issues.Add("[CRITICAL] " + issue);
    }

    /// <summary>Escalate to Warning unless already Critical.</summary>
    private static void Warning(HealthResult res, string issue)
    {
        if (res.Status < HealthStatus.Warning) res.Status = HealthStatus.Warning;
        res.Issues.Add("[WARNING] " + issue);
    }

    private static double? MaxOf(params double?[] values)
    {
        double? max = null;
        foreach (var v in values)
            if (v.HasValue && (!max.HasValue || v > max)) max = v;
        return max;
    }
}
