using ADPerfDashboard.Models;

namespace ADPerfDashboard.Services;

/// <summary>
/// Application service that composes repository data with the health engine
/// and shapes it for the UI. All heavy queries are cached (IMemoryCache).
/// </summary>
public interface IDashboardService
{
    Task<DashboardSummaryDto> GetSummaryAsync(DashboardFilter filter, CancellationToken ct = default);
    Task<IReadOnlyList<ServerOverviewDto>> GetOverviewAsync(DashboardFilter filter, CancellationToken ct = default);
    Task<IReadOnlyList<TrendPointDto>> GetTrendsAsync(DashboardFilter filter, CancellationToken ct = default);
    Task<IReadOnlyList<string>> GetServersAsync(CancellationToken ct = default);
    Task<IReadOnlyList<string>> GetSitesAsync(CancellationToken ct = default);
    Task<IReadOnlyList<AdPerfRecord>> GetServerHistoryAsync(string server, int days, CancellationToken ct = default);
    Task<PagedResult<AdPerfRecord>> GetHistoryPagedAsync(string? server, DateTime? from, DateTime? to, int offset, int pageSize, CancellationToken ct = default);
    Task<IReadOnlyList<MetricStatDto>> GetServerMetricStatsAsync(string server, int days, CancellationToken ct = default);
}
