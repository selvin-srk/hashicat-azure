using System.Globalization;
using System.Text;
using ADPerfDashboard.Models;
using ClosedXML.Excel;

namespace ADPerfDashboard.Services;

/// <summary>
/// CSV / Excel export. CSV is written manually (RFC 4180 escaping); Excel is
/// generated with ClosedXML including styled headers and auto-fit columns.
/// </summary>
public class ExportService : IExportService
{
    // ------------------------------------------------------------------ CSV

    public byte[] ToCsv(IReadOnlyList<ServerOverviewDto> rows)
    {
        var sb = new StringBuilder();
        sb.AppendLine("Server,Site,HealthStatus,MemoryAvailableMB,LsassCpuPct,LdapSearchesSec,LdapBindTime,KerberosAuth,NtlmAuth,NtlmPercent,DiskReadMs,DiskWriteMs,UptimeDays,LogonsSec,LogonErrors,ReportDate");
        foreach (var r in rows)
        {
            sb.AppendLine(string.Join(",",
                Csv(r.Server), Csv(r.Site), Csv(r.HealthStatus),
                Num(r.MemoryAvailableMBytes), Num(r.LsassCpu), Num(r.LdapSearchesSec),
                Num(r.LdapBindTime), Num(r.KerberosAuthentications), Num(r.NtlmAuthentications),
                Num(r.NtlmPercent), Num(r.DiskReadMs), Num(r.DiskWriteMs),
                Num(r.UptimeDays), Num(r.LogonSec), Num(r.ServerErrorsLogon),
                r.ReportDate.ToString("yyyy-MM-dd HH:mm:ss")));
        }
        // UTF-8 BOM so Excel opens the CSV correctly
        return Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
    }

    public byte[] HistoryToCsv(IReadOnlyList<AdPerfRecord> rows)
    {
        var sb = new StringBuilder();
        sb.AppendLine("Server,ReportDate,UptimeDays,MemoryAvailableMB,MemoryPagesSec,FreePTEs,PoolPagedBytes,PoolNonPagedBytes,LsassCpuPct,LsassWorkingSet,DiskCReadMs,DiskDReadMs,DiskTotalReadMs,DiskCWriteMs,DiskDWriteMs,DiskTotalWriteMs,KerberosAuth,NtlmAuth,LdapBindTime,LdapSearchesSec,LdapClientSessions,AbClientSessions,LdapSuccessfulBindsSec,LdapNewConnSec,LdapClosedConnSec,ServerNameTransSec,ClientNameTransSec,LogonErrors,ServerSessions,LogonTotal,LogonSec,TotalDays,LogonsPerDay");
        foreach (var r in rows)
        {
            sb.AppendLine(string.Join(",",
                Csv(r.Server), r.ReportDate.ToString("yyyy-MM-dd HH:mm:ss"), Num(r.UptimeDays),
                Num(r.MemoryAvailableMBytes), Num(r.MemoryPagesSec), Num(r.MemoryFreePageTableEntries),
                Num(r.MemoryPoolPagedBytes), Num(r.MemoryPoolNonPagedBytes),
                Num(r.LsassProcessorTime), Num(r.LsassWorkingSet),
                Num(r.DiskCReadMs), Num(r.DiskDReadMs), Num(r.DiskTotalReadMs),
                Num(r.DiskCWriteMs), Num(r.DiskDWriteMs), Num(r.DiskTotalWriteMs),
                Num(r.KerberosAuthentications), Num(r.NtlmAuthentications),
                Num(r.LdapBindTime), Num(r.LdapSearchesSec), Num(r.LdapClientSessions),
                Num(r.AbClientSessions), Num(r.LdapSuccessfulBindsSec),
                Num(r.LdapNewConnectionsSec), Num(r.LdapClosedConnectionsSec),
                Num(r.DsServerNameTranslationsSec), Num(r.DsClientNameTranslationsSec),
                Num(r.ServerErrorsLogon), Num(r.ServerSessions), Num(r.LogonTotal),
                Num(r.LogonSec), Num(r.TotalDays), Num(r.LogonsPerDay)));
        }
        return Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
    }

    // ---------------------------------------------------------------- Excel

    public byte[] ToExcel(IReadOnlyList<ServerOverviewDto> rows)
    {
        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("DC Overview");

        string[] headers = { "Server", "Site", "Health", "Memory (MB)", "LSASS CPU %",
            "LDAP Searches/sec", "LDAP Bind Time", "Kerberos/sec", "NTLM/sec", "NTLM %",
            "Disk Read (ms)", "Disk Write (ms)", "Uptime (days)", "Logons/sec",
            "Logon Errors", "Report Date" };
        WriteHeader(ws, headers);

        for (var i = 0; i < rows.Count; i++)
        {
            var r = rows[i];
            var row = i + 2;
            ws.Cell(row, 1).Value = r.Server;
            ws.Cell(row, 2).Value = r.Site;
            ws.Cell(row, 3).Value = r.HealthStatus;
            ws.Cell(row, 4).Value = r.MemoryAvailableMBytes;
            ws.Cell(row, 5).Value = r.LsassCpu;
            ws.Cell(row, 6).Value = r.LdapSearchesSec;
            ws.Cell(row, 7).Value = r.LdapBindTime;
            ws.Cell(row, 8).Value = r.KerberosAuthentications;
            ws.Cell(row, 9).Value = r.NtlmAuthentications;
            ws.Cell(row, 10).Value = r.NtlmPercent;
            ws.Cell(row, 11).Value = r.DiskReadMs;
            ws.Cell(row, 12).Value = r.DiskWriteMs;
            ws.Cell(row, 13).Value = r.UptimeDays;
            ws.Cell(row, 14).Value = r.LogonSec;
            ws.Cell(row, 15).Value = r.ServerErrorsLogon;
            ws.Cell(row, 16).Value = r.ReportDate;
            ws.Cell(row, 16).Style.DateFormat.Format = "yyyy-mm-dd hh:mm";

            // Colour-code the health cell to match the dashboard
            ws.Cell(row, 3).Style.Fill.BackgroundColor = r.HealthStatus switch
            {
                "Critical" => XLColor.FromHtml("#f8d7da"),
                "Warning"  => XLColor.FromHtml("#fff3cd"),
                _          => XLColor.FromHtml("#d1e7dd")
            };
        }

        ws.Columns().AdjustToContents();
        ws.SheetView.FreezeRows(1);
        return ToBytes(wb);
    }

    public byte[] HistoryToExcel(IReadOnlyList<AdPerfRecord> rows, string sheetName)
    {
        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add(Truncate(sheetName, 31));

        string[] headers = { "Server", "Report Date", "Uptime (days)", "Memory (MB)", "Pages/sec",
            "Free PTEs", "Pool Paged", "Pool NonPaged", "LSASS CPU %", "LSASS WS",
            "C: Read ms", "D: Read ms", "Total Read ms", "C: Write ms", "D: Write ms", "Total Write ms",
            "Kerberos", "NTLM", "LDAP Bind", "LDAP Searches/sec", "LDAP Sessions", "AB Sessions",
            "Successful Binds/sec", "New Conn/sec", "Closed Conn/sec", "Srv Name Trans/sec",
            "Cli Name Trans/sec", "Logon Errors", "Sessions", "Logon Total", "Logons/sec",
            "Total Days", "Logons/Day" };
        WriteHeader(ws, headers);

        for (var i = 0; i < rows.Count; i++)
        {
            var r = rows[i];
            var row = i + 2;
            var c = 1;
            ws.Cell(row, c++).Value = r.Server;
            ws.Cell(row, c).Value = r.ReportDate;
            ws.Cell(row, c++).Style.DateFormat.Format = "yyyy-mm-dd hh:mm";
            ws.Cell(row, c++).Value = r.UptimeDays;
            ws.Cell(row, c++).Value = r.MemoryAvailableMBytes;
            ws.Cell(row, c++).Value = r.MemoryPagesSec;
            ws.Cell(row, c++).Value = r.MemoryFreePageTableEntries;
            ws.Cell(row, c++).Value = r.MemoryPoolPagedBytes;
            ws.Cell(row, c++).Value = r.MemoryPoolNonPagedBytes;
            ws.Cell(row, c++).Value = r.LsassProcessorTime;
            ws.Cell(row, c++).Value = r.LsassWorkingSet;
            ws.Cell(row, c++).Value = r.DiskCReadMs;
            ws.Cell(row, c++).Value = r.DiskDReadMs;
            ws.Cell(row, c++).Value = r.DiskTotalReadMs;
            ws.Cell(row, c++).Value = r.DiskCWriteMs;
            ws.Cell(row, c++).Value = r.DiskDWriteMs;
            ws.Cell(row, c++).Value = r.DiskTotalWriteMs;
            ws.Cell(row, c++).Value = r.KerberosAuthentications;
            ws.Cell(row, c++).Value = r.NtlmAuthentications;
            ws.Cell(row, c++).Value = r.LdapBindTime;
            ws.Cell(row, c++).Value = r.LdapSearchesSec;
            ws.Cell(row, c++).Value = r.LdapClientSessions;
            ws.Cell(row, c++).Value = r.AbClientSessions;
            ws.Cell(row, c++).Value = r.LdapSuccessfulBindsSec;
            ws.Cell(row, c++).Value = r.LdapNewConnectionsSec;
            ws.Cell(row, c++).Value = r.LdapClosedConnectionsSec;
            ws.Cell(row, c++).Value = r.DsServerNameTranslationsSec;
            ws.Cell(row, c++).Value = r.DsClientNameTranslationsSec;
            ws.Cell(row, c++).Value = r.ServerErrorsLogon;
            ws.Cell(row, c++).Value = r.ServerSessions;
            ws.Cell(row, c++).Value = r.LogonTotal;
            ws.Cell(row, c++).Value = r.LogonSec;
            ws.Cell(row, c++).Value = r.TotalDays;
            ws.Cell(row, c).Value = r.LogonsPerDay;
        }

        ws.Columns().AdjustToContents();
        ws.SheetView.FreezeRows(1);
        return ToBytes(wb);
    }

    // -------------------------------------------------------------- helpers

    private static void WriteHeader(IXLWorksheet ws, string[] headers)
    {
        for (var i = 0; i < headers.Length; i++)
        {
            var cell = ws.Cell(1, i + 1);
            cell.Value = headers[i];
            cell.Style.Font.Bold = true;
            cell.Style.Font.FontColor = XLColor.White;
            cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#0078d4"); // Azure blue
        }
    }

    private static byte[] ToBytes(XLWorkbook wb)
    {
        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        return ms.ToArray();
    }

    /// <summary>RFC 4180 field escaping.</summary>
    private static string Csv(string? value)
    {
        if (string.IsNullOrEmpty(value)) return string.Empty;
        return value.Contains(',') || value.Contains('"') || value.Contains('\n')
            ? "\"" + value.Replace("\"", "\"\"") + "\""
            : value;
    }

    private static string Num(double? value) =>
        value?.ToString(CultureInfo.InvariantCulture) ?? string.Empty;

    private static string Truncate(string s, int max) => s.Length <= max ? s : s[..max];
}
