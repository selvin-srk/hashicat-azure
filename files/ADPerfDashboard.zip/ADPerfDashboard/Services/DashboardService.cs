using ADPerfDashboard.Models;
using ADPerfDashboard.Repositories;
using Microsoft.Extensions.Caching.Memory;

namespace ADPerfDashboard.Services;

/// <summary>
/// Composes repository data with the Health Engine and shapes results for the
/// UI. Latest-snapshot and trend queries are cached in-process to keep the
/// dashboard fast; history is loaded on demand (lazy loading).
/// </summary>
public class DashboardService : IDashboardService
{
    private readonly IAdPerfRepository _repo;
    private readonly IHealthEngine _health;
    private readonly IMemoryCache _cache;
    private readonly TimeSpan _cacheTtl;

    public DashboardService(IAdPerfRepository repo, IHealthEngine health,
                            IMemoryCache cache, IConfiguration config)
    {
        _repo = repo;
        _health = health;
        _cache = cache;
        _cacheTtl = TimeSpan.FromSeconds(config.GetValue("Dashboard:CacheSeconds", 300));
    }

    /// <summary>Latest snapshot per DC, filtered, with health evaluated once.</summary>
    private async Task<List<(AdPerfRecord Record, HealthResult Health)>> GetEvaluatedLatestAsync(
        DashboardFilter filter, CancellationToken ct)
    {
        var key = $"latest:{filter.Server}:{filter.Site}:{filter.DateFrom:o}:{filter.DateTo:o}";
        var rows = await _cache.GetOrCreateAsync(key, async e =>
        {
            e.AbsoluteExpirationRelativeToNow = _cacheTtl;
            return await _repo.GetLatestSnapshotAsync(filter.Server, filter.Site, filter.DateFrom, filter.DateTo, ct);
        }) ?? Array.Empty<AdPerfRecord>();

        var evaluated = rows.Select(r => (Record: r, Health: _health.Evaluate(r))).ToList();

        // Health filter is applied after evaluation (health is computed, not stored)
        if (!string.IsNullOrWhiteSpace(filter.Health) &&
            Enum.TryParse<HealthStatus>(filter.Health, true, out var status))
        {
            evaluated = evaluated.Where(x => x.Health.Status == status).ToList();
        }

        return evaluated;
    }

    public async Task<DashboardSummaryDto> GetSummaryAsync(DashboardFilter filter, CancellationToken ct = default)
    {
        var rows = await GetEvaluatedLatestAsync(filter, ct);
        var dto = new DashboardSummaryDto { TotalDomainControllers = rows.Count };
        if (rows.Count == 0) return dto;

        dto.LatestCollectionDate = rows.Max(x => x.Record.ReportDate);
        dto.HealthyCount  = rows.Count(x => x.Health.Status == HealthStatus.Healthy);
        dto.WarningCount  = rows.Count(x => x.Health.Status == HealthStatus.Warning);
        dto.CriticalCount = rows.Count(x => x.Health.Status == HealthStatus.Critical);

        dto.AvgLdapSearchesSec   = Round(rows.Average(x => x.Record.LdapSearchesSec ?? 0));
        dto.AvgKerberosAuthSec   = Round(rows.Average(x => x.Record.KerberosAuthentications ?? 0));
        dto.AvgNtlmAuthSec       = Round(rows.Average(x => x.Record.NtlmAuthentications ?? 0));
        dto.AvgAvailableMemoryMB = Round(rows.Average(x => x.Record.MemoryAvailableMBytes ?? 0), 0);

        var topCpu = rows.OrderByDescending(x => x.Record.LsassProcessorTime ?? 0).First();
        dto.HighestLsassCpu = Round(topCpu.Record.LsassProcessorTime ?? 0);
        dto.HighestLsassCpuServer = topCpu.Record.Server;

        var topDisk = rows.OrderByDescending(x => MaxLatency(x.Record)).First();
        dto.HighestDiskLatencyMs = Round(MaxLatency(topDisk.Record));
        dto.HighestDiskLatencyServer = topDisk.Record.Server;

        var topBind = rows.OrderByDescending(x => x.Record.LdapBindTime ?? 0).First();
        dto.HighestLdapBindTime = Round(topBind.Record.LdapBindTime ?? 0, 0);
        dto.HighestLdapBindTimeServer = topBind.Record.Server;

        return dto;
    }

    public async Task<IReadOnlyList<ServerOverviewDto>> GetOverviewAsync(DashboardFilter filter, CancellationToken ct = default)
    {
        var rows = await GetEvaluatedLatestAsync(filter, ct);
        return rows
            .OrderByDescending(x => x.Health.Status)   // critical first
            .ThenBy(x => x.Record.Server)
            .Select(x => new ServerOverviewDto
            {
                Server = x.Record.Server,
                Site = x.Record.Site,
                HealthStatus = x.Health.Status.ToString(),
                HealthIssues = x.Health.Issues,
                MemoryAvailableMBytes = x.Record.MemoryAvailableMBytes,
                LsassCpu = x.Record.LsassProcessorTime,
                LdapSearchesSec = x.Record.LdapSearchesSec,
                LdapBindTime = x.Record.LdapBindTime,
                KerberosAuthentications = x.Record.KerberosAuthentications,
                NtlmAuthentications = x.Record.NtlmAuthentications,
                NtlmPercent = x.Record.NtlmPercent,
                DiskReadMs = x.Record.DiskTotalReadMs ?? x.Record.DiskCReadMs,
                DiskWriteMs = x.Record.DiskTotalWriteMs ?? x.Record.DiskCWriteMs,
                UptimeDays = x.Record.UptimeDays,
                LogonSec = x.Record.LogonSec,
                ServerErrorsLogon = x.Record.ServerErrorsLogon,
                ReportDate = x.Record.ReportDate
            })
            .ToList();
    }

    public async Task<IReadOnlyList<TrendPointDto>> GetTrendsAsync(DashboardFilter filter, CancellationToken ct = default)
    {
        var key = $"trends:{filter.Days}:{filter.Server}:{filter.Site}";
        return await _cache.GetOrCreateAsync(key, async e =>
        {
            e.AbsoluteExpirationRelativeToNow = _cacheTtl;
            return await _repo.GetDailyTrendsAsync(filter.Days, filter.Server, filter.Site, ct);
        }) ?? Array.Empty<TrendPointDto>();
    }

    public async Task<IReadOnlyList<string>> GetServersAsync(CancellationToken ct = default) =>
        await _cache.GetOrCreateAsync("servers", async e =>
        {
            e.AbsoluteExpirationRelativeToNow = _cacheTtl;
            return await _repo.GetServersAsync(ct);
        }) ?? Array.Empty<string>();

    public async Task<IReadOnlyList<string>> GetSitesAsync(CancellationToken ct = default) =>
        await _cache.GetOrCreateAsync("sites", async e =>
        {
            e.AbsoluteExpirationRelativeToNow = _cacheTtl;
            return await _repo.GetSitesAsync(ct);
        }) ?? Array.Empty<string>();

    public Task<IReadOnlyList<AdPerfRecord>> GetServerHistoryAsync(string server, int days, CancellationToken ct = default) =>
        _repo.GetServerHistoryAsync(server, days, ct);

    public Task<PagedResult<AdPerfRecord>> GetHistoryPagedAsync(string? server, DateTime? from, DateTime? to,
        int offset, int pageSize, CancellationToken ct = default) =>
        _repo.GetHistoryPagedAsync(server, from, to, offset, pageSize, ct);

    /// <summary>
    /// Builds Min/Max/Avg + sparkline series for every metric over the given
    /// window — the data behind the Server Details page.
    /// </summary>
    public async Task<IReadOnlyList<MetricStatDto>> GetServerMetricStatsAsync(string server, int days, CancellationToken ct = default)
    {
        var history = (await _repo.GetServerHistoryAsync(server, days, ct))
            .OrderBy(r => r.ReportDate).ToList();

        var stats = new List<MetricStatDto>();

        // Local helper: computes one MetricStatDto from a selector.
        void Add(string metric, string label, string unit, Func<AdPerfRecord, double?> pick)
        {
            var series = history.Select(pick).ToList();
            var values = series.Where(v => v.HasValue).Select(v => v!.Value).ToList();
            stats.Add(new MetricStatDto
            {
                Metric = metric, Label = label, Unit = unit,
                Latest = values.Count > 0 ? Round(values[^1]) : null,
                Min = values.Count > 0 ? Round(values.Min()) : 0,
                Max = values.Count > 0 ? Round(values.Max()) : 0,
                Avg = values.Count > 0 ? Round(values.Average()) : 0,
                Spark = series
            });
        }

        Add("MemoryAvailableMBytes", "Available Memory", "MB", r => r.MemoryAvailableMBytes);
        Add("MemoryPagesSec", "Memory Pages/sec", "/sec", r => r.MemoryPagesSec);
        Add("MemoryFreePageTableEntries", "Free System PTEs", "", r => r.MemoryFreePageTableEntries);
        Add("MemoryPoolPagedBytes", "Pool Paged", "bytes", r => r.MemoryPoolPagedBytes);
        Add("MemoryPoolNonPagedBytes", "Pool NonPaged", "bytes", r => r.MemoryPoolNonPagedBytes);
        Add("LsassProcessorTime", "LSASS CPU", "%", r => r.LsassProcessorTime);
        Add("LsassWorkingSet", "LSASS Working Set", "bytes", r => r.LsassWorkingSet);
        Add("DiskCReadMs", "Disk C: Read Latency", "ms", r => r.DiskCReadMs);
        Add("DiskDReadMs", "Disk D: Read Latency", "ms", r => r.DiskDReadMs);
        Add("DiskTotalReadMs", "Disk Total Read Latency", "ms", r => r.DiskTotalReadMs);
        Add("DiskCWriteMs", "Disk C: Write Latency", "ms", r => r.DiskCWriteMs);
        Add("DiskDWriteMs", "Disk D: Write Latency", "ms", r => r.DiskDWriteMs);
        Add("DiskTotalWriteMs", "Disk Total Write Latency", "ms", r => r.DiskTotalWriteMs);
        Add("KerberosAuthentications", "Kerberos Authentications", "/sec", r => r.KerberosAuthentications);
        Add("NtlmAuthentications", "NTLM Authentications", "/sec", r => r.NtlmAuthentications);
        Add("LdapBindTime", "LDAP Bind Time", "ms", r => r.LdapBindTime);
        Add("LdapSearchesSec", "LDAP Searches", "/sec", r => r.LdapSearchesSec);
        Add("LdapClientSessions", "LDAP Client Sessions", "", r => r.LdapClientSessions);
        Add("AbClientSessions", "AB Client Sessions", "", r => r.AbClientSessions);
        Add("LdapSuccessfulBindsSec", "LDAP Successful Binds", "/sec", r => r.LdapSuccessfulBindsSec);
        Add("LdapNewConnectionsSec", "LDAP New Connections", "/sec", r => r.LdapNewConnectionsSec);
        Add("LdapClosedConnectionsSec", "LDAP Closed Connections", "/sec", r => r.LdapClosedConnectionsSec);
        Add("DsServerNameTranslationsSec", "Server Name Translations", "/sec", r => r.DsServerNameTranslationsSec);
        Add("DsClientNameTranslationsSec", "Client Name Translations", "/sec", r => r.DsClientNameTranslationsSec);
        Add("ServerErrorsLogon", "Logon Errors", "", r => r.ServerErrorsLogon);
        Add("ServerSessions", "Server Sessions", "", r => r.ServerSessions);
        Add("LogonTotal", "Total Logons", "", r => r.LogonTotal);
        Add("LogonSec", "Logons", "/sec", r => r.LogonSec);
        Add("LogonsPerDay", "Logons Per Day", "/day", r => r.LogonsPerDay);
        Add("SystemUpTimeSeconds", "Uptime", "days", r => r.SystemUpTimeSeconds.HasValue ? Math.Round(r.SystemUpTimeSeconds.Value / 86400.0, 1) : null);

        return stats;
    }

    private static double MaxLatency(AdPerfRecord r) =>
        new[] { r.DiskCReadMs ?? 0, r.DiskDReadMs ?? 0, r.DiskTotalReadMs ?? 0,
                r.DiskCWriteMs ?? 0, r.DiskDWriteMs ?? 0, r.DiskTotalWriteMs ?? 0 }.Max();

    private static double Round(double v, int digits = 2) => Math.Round(v, digits);
}
