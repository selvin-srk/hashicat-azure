using ADPerfDashboard.Models;

namespace ADPerfDashboard.Services;

/// <summary>Builds CSV and Excel exports from dashboard data.</summary>
public interface IExportService
{
    byte[] ToCsv(IReadOnlyList<ServerOverviewDto> rows);
    byte[] ToExcel(IReadOnlyList<ServerOverviewDto> rows);
    byte[] HistoryToCsv(IReadOnlyList<AdPerfRecord> rows);
    byte[] HistoryToExcel(IReadOnlyList<AdPerfRecord> rows, string sheetName);
}
