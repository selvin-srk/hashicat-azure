using ADPerfDashboard.Middleware;
using ADPerfDashboard.Repositories;
using ADPerfDashboard.Services;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.AspNetCore.Authorization;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// ---------------------------------------------------------------------------
// Logging: Serilog, configured from appsettings.json ("Serilog" section).
// Writes rolling daily log files to App_Data\Logs (audit + application logs).
// ---------------------------------------------------------------------------
builder.Host.UseSerilog((context, services, configuration) => configuration
    .ReadFrom.Configuration(context.Configuration)
    .Enrich.FromLogContext());

// ---------------------------------------------------------------------------
// Authentication: Windows Authentication (Negotiate = Kerberos/NTLM).
// Under IIS in-process hosting, IIS performs the handshake; Negotiate covers
// Kestrel/self-host scenarios so the app behaves identically in development.
// ---------------------------------------------------------------------------
builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme)
    .AddNegotiate();

// ---------------------------------------------------------------------------
// Authorization: role-based access. AD groups are configured in
// appsettings.json under "Authorization:ViewerGroups". If the list is empty,
// any authenticated domain user may view (read-only application).
// ---------------------------------------------------------------------------
builder.Services.AddAuthorization(options =>
{
    var viewerGroups = builder.Configuration
        .GetSection("Authorization:ViewerGroups").Get<string[]>() ?? Array.Empty<string>();

    options.AddPolicy("DashboardViewer", policy =>
    {
        policy.RequireAuthenticatedUser();
        if (viewerGroups.Length > 0)
        {
            policy.RequireRole(viewerGroups);
        }
    });

    // Every endpoint requires authentication unless explicitly opted out.
    options.FallbackPolicy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
});

// ---------------------------------------------------------------------------
// Dependency injection registrations (Repository + Service layers).
// ---------------------------------------------------------------------------
builder.Services.AddMemoryCache();
builder.Services.AddSingleton<ISqlConnectionFactory, SqlConnectionFactory>();
builder.Services.AddScoped<IAdPerfRepository, AdPerfRepository>();
builder.Services.AddScoped<IHealthEngine, HealthEngine>();
builder.Services.AddScoped<IDashboardService, DashboardService>();
builder.Services.AddScoped<IExportService, ExportService>();

builder.Services.AddControllersWithViews(options =>
{
    // Cache API responses for a short period at the MVC layer where marked.
    options.CacheProfiles.Add("ApiShort", new Microsoft.AspNetCore.Mvc.CacheProfile
    {
        Duration = 300, Location = Microsoft.AspNetCore.Mvc.ResponseCacheLocation.Client
    });
});

builder.Services.AddResponseCompression(o => o.EnableForHttps = true);

var app = builder.Build();

// ---------------------------------------------------------------------------
// Global exception handling: unhandled exceptions are logged with a
// correlation id and the client receives a sanitized error payload/page.
// ---------------------------------------------------------------------------
app.UseMiddleware<GlobalExceptionMiddleware>();

if (!app.Environment.IsDevelopment())
{
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseResponseCompression();
app.UseStaticFiles(new StaticFileOptions
{
    // Long client-side caching for static assets; file names are versioned
    // via asp-append-version tag helpers in the layout.
    OnPrepareResponse = ctx =>
        ctx.Context.Response.Headers.CacheControl = "public,max-age=604800"
});

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

// Audit logging: records authenticated user, action and timestamp for every
// request (read-only application, so all access is auditable).
app.UseMiddleware<AuditLoggingMiddleware>();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
