using ADPerfDashboard.Models;

namespace ADPerfDashboard.Repositories;

/// <summary>
/// Repository over dbo.ADPerfMonData. Every call is async and executes a
/// parameterized stored procedure — no dynamic SQL anywhere.
/// </summary>
public interface IAdPerfRepository
{
    /// <summary>Latest collection row for each domain controller (optionally filtered).</summary>
    Task<IReadOnlyList<AdPerfRecord>> GetLatestSnapshotAsync(string? server, string? site,
        DateTime? dateFrom, DateTime? dateTo, CancellationToken ct = default);

    /// <summary>Full history for one server over the last N days.</summary>
    Task<IReadOnlyList<AdPerfRecord>> GetServerHistoryAsync(string server, int days, CancellationToken ct = default);

    /// <summary>Daily averaged trends per server for charting.</summary>
    Task<IReadOnlyList<TrendPointDto>> GetDailyTrendsAsync(int days, string? server, string? site, CancellationToken ct = default);

    /// <summary>Distinct server names.</summary>
    Task<IReadOnlyList<string>> GetServersAsync(CancellationToken ct = default);

    /// <summary>Distinct site names from the site map table.</summary>
    Task<IReadOnlyList<string>> GetSitesAsync(CancellationToken ct = default);

    /// <summary>Paged raw history for lazy-loading grids.</summary>
    Task<PagedResult<AdPerfRecord>> GetHistoryPagedAsync(string? server, DateTime? dateFrom,
        DateTime? dateTo, int offset, int pageSize, CancellationToken ct = default);
}
