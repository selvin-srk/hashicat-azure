using Microsoft.Data.SqlClient;

namespace ADPerfDashboard.Repositories;

/// <summary>Creates pooled SQL connections (ADO.NET pooling is automatic).</summary>
public interface ISqlConnectionFactory
{
    SqlConnection Create();
}

/// <summary>
/// Reads the "ADSStats" connection string once at startup. Integrated
/// Security means the IIS application-pool identity authenticates to SQL
/// Server — no credentials in configuration.
/// </summary>
public class SqlConnectionFactory : ISqlConnectionFactory
{
    private readonly string _connectionString;

    public SqlConnectionFactory(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("ADSStats")
            ?? throw new InvalidOperationException("Connection string 'ADSStats' is not configured.");
    }

    public SqlConnection Create() => new(_connectionString);
}
