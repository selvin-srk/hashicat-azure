using ADPerfDashboard.Models;
using Dapper;
using System.Data;

namespace ADPerfDashboard.Repositories;

/// <summary>
/// Data access for dbo.ADPerfMonData via Dapper. Rules enforced here:
///   - stored procedures only (CommandType.StoredProcedure)
///   - parameterized everywhere — SQL injection is impossible
///   - fully async with cancellation support
///   - connections come from the pooled factory and are disposed per call
/// </summary>
public class AdPerfRepository : IAdPerfRepository
{
    private readonly ISqlConnectionFactory _factory;
    private readonly ILogger<AdPerfRepository> _logger;

    public AdPerfRepository(ISqlConnectionFactory factory, ILogger<AdPerfRepository> logger)
    {
        _factory = factory;
        _logger = logger;
    }

    public async Task<IReadOnlyList<AdPerfRecord>> GetLatestSnapshotAsync(string? server, string? site,
        DateTime? dateFrom, DateTime? dateTo, CancellationToken ct = default)
    {
        await using var conn = _factory.Create();
        var rows = await conn.QueryAsync<AdPerfRecord>(new CommandDefinition(
            "dbo.usp_GetLatestSnapshot",
            new { Server = Nullify(server), Site = Nullify(site), DateFrom = dateFrom, DateTo = dateTo },
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct));
        return rows.AsList();
    }

    public async Task<IReadOnlyList<AdPerfRecord>> GetServerHistoryAsync(string server, int days, CancellationToken ct = default)
    {
        await using var conn = _factory.Create();
        var rows = await conn.QueryAsync<AdPerfRecord>(new CommandDefinition(
            "dbo.usp_GetServerHistory",
            new { Server = server, Days = days },
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct));
        return rows.AsList();
    }

    public async Task<IReadOnlyList<TrendPointDto>> GetDailyTrendsAsync(int days, string? server, string? site, CancellationToken ct = default)
    {
        await using var conn = _factory.Create();
        var rows = await conn.QueryAsync<TrendPointDto>(new CommandDefinition(
            "dbo.usp_GetDailyTrends",
            new { Days = days, Server = Nullify(server), Site = Nullify(site) },
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct));
        return rows.AsList();
    }

    public async Task<IReadOnlyList<string>> GetServersAsync(CancellationToken ct = default)
    {
        await using var conn = _factory.Create();
        var rows = await conn.QueryAsync<string>(new CommandDefinition(
            "dbo.usp_GetServers",
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct));
        return rows.AsList();
    }

    public async Task<IReadOnlyList<string>> GetSitesAsync(CancellationToken ct = default)
    {
        await using var conn = _factory.Create();
        var rows = await conn.QueryAsync<string>(new CommandDefinition(
            "dbo.usp_GetSites",
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct));
        return rows.AsList();
    }

    public async Task<PagedResult<AdPerfRecord>> GetHistoryPagedAsync(string? server, DateTime? dateFrom,
        DateTime? dateTo, int offset, int pageSize, CancellationToken ct = default)
    {
        await using var conn = _factory.Create();

        // The stored procedure returns two result sets: total count + page.
        using var multi = await conn.QueryMultipleAsync(new CommandDefinition(
            "dbo.usp_GetHistoryPaged",
            new { Server = Nullify(server), DateFrom = dateFrom, DateTo = dateTo, Offset = offset, PageSize = pageSize },
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct));

        var total = await multi.ReadSingleAsync<int>();
        var items = (await multi.ReadAsync<AdPerfRecord>()).AsList();

        return new PagedResult<AdPerfRecord>
        {
            Items = items, TotalCount = total, Offset = offset, PageSize = pageSize
        };
    }

    /// <summary>Empty strings become NULL so optional SP parameters behave.</summary>
    private static string? Nullify(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
