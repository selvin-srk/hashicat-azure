namespace ADPerfDashboard.Models;

/// <summary>Overall health classification for a domain controller.</summary>
public enum HealthStatus
{
    Healthy = 0,
    Warning = 1,
    Critical = 2
}

/// <summary>Result of evaluating one server snapshot against the health rules.</summary>
public class HealthResult
{
    public HealthStatus Status { get; set; } = HealthStatus.Healthy;

    /// <summary>Human-readable list of every rule that fired.</summary>
    public List<string> Issues { get; set; } = new();
}

/// <summary>
/// Health thresholds bound from appsettings.json ("HealthThresholds").
/// Keeping the rules in configuration lets operations tune them without a
/// redeploy.
/// </summary>
public class HealthThresholdOptions
{
    public const string SectionName = "HealthThresholds";

    public double MemoryAvailableCriticalMB { get; set; } = 2048;
    public double MemoryAvailableWarningMB { get; set; } = 4096;
    public double DiskReadCriticalMs { get; set; } = 20;
    public double DiskReadWarningMs { get; set; } = 10;
    public double DiskWriteCriticalMs { get; set; } = 20;
    public double DiskWriteWarningMs { get; set; } = 10;
    public double LdapBindTimeCriticalMs { get; set; } = 100;
    public double LdapBindTimeWarningMs { get; set; } = 50;
    public double LogonErrorsCritical { get; set; } = 10;
    public double LsassCpuCriticalPercent { get; set; } = 70;
    public double LsassCpuWarningPercent { get; set; } = 40;
    public double NtlmRatioWarningPercent { get; set; } = 25;
}
