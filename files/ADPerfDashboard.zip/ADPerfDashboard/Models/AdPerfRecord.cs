namespace ADPerfDashboard.Models;

/// <summary>
/// One collection row from dbo.ADPerfMonData. Property names match the column
/// aliases produced by the stored procedures so Dapper maps automatically.
/// Disk latencies are converted to milliseconds by the stored procedures
/// (PerfMon "Avg. Disk sec/Read|Write" counters are stored in seconds).
/// </summary>
public class AdPerfRecord
{
    public long Id { get; set; }
    public string Server { get; set; } = string.Empty;
    public string? Site { get; set; }

    // System
    public double? SystemUpTimeSeconds { get; set; }

    // Memory
    public double? MemoryAvailableMBytes { get; set; }
    public double? MemoryPagesSec { get; set; }
    public double? MemoryFreePageTableEntries { get; set; }
    public double? MemoryPoolNonPagedBytes { get; set; }
    public double? MemoryPoolPagedBytes { get; set; }

    // LSASS process
    public double? LsassProcessorTime { get; set; }
    public double? LsassWorkingSet { get; set; }

    // Disk latency (milliseconds)
    public double? DiskCReadMs { get; set; }
    public double? DiskDReadMs { get; set; }
    public double? DiskTotalReadMs { get; set; }
    public double? DiskCWriteMs { get; set; }
    public double? DiskDWriteMs { get; set; }
    public double? DiskTotalWriteMs { get; set; }

    // Authentication
    public double? KerberosAuthentications { get; set; }
    public double? NtlmAuthentications { get; set; }

    // Directory Services (NTDS)
    public double? LdapBindTime { get; set; }
    public double? LdapSearchesSec { get; set; }
    public double? LdapClientSessions { get; set; }
    public double? AbClientSessions { get; set; }
    public double? LdapSuccessfulBindsSec { get; set; }
    public double? LdapNewConnectionsSec { get; set; }
    public double? LdapClosedConnectionsSec { get; set; }
    public double? DsServerNameTranslationsSec { get; set; }
    public double? DsClientNameTranslationsSec { get; set; }

    // Server / logon
    public double? ServerErrorsLogon { get; set; }
    public double? ServerSessions { get; set; }
    public double? LogonTotal { get; set; }
    public double? LogonSec { get; set; }
    public double? TotalDays { get; set; }
    public double? LogonsPerDay { get; set; }

    public DateTime ReportDate { get; set; }

    /// <summary>Uptime expressed in days for display.</summary>
    public double UptimeDays => Math.Round((SystemUpTimeSeconds ?? 0) / 86400.0, 1);

    /// <summary>NTLM share of all authentications (0-100).</summary>
    public double NtlmPercent
    {
        get
        {
            var total = (KerberosAuthentications ?? 0) + (NtlmAuthentications ?? 0);
            return total <= 0 ? 0 : Math.Round((NtlmAuthentications ?? 0) / total * 100.0, 1);
        }
    }
}
