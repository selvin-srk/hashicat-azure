namespace ADPerfDashboard.Models;

/// <summary>Top summary cards for the dashboard header.</summary>
public class DashboardSummaryDto
{
    public DateTime? LatestCollectionDate { get; set; }
    public int TotalDomainControllers { get; set; }
    public int HealthyCount { get; set; }
    public int WarningCount { get; set; }
    public int CriticalCount { get; set; }
    public double AvgLdapSearchesSec { get; set; }
    public double AvgKerberosAuthSec { get; set; }
    public double AvgNtlmAuthSec { get; set; }
    public double AvgAvailableMemoryMB { get; set; }
    public double HighestLsassCpu { get; set; }
    public string HighestLsassCpuServer { get; set; } = "-";
    public double HighestDiskLatencyMs { get; set; }
    public string HighestDiskLatencyServer { get; set; } = "-";
    public double HighestLdapBindTime { get; set; }
    public string HighestLdapBindTimeServer { get; set; } = "-";
}

/// <summary>One row of the Overview grid (latest snapshot + computed health).</summary>
public class ServerOverviewDto
{
    public string Server { get; set; } = string.Empty;
    public string? Site { get; set; }
    public string HealthStatus { get; set; } = "Healthy";
    public List<string> HealthIssues { get; set; } = new();
    public double? MemoryAvailableMBytes { get; set; }
    public double? LsassCpu { get; set; }
    public double? LdapSearchesSec { get; set; }
    public double? LdapBindTime { get; set; }
    public double? KerberosAuthentications { get; set; }
    public double? NtlmAuthentications { get; set; }
    public double NtlmPercent { get; set; }
    public double? DiskReadMs { get; set; }
    public double? DiskWriteMs { get; set; }
    public double UptimeDays { get; set; }
    public double? LogonSec { get; set; }
    public double? ServerErrorsLogon { get; set; }
    public DateTime ReportDate { get; set; }
}

/// <summary>Filter parameters accepted by the dashboard API endpoints.</summary>
public class DashboardFilter
{
    public string? Server { get; set; }
    public string? Site { get; set; }
    public DateTime? DateFrom { get; set; }
    public DateTime? DateTo { get; set; }
    public string? Health { get; set; }   // Healthy | Warning | Critical
    public int Days { get; set; } = 30;
}

/// <summary>Daily trend point used by every Chart.js time-series chart.</summary>
public class TrendPointDto
{
    public string Server { get; set; } = string.Empty;
    public DateTime Day { get; set; }
    public double? Kerberos { get; set; }
    public double? Ntlm { get; set; }
    public double? LogonSec { get; set; }
    public double? LogonTotal { get; set; }
    public double? LogonErrors { get; set; }
    public double? LdapSearchesSec { get; set; }
    public double? LdapBindTime { get; set; }
    public double? LdapClientSessions { get; set; }
    public double? LdapSuccessfulBindsSec { get; set; }
    public double? LdapNewConnectionsSec { get; set; }
    public double? LdapClosedConnectionsSec { get; set; }
    public double? ServerNameTranslationsSec { get; set; }
    public double? ClientNameTranslationsSec { get; set; }
    public double? MemoryAvailableMBytes { get; set; }
    public double? MemoryPagesSec { get; set; }
    public double? MemoryPoolPagedBytes { get; set; }
    public double? MemoryPoolNonPagedBytes { get; set; }
    public double? MemoryFreePageTableEntries { get; set; }
    public double? DiskCReadMs { get; set; }
    public double? DiskDReadMs { get; set; }
    public double? DiskTotalReadMs { get; set; }
    public double? DiskCWriteMs { get; set; }
    public double? DiskDWriteMs { get; set; }
    public double? DiskTotalWriteMs { get; set; }
    public double? LsassCpu { get; set; }
    public double? LsassWorkingSet { get; set; }
}

/// <summary>Min/Max/Avg statistics for one metric on the Server Details page.</summary>
public class MetricStatDto
{
    public string Metric { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public string Unit { get; set; } = string.Empty;
    public double? Latest { get; set; }
    public double Min { get; set; }
    public double Max { get; set; }
    public double Avg { get; set; }
    /// <summary>Series for the sparkline (oldest → newest).</summary>
    public List<double?> Spark { get; set; } = new();
}

/// <summary>Paged result wrapper for lazy-loaded history grids.</summary>
public class PagedResult<T>
{
    public IReadOnlyList<T> Items { get; set; } = Array.Empty<T>();
    public int TotalCount { get; set; }
    public int Offset { get; set; }
    public int PageSize { get; set; }
}
