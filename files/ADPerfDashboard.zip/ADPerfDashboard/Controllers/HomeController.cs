using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ADPerfDashboard.Controllers;

/// <summary>Serves the dashboard shell; all data arrives later via AJAX.</summary>
[Authorize(Policy = "DashboardViewer")]
public class HomeController : Controller
{
    private readonly IConfiguration _config;

    public HomeController(IConfiguration config) => _config = config;

    /// <summary>Main dashboard page (tabs load their data lazily).</summary>
    public IActionResult Index()
    {
        ViewBag.AutoRefreshHours = _config.GetValue("Dashboard:AutoRefreshHours", 12);
        ViewBag.DefaultTrendDays = _config.GetValue("Dashboard:DefaultTrendDays", 30);
        return View();
    }

    /// <summary>Friendly error page shown by the global exception handler.</summary>
    [AllowAnonymous]
    public IActionResult Error(string? @ref)
    {
        ViewBag.ReferenceId = @ref;
        return View();
    }
}
