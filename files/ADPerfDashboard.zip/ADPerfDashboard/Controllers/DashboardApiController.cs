using ADPerfDashboard.Models;
using ADPerfDashboard.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ADPerfDashboard.Controllers;

/// <summary>
/// JSON API consumed by the dashboard's AJAX layer. Everything is read-only
/// GET; results are short-cached client-side ("ApiShort" profile) and
/// server-side (IMemoryCache in the service layer).
/// </summary>
[ApiController]
[Route("api/dashboard")]
[Authorize(Policy = "DashboardViewer")]
public class DashboardApiController : ControllerBase
{
    private readonly IDashboardService _service;

    public DashboardApiController(IDashboardService service) => _service = service;

    /// <summary>Top summary cards.</summary>
    [HttpGet("summary")]
    [ResponseCache(CacheProfileName = "ApiShort")]
    public async Task<ActionResult<DashboardSummaryDto>> Summary([FromQuery] DashboardFilter filter, CancellationToken ct) =>
        Ok(await _service.GetSummaryAsync(filter, ct));

    /// <summary>Overview grid — latest snapshot per DC with computed health.</summary>
    [HttpGet("overview")]
    [ResponseCache(CacheProfileName = "ApiShort")]
    public async Task<ActionResult<IReadOnlyList<ServerOverviewDto>>> Overview([FromQuery] DashboardFilter filter, CancellationToken ct) =>
        Ok(await _service.GetOverviewAsync(filter, ct));

    /// <summary>Daily trend points powering all Chart.js charts and heatmaps.</summary>
    [HttpGet("trends")]
    [ResponseCache(CacheProfileName = "ApiShort")]
    public async Task<ActionResult<IReadOnlyList<TrendPointDto>>> Trends([FromQuery] DashboardFilter filter, CancellationToken ct)
    {
        if (filter.Days is < 1 or > 365) filter.Days = 30;
        return Ok(await _service.GetTrendsAsync(filter, ct));
    }

    /// <summary>Distinct server names (filter drop-down).</summary>
    [HttpGet("servers")]
    [ResponseCache(CacheProfileName = "ApiShort")]
    public async Task<ActionResult<IReadOnlyList<string>>> Servers(CancellationToken ct) =>
        Ok(await _service.GetServersAsync(ct));

    /// <summary>Distinct site names (filter drop-down).</summary>
    [HttpGet("sites")]
    [ResponseCache(CacheProfileName = "ApiShort")]
    public async Task<ActionResult<IReadOnlyList<string>>> Sites(CancellationToken ct) =>
        Ok(await _service.GetSitesAsync(ct));

    /// <summary>Raw history for one server (used by detail charts).</summary>
    [HttpGet("history")]
    public async Task<ActionResult<IReadOnlyList<AdPerfRecord>>> History(
        [FromQuery] string server, [FromQuery] int days = 90, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(server)) return BadRequest("server is required");
        if (days is < 1 or > 730) days = 90;
        return Ok(await _service.GetServerHistoryAsync(server, days, ct));
    }

    /// <summary>Paged history for lazy-loaded grids (loads on demand).</summary>
    [HttpGet("historypaged")]
    public async Task<ActionResult<PagedResult<AdPerfRecord>>> HistoryPaged(
        [FromQuery] string? server, [FromQuery] DateTime? from, [FromQuery] DateTime? to,
        [FromQuery] int offset = 0, [FromQuery] int pageSize = 25, CancellationToken ct = default) =>
        Ok(await _service.GetHistoryPagedAsync(server, from, to, offset, pageSize, ct));

    /// <summary>Min/Max/Avg + sparkline series for every metric of one server.</summary>
    [HttpGet("serverstats")]
    public async Task<ActionResult<IReadOnlyList<MetricStatDto>>> ServerStats(
        [FromQuery] string server, [FromQuery] int days = 90, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(server)) return BadRequest("server is required");
        if (days is < 1 or > 730) days = 90;
        return Ok(await _service.GetServerMetricStatsAsync(server, days, ct));
    }
}
