using ADPerfDashboard.Models;
using ADPerfDashboard.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ADPerfDashboard.Controllers;

/// <summary>
/// CSV / Excel download endpoints. Each export is audit-logged with the
/// requesting user via the audit middleware.
/// </summary>
[Route("api/export")]
[Authorize(Policy = "DashboardViewer")]
public class ExportController : ControllerBase
{
    private const string CsvMime = "text/csv";
    private const string XlsxMime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    private readonly IDashboardService _service;
    private readonly IExportService _export;

    public ExportController(IDashboardService service, IExportService export)
    {
        _service = service;
        _export = export;
    }

    /// <summary>Overview grid as CSV.</summary>
    [HttpGet("overview/csv")]
    public async Task<IActionResult> OverviewCsv([FromQuery] DashboardFilter filter, CancellationToken ct)
    {
        var rows = await _service.GetOverviewAsync(filter, ct);
        return File(_export.ToCsv(rows), CsvMime, FileName("DC-Overview", "csv"));
    }

    /// <summary>Overview grid as Excel.</summary>
    [HttpGet("overview/excel")]
    public async Task<IActionResult> OverviewExcel([FromQuery] DashboardFilter filter, CancellationToken ct)
    {
        var rows = await _service.GetOverviewAsync(filter, ct);
        return File(_export.ToExcel(rows), XlsxMime, FileName("DC-Overview", "xlsx"));
    }

    /// <summary>One server's history as CSV (Server Details export).</summary>
    [HttpGet("history/csv")]
    public async Task<IActionResult> HistoryCsv([FromQuery] string server, [FromQuery] int days = 90, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(server)) return BadRequest("server is required");
        var rows = await _service.GetServerHistoryAsync(server, days, ct);
        return File(_export.HistoryToCsv(rows), CsvMime, FileName(server + "-History", "csv"));
    }

    /// <summary>One server's history as Excel (Server Details export).</summary>
    [HttpGet("history/excel")]
    public async Task<IActionResult> HistoryExcel([FromQuery] string server, [FromQuery] int days = 90, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(server)) return BadRequest("server is required");
        var rows = await _service.GetServerHistoryAsync(server, days, ct);
        return File(_export.HistoryToExcel(rows, server), XlsxMime, FileName(server + "-History", "xlsx"));
    }

    private static string FileName(string prefix, string ext) =>
        $"{prefix}-{DateTime.Now:yyyyMMdd-HHmm}.{ext}";
}
