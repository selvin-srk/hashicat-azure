using ADPerfDashboard.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ADPerfDashboard.Controllers;

/// <summary>Server Details page — every metric with sparkline + 90-day history.</summary>
[Authorize(Policy = "DashboardViewer")]
public class ServerController : Controller
{
    private readonly IDashboardService _service;
    private readonly IConfiguration _config;

    public ServerController(IDashboardService service, IConfiguration config)
    {
        _service = service;
        _config = config;
    }

    /// <summary>Detail page shell; metric data loads via /api/dashboard/serverstats.</summary>
    public async Task<IActionResult> Details(string name, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(name)) return RedirectToAction("Index", "Home");

        // Validate the server exists (also prevents junk in the page title)
        var servers = await _service.GetServersAsync(ct);
        if (!servers.Contains(name, StringComparer.OrdinalIgnoreCase))
            return NotFound($"Unknown server '{name}'.");

        ViewBag.ServerName = name;
        ViewBag.HistoryDays = _config.GetValue("Dashboard:DetailHistoryDays", 90);
        return View();
    }
}
