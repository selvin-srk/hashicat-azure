using System.Diagnostics;

namespace ADPerfDashboard.Middleware;

/// <summary>
/// Audit logging: records who accessed what and when. Static assets are
/// skipped to keep the audit log focused on data access.
/// </summary>
public class AuditLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<AuditLoggingMiddleware> _logger;

    private static readonly string[] SkipPrefixes = { "/css", "/js", "/lib", "/favicon" };

    public AuditLoggingMiddleware(RequestDelegate next, ILogger<AuditLoggingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var path = context.Request.Path.Value ?? string.Empty;
        if (SkipPrefixes.Any(p => path.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
        {
            await _next(context);
            return;
        }

        var sw = Stopwatch.StartNew();
        await _next(context);
        sw.Stop();

        _logger.LogInformation("AUDIT user={User} method={Method} path={Path}{Query} status={Status} elapsedMs={Elapsed}",
            context.User?.Identity?.Name ?? "anonymous",
            context.Request.Method,
            path,
            context.Request.QueryString.Value,
            context.Response.StatusCode,
            sw.ElapsedMilliseconds);
    }
}
