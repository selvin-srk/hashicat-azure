using System.Net;
using System.Text.Json;

namespace ADPerfDashboard.Middleware;

/// <summary>
/// Global exception handler. Logs the full exception with a correlation id;
/// API calls receive a sanitized JSON payload, page requests are redirected to
/// the friendly error view. No stack traces ever leave the server.
/// </summary>
public class GlobalExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<GlobalExceptionMiddleware> _logger;

    public GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            var correlationId = Guid.NewGuid().ToString("N")[..12];
            _logger.LogError(ex, "Unhandled exception {CorrelationId} {Method} {Path} User={User}",
                correlationId, context.Request.Method, context.Request.Path,
                context.User?.Identity?.Name ?? "anonymous");

            if (context.Response.HasStarted) throw;

            context.Response.Clear();
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            if (context.Request.Path.StartsWithSegments("/api"))
            {
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsync(JsonSerializer.Serialize(new
                {
                    error = "An unexpected error occurred. Contact your administrator with the reference id.",
                    referenceId = correlationId
                }));
            }
            else
            {
                context.Response.Redirect($"/Home/Error?ref={correlationId}");
            }
        }
    }
}
